-- database/schema.sql — one table per data/ domain (PostgreSQL / SQLite compatible)
CREATE TABLE IF NOT EXISTS county_master (code INTEGER PRIMARY KEY, name TEXT UNIQUE NOT NULL, region TEXT NOT NULL, term TEXT NOT NULL DEFAULT '2022-2027');
CREATE TABLE IF NOT EXISTS demographics (county_code INTEGER PRIMARY KEY REFERENCES county_master(code), population_2019 INTEGER, land_area_sqkm REAL, density_per_sqkm INTEGER, source TEXT);
CREATE TABLE IF NOT EXISTS health (county_code INTEGER PRIMARY KEY REFERENCES county_master(code), facilities_per_10k REAL, doctor_patient_ratio TEXT, immunization_rate REAL, maternal_mortality TEXT, budget_per_capita TEXT, fy TEXT, source TEXT);
CREATE TABLE IF NOT EXISTS education (county_code INTEGER PRIMARY KEY REFERENCES county_master(code), primary_enrol REAL, secondary_enrol REAL, completion_primary REAL, teachers TEXT, budget_per_capita TEXT, fy TEXT, source TEXT);
CREATE TABLE IF NOT EXISTS agriculture (id TEXT PRIMARY KEY, county_code INTEGER REFERENCES county_master(code), commodity TEXT, output TEXT, fy TEXT, source TEXT);
CREATE TABLE IF NOT EXISTS finance_snapshots (county_name TEXT, fy TEXT, approved_budget_m INTEGER, equitable_share_m INTEGER, osr_m INTEGER, osr_target_m INTEGER, absorption REAL, dev_absorption REAL, pending_bills_m INTEGER, audit TEXT, compliance INTEGER, source TEXT, PRIMARY KEY (county_name, fy));
CREATE TABLE IF NOT EXISTS infrastructure (id TEXT PRIMARY KEY, county_code INTEGER REFERENCES county_master(code), asset TEXT, quantity TEXT, fy TEXT, source TEXT);
CREATE TABLE IF NOT EXISTS projects (id TEXT PRIMARY KEY, county_code INTEGER REFERENCES county_master(code), name TEXT, sector TEXT, phase TEXT, budget TEXT, spent TEXT, completion_pct REAL, status TEXT, source TEXT);
CREATE TABLE IF NOT EXISTS governance (county_code INTEGER PRIMARY KEY REFERENCES county_master(code), dpi REAL, dpi_rank INTEGER, petitions TEXT, gender TEXT, civic TEXT, fy TEXT, source TEXT);
CREATE TABLE IF NOT EXISTS procurement (id TEXT PRIMARY KEY, county_code INTEGER REFERENCES county_master(code), tender TEXT, contract_sum TEXT, status TEXT, fy TEXT, source TEXT);
CREATE TABLE IF NOT EXISTS environment (county_code INTEGER PRIMARY KEY REFERENCES county_master(code), nema TEXT, forest TEXT, water TEXT, disasters TEXT, fy TEXT, source TEXT);
CREATE TABLE IF NOT EXISTS elections (county_code INTEGER PRIMARY KEY REFERENCES county_master(code), governor TEXT, party TEXT, votes INTEGER, senator TEXT, woman_rep TEXT, mps TEXT, source TEXT);

-- migrations/002_operational.sql — citizen writes handled by the API backend
CREATE TABLE IF NOT EXISTS feedback (id TEXT PRIMARY KEY, name TEXT, county TEXT, topic TEXT, message TEXT, status TEXT DEFAULT 'Received', created_at INTEGER);
CREATE TABLE IF NOT EXISTS whistleblower_reports (ticket TEXT PRIMARY KEY, category TEXT, county TEXT, ciphertext TEXT, iv TEXT, wrapped_key TEXT, status TEXT DEFAULT 'Queued', created_at INTEGER);
CREATE TABLE IF NOT EXISTS finance_alerts (id TEXT PRIMARY KEY, email TEXT, county TEXT, threshold REAL, created_at INTEGER);
-- migrations/003_county_feeds.sql — county website feed (server/scrape.mjs)
CREATE TABLE IF NOT EXISTS county_sites (code INTEGER PRIMARY KEY, county TEXT, url TEXT, http_status INTEGER, title TEXT, checked_at INTEGER);
CREATE TABLE IF NOT EXISTS fy_reports (id INTEGER PRIMARY KEY AUTOINCREMENT, county_code INTEGER, county TEXT, fy TEXT, title TEXT, url TEXT, kind TEXT, source_page TEXT, found_at INTEGER);
