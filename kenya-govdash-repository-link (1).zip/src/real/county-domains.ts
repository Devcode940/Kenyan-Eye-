// County data domains — mirrors kenya-county-data/ tree:
// data/{counties,demographics,health,education,agriculture,finance,infrastructure,
//       projects,governance,procurement,environment,elections}
// + ingestion/{knbs,treasury,cog,county_portals,validation}
// + backend / frontend / database
//
// RULE: only numbers already published in the bundled OAG / CoB / KNBS /
// parliament.go.ke / IEBC extracts are shown. Everything else is an explicit
// gap with the authoritative source + URL so it can be ingested later.

export type DomainId =
  | "counties"
  | "demographics"
  | "health"
  | "education"
  | "agriculture"
  | "finance"
  | "infrastructure"
  | "projects"
  | "governance"
  | "procurement"
  | "environment"
  | "elections";

export interface DomainSource {
  name: string;
  abbr: string;
  url: string;
  provides: string;
}

export interface DomainMeta {
  id: DomainId;
  folder: string;
  title: string;
  swTitle: string;
  description: string;
  ingestion: string[];
  sources: DomainSource[];
}

export const DOMAIN_REGISTRY: DomainMeta[] = [
  {
    id: "counties", folder: "data/counties", title: "County master & boundaries",
    swTitle: "Kaunti — rejesta na mipaka",
    description: "County code, name, region, HQ, boundary reference (county_master.json + county_boundaries.geojson).",
    ingestion: ["county_portals", "validation"],
    sources: [
      { name: "Constitution of Kenya 2010, Fourth Schedule", abbr: "CoK", url: "https://www.kenyalaw.org/kl/index.php?id=398", provides: "47 counties, functions" },
      { name: "IEBC county codes", abbr: "IEBC", url: "https://www.iebc.or.ke/", provides: "001–047 coding" },
    ],
  },
  {
    id: "demographics", folder: "data/demographics", title: "Demographics",
    swTitle: "Idadi ya watu",
    description: "Population, land area, density, urbanisation — KNBS 2019 Census, all 47 counties.",
    ingestion: ["knbs", "validation"],
    sources: [
      { name: "KNBS 2019 Kenya Population and Housing Census", abbr: "KNBS", url: "https://www.knbs.or.ke/?p=2972", provides: "Population, area, density" },
      { name: "KNBS County Statistical Abstracts", abbr: "KNBS-CSA", url: "https://www.knbs.or.ke/reports/", provides: "County detail tables" },
    ],
  },
  {
    id: "health", folder: "data/health", title: "Health",
    swTitle: "Afya",
    description: "Facilities per 10k, doctor ratios, immunisation, maternal health, health budget per capita.",
    ingestion: ["knbs", "county_portals", "validation"],
    sources: [
      { name: "Kenya Health Information System (KHIS / DHIS2)", abbr: "KHIS", url: "https://hiskenya.org/", provides: "Facility + service stats" },
      { name: "KNBS County Statistical Abstracts", abbr: "KNBS-CSA", url: "https://www.knbs.or.ke/reports/", provides: "Health indicators" },
      { name: "County CIDP III — health sector", abbr: "CIDP", url: "https://cog.go.ke/", provides: "County health plans" },
    ],
  },
  {
    id: "education", folder: "data/education", title: "Education",
    swTitle: "Elimu",
    description: "Enrolment, completion, teacher deployment vs vacancy, ECDE & polytechnic budgets.",
    ingestion: ["knbs", "county_portals", "validation"],
    sources: [
      { name: "Teachers Service Commission", abbr: "TSC", url: "https://www.tsc.go.ke/", provides: "Teacher deployment" },
      { name: "Ministry of Education — Basic Education Statistical Booklet", abbr: "MoE", url: "https://www.education.go.ke/", provides: "Enrolment, completion" },
      { name: "KNBS County Statistical Abstracts", abbr: "KNBS-CSA", url: "https://www.knbs.or.ke/reports/", provides: "Education indicators" },
    ],
  },
  {
    id: "agriculture", folder: "data/agriculture", title: "Agriculture",
    swTitle: "Kilimo",
    description: "Crop + livestock output, extension officers, irrigation, cooperatives, agro-processing.",
    ingestion: ["knbs", "county_portals", "validation"],
    sources: [
      { name: "Ministry of Agriculture — Economic Review of Agriculture", abbr: "MoA", url: "https://www.kilimo.go.ke/", provides: "Crop/livestock output" },
      { name: "Kenya Dairy Board / KEPHIS / KALRO", abbr: "Agencies", url: "https://www.kilimo.go.ke/", provides: "Sub-sector data" },
      { name: "County CIDP III — agriculture sector", abbr: "CIDP", url: "https://cog.go.ke/", provides: "County agri plans" },
    ],
  },
  {
    id: "finance", folder: "data/finance", title: "Finance",
    swTitle: "Fedha",
    description: "Approved budget, equitable share, OSR, absorption, pending bills, audit opinion, compliance.",
    ingestion: ["treasury", "cog", "validation"],
    sources: [
      { name: "Controller of Budget — County BIRR FY 2023/24", abbr: "CoB", url: "https://cob.go.ke/reports/consolidated-county-budget-implementation-review-reports", provides: "Execution, absorption, pending bills" },
      { name: "County Allocation of Revenue Act 2024", abbr: "CARA", url: "https://www.treasury.go.ke/", provides: "Equitable share" },
      { name: "OAG county audit reports", abbr: "OAG", url: "https://oagkenya.go.ke/", provides: "Audit opinions" },
    ],
  },
  {
    id: "infrastructure", folder: "data/infrastructure", title: "Infrastructure",
    swTitle: "Miundombinu",
    description: "Roads (km tarmacked/murram), water connections, electricity access, markets, ECD classrooms.",
    ingestion: ["county_portals", "knbs", "validation"],
    sources: [
      { name: "Kenya Roads Board / KeNHA / KURA / KeRRA", abbr: "Roads", url: "https://www.krb.go.ke/", provides: "Road inventory" },
      { name: "WASREB + county water companies", abbr: "WASREB", url: "https://wasreb.go.ke/", provides: "Water coverage" },
      { name: "Kenya Power / REREC", abbr: "Energy", url: "https://www.kplc.co.ke/", provides: "Electricity access" },
    ],
  },
  {
    id: "projects", folder: "data/projects", title: "Projects (CIDP)",
    swTitle: "Miradi (CIDP)",
    description: "CIDP III 2023–2027 projects: budget vs spent, completion %, milestones, status.",
    ingestion: ["county_portals", "treasury", "validation"],
    sources: [
      { name: "County CIDP III documents", abbr: "CIDP", url: "https://cog.go.ke/", provides: "Project pipeline" },
      { name: "CoB implementation reports", abbr: "CoB", url: "https://cob.go.ke/reports/consolidated-county-budget-implementation-review-reports", provides: "Delivery proxy (dev absorption)" },
    ],
  },
  {
    id: "governance", folder: "data/governance", title: "Governance",
    swTitle: "Utawala",
    description: "DPI ranking, petitions & resolutions, gender compliance, civic participation, border conflicts.",
    ingestion: ["cog", "county_portals", "validation"],
    sources: [
      { name: "OAG + CoB + TI-Kenya + KNBS (DPI composite)", abbr: "DPI", url: "https://cob.go.ke/reports/", provides: "Performance ranking" },
      { name: "County Assembly Hansard", abbr: "Assembly", url: "https://parliament.go.ke/", provides: "Petitions, motions" },
      { name: "Bajeti Hub CBTS", abbr: "CBTS", url: "https://bajetihub.org/", provides: "Transparency scores" },
    ],
  },
  {
    id: "procurement", folder: "data/procurement", title: "Procurement",
    swTitle: "Ununuzi",
    description: "Tenders awarded, contract sums, variations, pending-bill ageing, supplier payments.",
    ingestion: ["treasury", "county_portals", "validation"],
    sources: [
      { name: "Public Procurement Regulatory Authority (PPRA)", abbr: "PPRA", url: "https://www.ppra.go.ke/", provides: "Award data" },
      { name: "CoB pending-bill schedules", abbr: "CoB", url: "https://cob.go.ke/reports/consolidated-county-budget-implementation-review-reports", provides: "Arrears ageing" },
    ],
  },
  {
    id: "environment", folder: "data/environment", title: "Environment",
    swTitle: "Mazingira",
    description: "NEMA compliance, forest cover, water stress, climate budget, disaster events & response.",
    ingestion: ["county_portals", "knbs", "validation"],
    sources: [
      { name: "NEMA State of Environment", abbr: "NEMA", url: "https://nema.go.ke/", provides: "Compliance, approvals" },
      { name: "Kenya Forest Service", abbr: "KFS", url: "https://www.kenyaforestservice.org/", provides: "Forest cover" },
      { name: "NDMA drought bulletins", abbr: "NDMA", url: "https://www.ndma.go.ke/", provides: "Drought/disaster" },
    ],
  },
  {
    id: "elections", folder: "data/elections", title: "Elections & representation",
    swTitle: "Uchaguzi",
    description: "2022 results: governor votes, senator, woman rep, MPs, MCAs — IEBC + parliament.go.ke.",
    ingestion: ["county_portals", "validation"],
    sources: [
      { name: "IEBC 2022 general election results", abbr: "IEBC", url: "https://www.iebc.or.ke/", provides: "Winners, votes" },
      { name: "Parliament of Kenya", abbr: "Parliament", url: "https://www.parliament.go.ke/", provides: "MP/senator profiles" },
    ],
  },
];

export const PIPELINE_STAGES = [
  { id: "knbs", folder: "ingestion/knbs", title: "KNBS ingest", detail: "2019 Census + County Statistical Abstracts → data/demographics, health, education." },
  { id: "treasury", folder: "ingestion/treasury", title: "Treasury / CoB ingest", detail: "BIRR PDFs (tables + regex fallback) → data/finance, procurement, projects." },
  { id: "cog", folder: "ingestion/cog", title: "CoG ingest", detail: "Compliance scores, county status → data/governance, finance." },
  { id: "county_portals", folder: "ingestion/county_portals", title: "County portals + CIDPs", detail: "CIDP III, gazettes, assembly records → data/projects, governance, elections." },
  { id: "validation", folder: "ingestion/validation", title: "Validation", detail: "Source-cited, no estimates: missing = N/A. Cross-check OAG↔CoB↔KNBS." },
];

export const DATABASE_SCHEMA_REF = `database/schema.sql — county_master(code PK, name, region, hq),
demographics, health, education, agriculture, finance_snapshots,
infrastructure, projects(cidp), governance(dpi, petitions),
procurement, environment, elections — see public/data + Stats page.`;
