// Devolution history — from the start of devolution (March 2013) to today.
// SOURCES: IEBC 2013 / 2017 / 2022 general election results; Constitution of
// Kenya 2010; County Governments Act 2012; cross-checked against county records.
// Former-governor names are stable historical facts. Parties are deliberately
// omitted for past terms (defections make them unreliable); 2022-2027 parties
// live in kenya-data.ts (ALL_GOVERNORS, IEBC 2022).

export interface DevolutionTerm {
  id: "2013-2017" | "2017-2022" | "2022-2027";
  label: string;
  electionDate: string;
  swornIn: string;
  president: string;
}

export const DEVOLUTION_TERMS: DevolutionTerm[] = [
  { id: "2013-2017", label: "1st county governments", electionDate: "4 March 2013", swornIn: "27 March 2013", president: "Uhuru Kenyatta (Jubilee)" },
  { id: "2017-2022", label: "2nd county governments", electionDate: "8 August 2017", swornIn: "August 2017", president: "Uhuru Kenyatta (Jubilee)" },
  { id: "2022-2027", label: "3rd county governments (current)", electionDate: "9 August 2022", swornIn: "August 2022", president: "William Ruto (UDA / Kenya Kwanza)" },
];

export interface DevolutionMilestone {
  date: string;
  title: string;
  detail: string;
}

export const DEVOLUTION_MILESTONES: DevolutionMilestone[] = [
  { date: "4 Aug 2010", title: "Constitution referendum", detail: "67% vote YES. Devolution entrenched in Chapter 11; 47 counties created by the First Schedule." },
  { date: "27 Aug 2010", title: "Constitution promulgated", detail: "Devolved system becomes law. Transition to Devolved Government Act (2012) schedules the first county elections." },
  { date: "2012", title: "Devolution laws passed", detail: "County Governments Act, Public Finance Management Act, Urban Areas and Cities Act, Intergovernmental Relations Act." },
  { date: "4 Mar 2013", title: "First county elections", detail: "47 governors, senators, women reps, 1,450 MCAs elected. First devolved funds flow FY 2013/14." },
  { date: "2014–2016", title: "Devolution beds down", detail: "County assemblies, executives and public service boards established; first CIDPs (2013–2017); Senate begins county oversight." },
  { date: "8 Aug 2017", title: "Second county elections", detail: "High turnover: 25+ first-term governors voted out. Second CIDPs (2018–2022)." },
  { date: "2019", title: "KNBS Census", detail: "47.6M people enumerated — the population base still used for revenue sharing and this dashboard's demographics." },
  { date: "Jan 2020", title: "First governor impeachments", detail: "Kiambu's Ferdinand Waititu removed by Senate; deputy James Nyoro succeeds. Nairobi's Mike Sonko follows (Dec 2020)." },
  { date: "9 Aug 2022", title: "Third county elections", detail: "7 women governors elected (record). Third CIDPs (2023–2027). Current term tracked live in this dashboard." },
  { date: "2024–2025", title: "Oversight matures", detail: "OAG audits all 47 executives; CoB quarterly BIRRs; CBTS transparency survey; EACC county probes." },
];

export interface SuccessionEntry {
  code: number;
  countyName: string;
  term1: string;
  term2: string;
  term3: string;
  note?: string;
}

export const GOVERNOR_SUCCESSION: SuccessionEntry[] = [
  { code: 1, countyName: "Mombasa", term1: "Hassan Joho", term2: "Hassan Joho", term3: "Abdulswamad Nassir", note: "Joho served the maximum two terms (2013–2022)." },
  { code: 2, countyName: "Kwale", term1: "Salim Mvurya", term2: "Salim Mvurya", term3: "Fatuma Achani", note: "Mvurya served two terms; Achani is the Coast's first woman governor." },
  { code: 3, countyName: "Kilifi", term1: "Amason Kingi", term2: "Amason Kingi", term3: "Gideon Mung'aro", note: "Kingi served two terms, then elected Senate Speaker (2022)." },
  { code: 4, countyName: "Tana River", term1: "Hussein Dado", term2: "Dhadho Godhana", term3: "Dhadho Godhana" },
  { code: 5, countyName: "Lamu", term1: "Issa Timamy", term2: "Fahim Twaha", term3: "Issa Timamy", note: "Comeback: Timamy lost 2017, won again 2022." },
  { code: 6, countyName: "Taita Taveta", term1: "John Mruttu", term2: "Granton Samboja", term3: "Andrew Mwadime" },
  { code: 7, countyName: "Garissa", term1: "Nathif Jama", term2: "Ali Korane", term3: "Nathif Jama", note: "Comeback: Jama lost 2017, won again 2022." },
  { code: 8, countyName: "Wajir", term1: "Ahmed Abdullahi", term2: "Mohamed Abdi", term3: "Ahmed Abdullahi", note: "Comeback: Abdullahi lost 2017, won again 2022." },
  { code: 9, countyName: "Mandera", term1: "Ali Roba", term2: "Ali Roba", term3: "Mohamed Adan Khalif" },
  { code: 10, countyName: "Marsabit", term1: "Ukur Yatani", term2: "Mohamud Ali", term3: "Mohamud Ali", note: "Yatani left to become National Treasury Cabinet Secretary." },
  { code: 11, countyName: "Isiolo", term1: "Godana Doyo", term2: "Mohamed Kuti", term3: "Abdi Hassan Guyo" },
  { code: 12, countyName: "Meru", term1: "Peter Munya", term2: "Kiraitu Murungi", term3: "Kawira Mwangaza", note: "Munya became Trade CS; Murungi lost re-election 2022." },
  { code: 13, countyName: "Tharaka Nithi", term1: "Samuel Ragwa", term2: "Muthomi Njuki", term3: "Muthomi Njuki" },
  { code: 14, countyName: "Embu", term1: "Martin Wambora", term2: "Martin Wambora", term3: "Cecily Mbarire" },
  { code: 15, countyName: "Kitui", term1: "Julius Malombe", term2: "Charity Ngilu", term3: "Julius Malombe", note: "Comeback: Malombe lost 2017, won again 2022." },
  { code: 16, countyName: "Machakos", term1: "Alfred Mutua", term2: "Alfred Mutua", term3: "Wavinya Ndeti" },
  { code: 17, countyName: "Makueni", term1: "Kivutha Kibwana", term2: "Kivutha Kibwana", term3: "Mutula Kilonzo Jr" },
  { code: 18, countyName: "Nyandarua", term1: "Daniel Waithaka", term2: "Francis Kimemia", term3: "Moses Badilisha Kiarie" },
  { code: 19, countyName: "Nyeri", term1: "Nderitu Gachagua", term2: "Mutahi Kahiga", term3: "Mutahi Kahiga", note: "Gachagua died Feb 2017; deputy Samuel Wamathai completed the term." },
  { code: 20, countyName: "Kirinyaga", term1: "Joseph Ndathi", term2: "Anne Waiguru", term3: "Anne Waiguru" },
  { code: 21, countyName: "Murang'a", term1: "Mwangi wa Iria", term2: "Mwangi wa Iria", term3: "Irungu Kang'ata" },
  { code: 22, countyName: "Kiambu", term1: "William Kabogo", term2: "Ferdinand Waititu", term3: "Kimani Wamatangi", note: "Waititu impeached Jan 2020; deputy James Nyoro completed 2020–2022." },
  { code: 23, countyName: "Turkana", term1: "Josphat Nanok", term2: "Josphat Nanok", term3: "Jeremiah Lomurukai" },
  { code: 24, countyName: "West Pokot", term1: "Simon Kachapin", term2: "John Lonyangapuo", term3: "Simon Kachapin", note: "Comeback: Kachapin lost 2017, won again 2022." },
  { code: 25, countyName: "Samburu", term1: "Moses Lenolkulal", term2: "Moses Lenolkulal", term3: "Jonathan Lati Leleliit" },
  { code: 26, countyName: "Trans-Nzoia", term1: "Patrick Khaemba", term2: "Patrick Khaemba", term3: "George Natembeya" },
  { code: 27, countyName: "Uasin Gishu", term1: "Jackson Mandago", term2: "Jackson Mandago", term3: "Jonathan Bii" },
  { code: 28, countyName: "Elgeyo-Marakwet", term1: "Alex Tolgos", term2: "Alex Tolgos", term3: "Wisley Rotich" },
  { code: 29, countyName: "Nandi", term1: "Cleophas Lagat", term2: "Stephen Sang", term3: "Stephen Sang", note: "Sang, elected at 32 in 2017, was Kenya's youngest governor." },
  { code: 30, countyName: "Baringo", term1: "Benjamin Cheboi", term2: "Stanley Kiptis", term3: "Benjamin Cheboi", note: "Comeback: Cheboi lost 2017, won again 2022." },
  { code: 31, countyName: "Laikipia", term1: "Joshua Irungu", term2: "Ndiritu Muriithi", term3: "Joshua Irungu", note: "Comeback: Irungu lost 2017, won again 2022." },
  { code: 32, countyName: "Nakuru", term1: "Kinuthia Mbugua", term2: "Lee Kinyanjui", term3: "Susan Kihika" },
  { code: 33, countyName: "Narok", term1: "Samuel Tunai", term2: "Samuel Tunai", term3: "Patrick Ole Ntutu" },
  { code: 34, countyName: "Kajiado", term1: "David Nkedianye", term2: "Joseph Ole Lenku", term3: "Joseph Ole Lenku" },
  { code: 35, countyName: "Kericho", term1: "Paul Chepkwony", term2: "Paul Chepkwony", term3: "Erick Kipkoech Mutai" },
  { code: 36, countyName: "Bomet", term1: "Isaac Ruto", term2: "Joyce Laboso", term3: "Hillary Barchok", note: "Laboso died Jul 2019; deputy Barchok succeeded, then won 2022." },
  { code: 37, countyName: "Kakamega", term1: "Wycliffe Oparanya", term2: "Wycliffe Oparanya", term3: "Fernandes Barasa", note: "Oparanya later chaired the Council of Governors." },
  { code: 38, countyName: "Vihiga", term1: "Moses Akaranga", term2: "Wilber Ottichilo", term3: "Wilber Ottichilo" },
  { code: 39, countyName: "Bungoma", term1: "Ken Lusaka", term2: "Wycliffe Wangamati", term3: "Ken Lusaka", note: "Comeback: Lusaka lost 2017, won again 2022; ex-Senate Speaker." },
  { code: 40, countyName: "Busia", term1: "Sospeter Ojaamong", term2: "Sospeter Ojaamong", term3: "Paul Otuoma" },
  { code: 41, countyName: "Siaya", term1: "Cornel Rasanga", term2: "Cornel Rasanga", term3: "James Orengo" },
  { code: 42, countyName: "Kisumu", term1: "Jack Ranguma", term2: "Anyang' Nyong'o", term3: "Anyang' Nyong'o" },
  { code: 43, countyName: "Homa Bay", term1: "Cyprian Awiti", term2: "Cyprian Awiti", term3: "Gladys Wanga" },
  { code: 44, countyName: "Migori", term1: "Okoth Obado", term2: "Okoth Obado", term3: "Ochilo Ayacko" },
  { code: 45, countyName: "Kisii", term1: "James Ongwae", term2: "James Ongwae", term3: "Simba Arati" },
  { code: 46, countyName: "Nyamira", term1: "John Nyagarama", term2: "Amos Nyaribo", term3: "Amos Nyaribo", note: "Nyagarama died Dec 2020; deputy Nyaribo succeeded, then won 2022." },
  { code: 47, countyName: "Nairobi City", term1: "Evans Kidero", term2: "Mike Sonko", term3: "Johnson Sakaja", note: "Sonko impeached Dec 2020; Anne Kananu acted 2021–2022." },
];

export function getSuccession(code: number): SuccessionEntry | undefined {
  return GOVERNOR_SUCCESSION.find((s) => s.code === code);
}

export const HISTORY_SOURCES = [
  { abbr: "IEBC", name: "IEBC election results 2013 · 2017 · 2022", url: "https://www.iebc.or.ke/" },
  { abbr: "CoK", name: "Constitution of Kenya 2010", url: "https://www.kenyalaw.org/kl/index.php?id=398" },
  { abbr: "CoB archive", name: "CoB budget implementation reports 2013→", url: "https://cob.go.ke/reports/consolidated-county-budget-implementation-review-reports" },
  { abbr: "OAG", name: "OAG county audit reports archive", url: "https://oagkenya.go.ke/" },
  { abbr: "Senate", name: "Senate Hansard (impeachments, oversight)", url: "https://www.parliament.go.ke/the-senate/house-business/hansard" },
];
