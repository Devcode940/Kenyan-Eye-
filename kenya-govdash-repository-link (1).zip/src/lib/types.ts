export type AuditOpinion = "Unmodified" | "Qualified" | "Adverse" | "Disclaimer" | "Not Audited";
export type Coalition = "Kenya Kwanza" | "Azimio" | "Independent" | "Other";
export type Level = "National" | "County" | "Constituency" | "Ward";
export type Region =
  | "Coast"
  | "North Eastern"
  | "Eastern"
  | "Central"
  | "Rift Valley"
  | "Western"
  | "Nyanza"
  | "Nairobi";

export interface Person {
  id: string;
  name: string;
  title: string;
  party: string;
  coalition: Coalition;
  level: Level;
  jurisdiction: string;
  countyCode?: number;
  termStart: string;
  termEnd: string;
  bio?: string | null;
  bioSource?: string | null;
  email?: string | null;
  phone?: string | null;
  twitter?: string | null;
  website?: string | null;
  verified?: boolean;
}

export interface County {
  code: number;
  name: string;
  region: Region;
  population: number;
  area: number;
  density: number;
  governor: Person;
  deputyGovernor?: Person;
  senator?: Person;
  womanRep?: Person;
  mps: Person[];
  cecms: Person[];
  countySecretary?: Person;
  countyAttorney?: Person;
}

export interface CountyFinance {
  countyName: string;
  fiscalYear: string;
  approvedBudget: number;
  equitableShare: number;
  osrTarget: number;
  ownSourceRevenue?: number;
  actualExpenditure?: number;
  recurrentExpenditure?: number;
  developmentExpenditure?: number;
  overallAbsorption?: number;
  recurrentAbsorption?: number;
  developmentAbsorption?: number;
  auditOpinion: AuditOpinion;
  pendingBills?: number;
  complianceScore?: number;
  notes?: string;
  source: string;
}

export interface NationalFinance {
  fiscalYear: string;
  approvedBudget: number;
  actualExpenditure: number;
  recurrentExpenditure: number;
  developmentExpenditure: number;
  overallAbsorption: number;
  recurrentAbsorption: number;
  developmentAbsorption: number;
  pendingBills: number;
  totalDebt: number;
  auditOpinion: AuditOpinion;
  notes?: string;
  source: string;
}

export type PageId =
  | "home"
  | "county"
  | "finance"
  | "finance-county"
  | "reps"
  | "rep"
  | "senate"
  | "history"
  | "reports"
  | "compare"
  | "search"
  | "stats"
  | "feedback"
  | "whistleblower"
  | "ai"
  | "admin"
  | "oversight";

export interface RouteState {
  page: PageId;
  params: Record<string, string>;
  query: Record<string, string>;
}
