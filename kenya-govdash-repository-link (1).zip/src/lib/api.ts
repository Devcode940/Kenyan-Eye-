// API client — uses the SQLite backend when reachable, falls back to
// bundled data + localStorage when running as a static site.
// Configure: VITE_API_URL env, or Admin → Backend tab → Backend URL.

export function apiBase(): string {
  try {
    const saved = localStorage.getItem("kgd-api-url") || "";
    if (saved) return saved.replace(/\/$/, "");
  } catch { /* ignore */ }
  const env = (import.meta as any).env?.VITE_API_URL as string | undefined;
  return (env || "").replace(/\/$/, "");
}

async function req<T>(path: string, init?: RequestInit, timeoutMs = 4000): Promise<T> {
  const base = apiBase();
  if (!base) throw new Error("no-backend-configured");
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const r = await fetch(`${base}${path}`, { ...init, signal: ctrl.signal, headers: { "Content-Type": "application/json", ...(init?.headers || {}) } });
    if (!r.ok) throw new Error(`backend-${r.status}`);
    return (await r.json()) as T;
  } finally {
    clearTimeout(t);
  }
}

export async function backendHealth(): Promise<{ ok: boolean; counts?: Record<string, number>; url: string }> {
  const base = apiBase();
  if (!base) return { ok: false, url: "" };
  try {
    const h = await req<{ ok: boolean; counts: Record<string, number> }>("/api/health");
    return { ok: h.ok, counts: h.counts, url: base };
  } catch {
    return { ok: false, url: base };
  }
}

export interface BackendSite { code: number; county: string; url: string; http_status: number | null; title: string | null; checked_at: number | null; }
export async function listSites(): Promise<{ via: "backend" | "local"; sites: BackendSite[] }> {
  try {
    const r = await req<{ sites: BackendSite[] }>("/api/sites");
    return { via: "backend", sites: r.sites };
  } catch {
    return { via: "local", sites: [] };
  }
}

export interface BackendReport { id: number; county_code: number | null; county: string | null; fy: string | null; title: string; url: string; kind: string | null; source_page: string | null; found_at: number | null; }
export async function listReports(fy?: string, county?: string): Promise<{ via: "backend" | "local"; reports: BackendReport[] }> {
  try {
    const qs = new URLSearchParams();
    if (fy) qs.set("fy", fy);
    if (county) qs.set("county", county);
    const r = await req<{ reports: BackendReport[] }>(`/api/reports?${qs.toString()}`);
    return { via: "backend", reports: r.reports };
  } catch {
    return { via: "local", reports: [] };
  }
}

function localGet<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch { return fallback; }
}
function localSet(key: string, val: unknown) {
  try { localStorage.setItem(key, JSON.stringify(val)); } catch { /* ignore */ }
}

// ---------- feedback ----------
export interface FeedbackPayload { name: string; county: string; topic: string; message: string; }
export async function submitFeedback(p: FeedbackPayload): Promise<{ via: "backend" | "local"; id: string }> {
  try {
    const r = await req<{ id: string }>("/api/feedback", { method: "POST", body: JSON.stringify(p) });
    return { via: "backend", id: r.id };
  } catch {
    const row = { ...p, id: crypto.randomUUID(), status: "Received", at: Date.now() };
    const all = [row, ...localGet<any[]>("kgd-feedback", [])];
    localSet("kgd-feedback", all);
    return { via: "local", id: row.id };
  }
}
export async function listFeedback(): Promise<{ via: "backend" | "local"; items: any[] }> {
  try {
    const r = await req<{ feedback: any[] }>("/api/feedback");
    return { via: "backend", items: r.feedback };
  } catch {
    return { via: "local", items: localGet<any[]>("kgd-feedback", []) };
  }
}

// ---------- whistleblower (envelope stays ciphertext-only either way) ----------
export interface WbEnvelope { category: string; county: string; ciphertext: string; iv: string; wrappedKey: string; }
export async function submitEnvelope(e: WbEnvelope): Promise<{ via: "backend" | "local"; ticket: string }> {
  try {
    const r = await req<{ ticket: string }>("/api/whistleblower", { method: "POST", body: JSON.stringify(e) });
    return { via: "backend", ticket: r.ticket };
  } catch {
    const ticket = `WB-${Math.random().toString(36).slice(2, 8).toUpperCase()}`;
    const store = localGet<any[]>("kgd-wb", []);
    store.push({ id: ticket, ...e, status: "Queued — local only", at: Date.now() });
    localSet("kgd-wb", store);
    return { via: "local", ticket };
  }
}
export async function trackTicket(ticket: string): Promise<string> {
  const t = ticket.trim().toUpperCase();
  try {
    const r = await req<{ ticket: string; status: string }>("/api/whistleblower/status?ticket=" + encodeURIComponent(t));
    return `${r.ticket} · ${r.status} (backend)`;
  } catch {
    const hit = localGet<any[]>("kgd-wb", []).find((s) => s.id === t);
    return hit ? `${hit.id} · ${hit.status}` : "No ticket found";
  }
}

// ---------- finance alerts ----------
export async function createAlert(a: { email: string; county: string; threshold: number }): Promise<{ via: "backend" | "local" }> {
  try {
    await req("/api/alerts", { method: "POST", body: JSON.stringify(a) });
    return { via: "backend" };
  } catch {
    const list = localGet<any[]>("kgd-alerts", []);
    list.push({ ...a, at: Date.now() });
    localSet("kgd-alerts", list);
    return { via: "local" };
  }
}
