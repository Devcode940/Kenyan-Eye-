// Firebase Authentication (Google) — optional, configured via env.
//   VITE_FIREBASE_API_KEY, VITE_FIREBASE_AUTH_DOMAIN, VITE_FIREBASE_PROJECT_ID,
//   VITE_FIREBASE_APP_ID (+ optional VITE_FIREBASE_MESSAGING_SENDER_ID)
// Without config the app runs signed-out; the sign-in button opens setup steps.
// See Admin → Backend tab for the 5-minute Firebase setup guide.
import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import type { User } from "firebase/auth";

export interface AuthState {
  configured: boolean;
  user: User | null;
  initializing: boolean;
  signInWithGoogle: () => Promise<void>;
  signOut: () => Promise<void>;
  error: string | null;
}

const AuthContext = createContext<AuthState>({
  configured: false, user: null, initializing: false,
  signInWithGoogle: async () => {}, signOut: async () => {}, error: null,
});

function readConfig() {
  const env = (import.meta as any).env ?? {};
  const apiKey = env.VITE_FIREBASE_API_KEY as string | undefined;
  const authDomain = env.VITE_FIREBASE_AUTH_DOMAIN as string | undefined;
  const projectId = env.VITE_FIREBASE_PROJECT_ID as string | undefined;
  const appId = env.VITE_FIREBASE_APP_ID as string | undefined;
  if (!apiKey || !authDomain || !projectId || !appId) return null;
  return {
    apiKey, authDomain, projectId, appId,
    messagingSenderId: (env.VITE_FIREBASE_MESSAGING_SENDER_ID as string | undefined) ?? "",
  };
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [initializing, setInitializing] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [auth, setAuth] = useState<any>(null);
  const [provider, setProvider] = useState<any>(null);

  useEffect(() => {
    let unsub: (() => void) | null = null;
    (async () => {
      try {
        const config = readConfig();
        if (!config) { setInitializing(false); return; }
        const { initializeApp, getApps } = await import("firebase/app");
        const { getAuth, GoogleAuthProvider, onAuthStateChanged } = await import("firebase/auth");
        const app = getApps().length ? getApps()[0] : initializeApp(config);
        const a = getAuth(app);
        setAuth(a);
        setProvider(new GoogleAuthProvider());
        unsub = onAuthStateChanged(a, (u) => { setUser(u); setInitializing(false); });
      } catch (e: any) {
        setError(e?.message ?? "Firebase init failed");
        setInitializing(false);
      }
    })();
    return () => { if (unsub) unsub(); };
  }, []);

  const value = useMemo<AuthState>(() => ({
    configured: Boolean(auth),
    user, initializing, error,
    signInWithGoogle: async () => {
      setError(null);
      if (!auth || !provider) { setError("not-configured"); return; }
      try {
        const { signInWithPopup } = await import("firebase/auth");
        await signInWithPopup(auth, provider);
      } catch (e: any) {
        if (e?.code !== "auth/popup-closed-by-user") setError(e?.message ?? "Sign-in failed");
      }
    },
    signOut: async () => {
      setError(null);
      if (!auth) return;
      try {
        const { signOut: fbOut } = await import("firebase/auth");
        await fbOut(auth);
      } catch (e: any) {
        setError(e?.message ?? "Sign-out failed");
      }
    },
  }), [auth, provider, user, initializing, error]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  return useContext(AuthContext);
}
