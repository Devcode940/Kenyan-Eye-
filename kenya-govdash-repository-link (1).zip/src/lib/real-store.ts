import {
  buildAllCountyData,
  getCountyDemographics,
  getDataQualityScore,
  NATIONAL_SUMMARY,
  ALL_GOVERNORS,
  filterCounties,
  searchRepresentatives,
  flattenAllCountiesRepresentatives,
  getRepresentativeById,
  getCountyByCode,
  type CountyData,
  type Representative,
  type RegionType,
  type CoalitionType,
} from "../real/kenya-data";

import {
  NATIONAL_FINANCE,
  COUNTY_FINANCE,
  COUNTY_FINANCE_HISTORICAL,
  ALL_COUNTY_FINANCE,
  getAggregateStats,
  getAllCountyFinance,
  getCountyFinance,
  getCountyTimeSeries,
  getAvailableFiscalYears,
  getCountiesWithFinanceData,
  getFinanceCoverage,
  formatKshs,
  type CountyFinanceRecord,
} from "../real/finance-audit-data";

import * as MPS from "../real/kenya-parliament-mps";
import * as SEN from "../real/kenya-parliament-senators";
import * as WR from "../real/kenya-parliament-women-reps";
import {
  petitionData,
  getPetitionsForCounty,
  cidpProjectData,
  getCidpForCounty,
  revenueAutonomyData,
  getRevenueForCounty,
  genderInclusionData,
  getGenderInclusionForCounty,
  borderConflictData,
  getConflictsForCounty,
  climateEnvironmentData,
  getClimateForCounty,
  serviceDeliveryData,
  getServiceDeliveryForCounty,
  dpiData,
  getDpiForCounty,
  budgetQuarterlyData,
  getBudgetQuarterlyForCounty,
  civicParticipationData,
  getCivicParticipationForCounty,
  KENYA_OVERSIGHT_FEATURES,
} from "../real/kenya-oversight-data";

import sitesJson from "../../data/county-sites.json";

// ---------- cached county data ----------
let _counties: CountyData[] | null = null;
export function allCounties(): CountyData[] {
  if (!_counties) _counties = buildAllCountyData();
  return _counties;
}

export interface CountySite { code: number; county: string; url: string; verifiedIn?: string }
export function countySites(): CountySite[] {
  return (sitesJson as { sites: CountySite[] }).sites;
}
export function siteForCounty(code: number): CountySite | null {
  return countySites().find((s) => s.code === code) ?? null;
}

// ---------- parliament aggregations ----------
function collectArrays(mod: Record<string, unknown>): { countyName: string; countyCode: number; fullName: string; officialTitle: string; party: string; coalition: CoalitionType; jurisdiction: string; profileUrl: string; id: string; status?: string }[] {
  const out: any[] = [];
  for (const [k, v] of Object.entries(mod)) {
    if (k.endsWith("_MPS") || k.endsWith("_SENATORS") || k.endsWith("_WOMEN") || k.endsWith("_WOMEN_REPS") || k.includes("SENATORS") || k.includes("WOMEN")) {
      if (Array.isArray(v)) out.push(...v);
    }
  }
  if (out.length === 0) {
    for (const v of Object.values(mod)) {
      if (Array.isArray(v) && v.length > 0 && typeof v[0] === "object" && v[0] !== null && "fullName" in (v[0] as any)) {
        out.push(...(v as any[]));
      }
    }
  }
  return out;
}

let _mps: ReturnType<typeof collectArrays> | null = null;
export function allMPs() {
  if (!_mps) _mps = collectArrays(MPS as any);
  return _mps;
}

let _senators: ReturnType<typeof collectArrays> | null = null;
export function allSenators() {
  if (!_senators) _senators = collectArrays(SEN as any);
  return _senators;
}

let _women: ReturnType<typeof collectArrays> | null = null;
export function allWomenReps() {
  if (!_women) _women = collectArrays(WR as any);
  return _women;
}

export function mpsForCounty(code: number) {
  return allMPs().filter((m) => m.countyCode === code);
}
export function senatorForCounty(code: number) {
  return allSenators().find((m) => m.countyCode === code) ?? null;
}
export function womanRepForCounty(code: number) {
  return allWomenReps().find((m) => m.countyCode === code) ?? null;
}

// ---------- search ----------
export function realSearch(q: string): { counties: CountyData[]; reps: Representative[]; mps: ReturnType<typeof collectArrays>; senators: ReturnType<typeof collectArrays>; women: ReturnType<typeof collectArrays> } {
  const s = q.trim().toLowerCase();
  if (!s) return { counties: [], reps: [], mps: [], senators: [], women: [] };
  const counties = allCounties().filter((c) =>
    `${c.name} ${c.region} ${c.governor.fullName} ${c.governor.party}`.toLowerCase().includes(s),
  );
  const reps = searchRepresentatives(s);
  const mps = allMPs().filter((m) => `${m.fullName} ${m.officialTitle} ${m.party} ${m.jurisdiction} ${m.countyName}`.toLowerCase().includes(s));
  const senators = allSenators().filter((m) => `${m.fullName} ${m.party} ${m.countyName}`.toLowerCase().includes(s));
  const women = allWomenReps().filter((m) => `${m.fullName} ${m.party} ${m.countyName}`.toLowerCase().includes(s));
  return { counties, reps, mps, senators, women };
}

// ---------- finance helpers ----------
export function linearForecast(values: number[]): number | null {
  const clean = values.filter((v) => typeof v === "number" && !Number.isNaN(v));
  if (clean.length < 2) return null;
  const n = clean.length;
  const xs = clean.map((_, i) => i);
  const xMean = xs.reduce((a, b) => a + b, 0) / n;
  const yMean = clean.reduce((a, b) => a + b, 0) / n;
  let num = 0;
  let den = 0;
  for (let i = 0; i < n; i++) {
    num += (xs[i] - xMean) * (clean[i] - yMean);
    den += (xs[i] - xMean) ** 2;
  }
  if (den === 0) return clean[n - 1];
  const slope = num / den;
  const intercept = yMean - slope * xMean;
  return Math.round((intercept + slope * n) * 10) / 10;
}

export {
  buildAllCountyData,
  getCountyDemographics,
  getDataQualityScore,
  NATIONAL_SUMMARY,
  ALL_GOVERNORS,
  filterCounties,
  searchRepresentatives,
  flattenAllCountiesRepresentatives,
  getRepresentativeById,
  getCountyByCode,
  NATIONAL_FINANCE,
  COUNTY_FINANCE,
  COUNTY_FINANCE_HISTORICAL,
  ALL_COUNTY_FINANCE,
  getAggregateStats,
  getAllCountyFinance,
  getCountyFinance,
  getCountyTimeSeries,
  getAvailableFiscalYears,
  getCountiesWithFinanceData,
  getFinanceCoverage,
  formatKshs,
  petitionData,
  getPetitionsForCounty,
  cidpProjectData,
  getCidpForCounty,
  revenueAutonomyData,
  getRevenueForCounty,
  genderInclusionData,
  getGenderInclusionForCounty,
  borderConflictData,
  getConflictsForCounty,
  climateEnvironmentData,
  getClimateForCounty,
  serviceDeliveryData,
  getServiceDeliveryForCounty,
  dpiData,
  getDpiForCounty,
  budgetQuarterlyData,
  getBudgetQuarterlyForCounty,
  civicParticipationData,
  getCivicParticipationForCounty,
  KENYA_OVERSIGHT_FEATURES,
};
export type { CountyData, Representative, RegionType, CoalitionType, CountyFinanceRecord };
