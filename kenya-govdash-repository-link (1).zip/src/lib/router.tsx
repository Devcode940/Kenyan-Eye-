import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import type { PageId, RouteState } from "./types";

function parseHash(): RouteState {
  const raw = (window.location.hash.replace(/^#/, "") || "/").trim();
  const [pathPart, qs] = raw.split("?");
  const parts = pathPart.split("/").filter(Boolean);
  const query: Record<string, string> = {};
  if (qs) {
    new URLSearchParams(qs).forEach((v, k) => {
      query[k] = v;
    });
  }
  const head = parts[0];
  if (!head) return { page: "home", params: {}, query };
  if (head === "county" && parts[1]) return { page: "county", params: { code: parts[1] }, query };
  if (head === "finance" && parts[1] === "county" && parts[2])
    return { page: "finance-county", params: { name: decodeURIComponent(parts[2]) }, query };
  if (head === "finance") return { page: "finance", params: {}, query };
  if (head === "representatives") return { page: "reps", params: {}, query };
  if (head === "senate") return { page: "senate", params: {}, query };
  if (head === "history") return { page: "history", params: {}, query };
  if (head === "reports") return { page: "reports", params: {}, query };
  if (head === "representative" && parts[1]) return { page: "rep", params: { id: decodeURIComponent(parts[1]) }, query };
  if (head === "compare") return { page: "compare", params: {}, query };
  if (head === "search") return { page: "search", params: {}, query };
  if (head === "stats") return { page: "stats", params: {}, query };
  if (head === "feedback") return { page: "feedback", params: {}, query };
  if (head === "whistleblower") return { page: "whistleblower", params: {}, query };
  if (head === "ai") return { page: "ai", params: {}, query };
  if (head === "admin") return { page: "admin", params: {}, query };
  if (head === "oversight") return { page: "oversight", params: { section: parts[1] || "pending-bills" }, query };
  return { page: "home", params: {}, query };
}

function toHash(page: PageId, params: Record<string, string> = {}, query: Record<string, string> = {}): string {
  let path = "/";
  switch (page) {
    case "home": path = "/"; break;
    case "county": path = `/county/${params.code}`; break;
    case "finance": path = "/finance"; break;
    case "finance-county": path = `/finance/county/${encodeURIComponent(params.name)}`; break;
    case "reps": path = "/representatives"; break;
    case "senate": path = "/senate"; break;
    case "history": path = "/history"; break;
    case "reports": path = "/reports"; break;
    case "rep": path = `/representative/${encodeURIComponent(params.id)}`; break;
    case "compare": path = "/compare"; break;
    case "search": path = "/search"; break;
    case "stats": path = "/stats"; break;
    case "feedback": path = "/feedback"; break;
    case "whistleblower": path = "/whistleblower"; break;
    case "ai": path = "/ai"; break;
    case "admin": path = "/admin"; break;
    case "oversight": path = `/oversight/${params.section || "pending-bills"}`; break;
  }
  const qs = new URLSearchParams(query).toString();
  return "#" + path + (qs ? `?${qs}` : "");
}

interface RouterValue {
  route: RouteState;
  navigate: (page: PageId, params?: Record<string, string>, query?: Record<string, string>) => void;
}

const RouterContext = createContext<RouterValue | null>(null);

export function RouterProvider({ children }: { children: ReactNode }) {
  const [route, setRoute] = useState<RouteState>(() => (typeof window === "undefined" ? { page: "home", params: {}, query: {} } : parseHash()));

  useEffect(() => {
    const onHash = () => setRoute(parseHash());
    window.addEventListener("hashchange", onHash);
    if (!window.location.hash) window.location.hash = "#/";
    return () => window.removeEventListener("hashchange", onHash);
  }, []);

  const navigate = useCallback((page: PageId, params: Record<string, string> = {}, query: Record<string, string> = {}) => {
    const next = toHash(page, params, query);
    if (window.location.hash !== next) window.location.hash = next;
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, []);

  const value = useMemo(() => ({ route, navigate }), [route, navigate]);
  return <RouterContext.Provider value={value}>{children}</RouterContext.Provider>;
}

export function useRouter() {
  const ctx = useContext(RouterContext);
  if (!ctx) throw new Error("useRouter must be used within RouterProvider");
  return ctx;
}
