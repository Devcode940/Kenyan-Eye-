import { LanguageProvider } from "./lib/i18n";
import { RouterProvider, useRouter } from "./lib/router";
import { ThemeProvider } from "./lib/theme";
import { AuthProvider } from "./lib/auth";
import { Layout } from "./components/Layout";
import { HomePage } from "./pages/Home";
import { CountyPage, RepPage } from "./pages/County";
import { ComparePage, FinanceCountyPage, FinancePage } from "./pages/Finance";
import { RepsPage } from "./pages/Reps";
import { SenatePage } from "./pages/Senate";
import { HistoryPage } from "./pages/History";
import { ReportsPage } from "./pages/Reports";
import { AdminPage, AIPage, FeedbackPage, OversightPage, SearchPage, StatsPage, WhistleblowerPage } from "./pages/Civic";

function Screen() {
  const { route } = useRouter();
  switch (route.page) {
    case "county": return <CountyPage code={route.params.code} />;
    case "finance": return <FinancePage />;
    case "finance-county": return <FinanceCountyPage name={route.params.name} />;
    case "reps": return <RepsPage />;
    case "rep": return <RepPage id={route.params.id} />;
    case "senate": return <SenatePage />;
    case "history": return <HistoryPage />;
    case "reports": return <ReportsPage />;
    case "compare": return <ComparePage />;
    case "search": return <SearchPage />;
    case "stats": return <StatsPage />;
    case "feedback": return <FeedbackPage />;
    case "whistleblower": return <WhistleblowerPage />;
    case "ai": return <AIPage />;
    case "admin": return <AdminPage />;
    case "oversight": return <OversightPage section={route.params.section} />;
    default: return <HomePage />;
  }
}

export default function App() {
  return (
    <ThemeProvider>
      <LanguageProvider>
        <AuthProvider>
          <RouterProvider>
            <Layout>
              <Screen />
            </Layout>
          </RouterProvider>
        </AuthProvider>
      </LanguageProvider>
    </ThemeProvider>
  );
}
