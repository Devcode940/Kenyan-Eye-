import { getSuccession, DEVOLUTION_TERMS } from "../real/devolution-history";
import { Card, DataGap, SectionTitle } from "./ui";

export function CountyHistory({ code }: { code: number }) {
  const s = getSuccession(code);
  if (!s) return null;
  const terms = [
    { term: DEVOLUTION_TERMS[0], name: s.term1 },
    { term: DEVOLUTION_TERMS[1], name: s.term2 },
    { term: DEVOLUTION_TERMS[2], name: s.term3 },
  ];
  return (
    <Card className="p-5">
      <SectionTitle kicker="Since 2013 · IEBC" title="Leadership succession — three devolution terms" />
      <div className="relative grid gap-3 sm:grid-cols-3">
        {terms.map(({ term, name }, i) => (
          <div key={term.id} className="relative rounded-2xl border border-border p-4">
            <p className="text-[10px] font-semibold uppercase tracking-[0.16em] text-muted-foreground">{term.id}</p>
            <p className="mt-1 font-display text-lg leading-snug">{name}</p>
            <p className="mt-1 text-xs text-muted-foreground">Elected {term.electionDate}</p>
            {i === 2 && <span className="mt-2 inline-block rounded-full bg-ke-green px-2 py-0.5 text-[10px] font-semibold text-white">Current term</span>}
          </div>
        ))}
      </div>
      {s.note ? (
        <p className="mt-3 rounded-xl bg-amber-50 p-3 text-sm text-amber-950 dark:bg-amber-950/30 dark:text-amber-100">{s.note}</p>
      ) : (
        <div className="mt-3"><DataGap note="Succession per IEBC 2013 / 2017 / 2022 results. Parties omitted for past terms (defections); 2022–2027 parties on the leadership panel." /></div>
      )}
    </Card>
  );
}
