import { useMemo, useState } from "react";
import { ExternalLink } from "lucide-react";
import { DOMAIN_REGISTRY, PIPELINE_STAGES, type DomainId } from "../real/county-domains";
import { getSuccession } from "../real/devolution-history";
import {
  getCountyByCode, getCountyDemographics, getCountyFinance, getCountyTimeSeries,
  getServiceDeliveryForCounty, getCidpForCounty, getDpiForCounty, getRevenueForCounty,
  getPetitionsForCounty, getGenderInclusionForCounty, getCivicParticipationForCounty,
  getClimateForCounty, getConflictsForCounty, mpsForCounty, senatorForCounty, womanRepForCounty,
  formatKshs, allCounties, siteForCounty,
} from "../lib/real-store";
import { formatPopulation } from "../real/kenya-data";
import { useRouter } from "../lib/router";
import { Card, DataGap, SectionTitle } from "./ui";
import { cn } from "../utils/cn";

function SourceLinks({ sources }: { sources: { name: string; url: string; abbr: string }[] }) {
  return (
    <div className="mt-3 flex flex-wrap gap-2">
      {sources.map((s) => (
        <a key={s.abbr} href={s.url} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 rounded-full border border-border px-2.5 py-1 text-[11px] hover:bg-muted">
          {s.abbr} <ExternalLink className="h-3 w-3" />
        </a>
      ))}
    </div>
  );
}

function Row({ k, v }: { k: string; v: string }) {
  return (
    <div className="flex items-center justify-between gap-3 border-b border-border py-1.5 text-sm last:border-0">
      <span className="text-muted-foreground">{k}</span>
      <span className="text-right font-medium">{v}</span>
    </div>
  );
}

export function CountyDomains({ code }: { code: number }) {
  const { navigate } = useRouter();
  const [tab, setTab] = useState<DomainId>("demographics");
  const county = getCountyByCode(code);
  const counties = useMemo(() => allCounties(), []);

  const demo = county ? getCountyDemographics(county.name) : null;
  const fin = county ? getCountyFinance(county.name, "2023/24") : null;
  const series = county ? getCountyTimeSeries(county.name) : [];
  const svc = getServiceDeliveryForCounty(code);
  const cidp = getCidpForCounty(code);
  const dpi = getDpiForCounty(code);
  const rev = getRevenueForCounty(code);
  const petitions = getPetitionsForCounty(code);
  const gender = getGenderInclusionForCounty(code);
  const civic = getCivicParticipationForCounty(code);
  const climate = getClimateForCounty(code);
  const conflicts = getConflictsForCounty(code);
  const mps = mpsForCounty(code);
  const sen = senatorForCounty(code);
  const wr = womanRepForCounty(code);
  const succession = getSuccession(code);
  const site = siteForCounty(code);

  if (!county) return null;
  const meta = DOMAIN_REGISTRY.find((d) => d.id === tab)!;
  const g = county.governor;

  return (
    <Card className="p-5">
      <SectionTitle
        kicker="kenya-county-data · 11 domains"
        title="County data file"
        action={<span className="hidden text-[11px] text-muted-foreground sm:block">data/{tab} · ingestion → validation → database</span>}
      />
      <div className="scrollbar-hide -mx-1 mb-4 flex gap-1.5 overflow-x-auto px-1 pb-1">
        {DOMAIN_REGISTRY.map((d) => (
          <button key={d.id} onClick={() => setTab(d.id)}
            className={cn("whitespace-nowrap rounded-full px-3 py-1.5 text-xs font-medium transition",
              tab === d.id ? "bg-ke-green text-white dark:bg-primary dark:text-primary-foreground" : "border border-border hover:bg-muted")}>
            {d.title}
          </button>
        ))}
      </div>

      <p className="text-sm text-muted-foreground">{meta.description}</p>

      <div className="mt-4">
        {tab === "counties" && (
          <div>
            <Row k="County code (IEBC)" v={String(county.code).padStart(3, "0")} />
            <Row k="Region" v={county.region} />
            <Row k="Governor (2022–2027)" v={`${g.fullName} (${g.party})`} />
            {site && (
              <div className="flex items-center justify-between gap-3 border-b border-border py-1.5 text-sm">
                <span className="text-muted-foreground">Official website</span>
                <a href={site.url} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 font-medium text-ke-green underline">{site.url.replace("https://", "")} <ExternalLink className="h-3 w-3" /></a>
              </div>
            )}
            <Row k="Boundary file" v="county_boundaries.geojson — see public/data" />
            <Row k="Counties in file" v={String(counties.length)} />
            <SourceLinks sources={meta.sources} />
          </div>
        )}

        {tab === "demographics" && (
          <div>
            {demo ? (<>
              <Row k="Population (2019 Census)" v={demo.population.toLocaleString()} />
              <Row k="Land area" v={`${Math.round(demo.landAreaSqKm).toLocaleString()} km²`} />
              <Row k="Density" v={`${demo.densityPerSqKm.toLocaleString()}/km²`} />
              <Row k="Census" v={demo.populationCensus} />
              <p className="mt-2 text-[11px] text-muted-foreground">Source: {demo.source}</p>
            </>) : <DataGap />}
            <SourceLinks sources={meta.sources} />
          </div>
        )}

        {tab === "health" && (
          <div>
            {svc && (svc.healthFacilitiesPer10k != null || svc.doctorPatientRatio || svc.immunizationRate != null) ? (<>
              {svc.healthFacilitiesPer10k != null && <Row k="Facilities per 10k" v={String(svc.healthFacilitiesPer10k)} />}
              {svc.doctorPatientRatio && <Row k="Doctor : patient" v={svc.doctorPatientRatio} />}
              {svc.immunizationRate != null && <Row k="Immunisation" v={`${svc.immunizationRate}%`} />}
              {svc.maternalMortalityRate && <Row k="Maternal mortality" v={svc.maternalMortalityRate} />}
              {svc.healthBudgetPerCapita && <Row k="Health budget / capita" v={svc.healthBudgetPerCapita} />}
              {svc.serviceDeliveryIndex != null && <Row k="Service index" v={`${svc.serviceDeliveryIndex}/100 (${svc.fy})`} />}
            </>) : <DataGap note="No bundled KHIS/DHIS2 extract for this county — shown as N/A. Ingest via ingestion/knbs + county CIDP health tables." />}
            <SourceLinks sources={meta.sources} />
          </div>
        )}

        {tab === "education" && (
          <div>
            {svc && (svc.primaryEnrollmentRate != null || svc.secondaryEnrollmentRate != null || svc.completionRatePrimary != null) ? (<>
              {svc.primaryEnrollmentRate != null && <Row k="Primary enrolment" v={`${svc.primaryEnrollmentRate}%`} />}
              {svc.secondaryEnrollmentRate != null && <Row k="Secondary enrolment" v={`${svc.secondaryEnrollmentRate}%`} />}
              {svc.completionRatePrimary != null && <Row k="Primary completion" v={`${svc.completionRatePrimary}%`} />}
              {svc.teacherDeploymentVsVacancy && <Row k="Teachers (deployed vs vacancy)" v={svc.teacherDeploymentVsVacancy} />}
              {svc.educationBudgetPerCapita && <Row k="Education budget / capita" v={svc.educationBudgetPerCapita} />}
            </>) : <DataGap note="No bundled MoE/TSC extract for this county — shown as N/A. Ingest via Basic Education Statistical Booklet + TSC deployment." />}
            <SourceLinks sources={meta.sources} />
          </div>
        )}

        {tab === "agriculture" && (
          <div>
            {cidp.filter((p) => p.sector === "Agriculture").length > 0 ? (
              cidp.filter((p) => p.sector === "Agriculture").slice(0, 4).map((p) => (
                <div key={p.id} className="rounded-lg border border-border p-2 text-sm"><p className="font-medium">{p.projectName}</p><p className="text-xs text-muted-foreground">{p.status} · {p.completionPercent ?? "N/A"}% · {p.budgetAllocated}</p></div>
              ))
            ) : <DataGap note="No bundled agriculture output/extension rows for this county — shown as N/A. Ingest via MoA Economic Review of Agriculture + CIDP agriculture tables." />}
            <SourceLinks sources={meta.sources} />
          </div>
        )}

        {tab === "finance" && (
          <div>
            {fin ? (<>
              <Row k={`Approved budget (${fin.fiscalYear})`} v={formatKshs(fin.approvedBudget)} />
              <Row k="Equitable share" v={formatKshs(fin.equitableShare)} />
              <Row k="OSR collected / target" v={`${formatKshs(fin.ownSourceRevenue)} / ${formatKshs(fin.osrTarget)}`} />
              <Row k="Overall absorption" v={`${fin.overallAbsorption ?? "N/A"}%`} />
              <Row k="Development absorption" v={`${fin.developmentAbsorption ?? "N/A"}%`} />
              <Row k="Pending bills" v={formatKshs(fin.pendingBills)} />
              <Row k="Audit opinion" v={fin.auditOpinion} />
              <Row k="CoG compliance" v={fin.complianceScore != null ? `${fin.complianceScore}/100` : "N/A"} />
              {series.length > 1 && <p className="mt-2 text-[11px] text-muted-foreground">History: {series.map((s) => `${s.fiscalYear} ${s.overallAbsorption}%`).join(" · ")}</p>}
            </>) : <DataGap note="No CoB FY23/24 extract for this county — shown as N/A rather than estimated." />}
            <div className="mt-3 flex flex-wrap gap-2">
              <button onClick={() => navigate("finance-county", { name: county.name })} className="rounded-full bg-ke-green px-4 py-2 text-sm text-white">Full finance drill-down</button>
              <button onClick={() => navigate("reports", {}, { county: county.name })} className="rounded-full border border-border px-4 py-2 text-sm">FY reports archive</button>
            </div>
            <SourceLinks sources={meta.sources} />
          </div>
        )}

        {tab === "infrastructure" && (
          <div>
            {cidp.filter((p) => p.sector === "Infrastructure").length > 0 ? (
              cidp.filter((p) => p.sector === "Infrastructure").slice(0, 4).map((p) => (
                <div key={p.id} className="rounded-lg border border-border p-2 text-sm"><p className="font-medium">{p.projectName}</p><p className="text-xs text-muted-foreground">{p.status} · {p.completionPercent ?? "N/A"}% · {p.budgetAllocated}</p></div>
              ))
            ) : <DataGap note="No bundled roads/water/energy inventory for this county — shown as N/A. Ingest via KRB/KeNHA/KURA, WASREB, KPLC/REREC county schedules." />}
            <SourceLinks sources={meta.sources} />
          </div>
        )}

        {tab === "projects" && (
          <div>
            {cidp.length > 0 ? (
              <div className="space-y-2">
                {cidp.slice(0, 5).map((p) => (
                  <div key={p.id} className="rounded-lg border border-border p-2 text-sm">
                    <p className="font-medium">{p.projectName}</p>
                    <p className="text-xs text-muted-foreground">{p.sector} · {p.cidpPhase} · {p.status} · {p.completionPercent ?? "N/A"}% · {p.budgetAllocated}{p.budgetSpent ? ` (spent ${p.budgetSpent})` : ""}</p>
                  </div>
                ))}
              </div>
            ) : <DataGap note="No CIDP project rows bundled for this county. Delivery proxy: development absorption in Finance." />}
            <SourceLinks sources={meta.sources} />
          </div>
        )}

        {tab === "governance" && (
          <div className="space-y-2 text-sm">
            {dpi && <Row k={`DPI rank #${dpi.rank}`} v={`${dpi.overallDPI}/100 (Fin ${dpi.financialManagement} · Svc ${dpi.serviceDelivery} · Trans ${dpi.transparency} · Gov ${dpi.governance})`} />}
            {rev && <Row k="OSR share" v={`${rev.osrPercentage}% · efficiency ${rev.collectionEfficiency}%`} />}
            {petitions.length > 0 && <p>Petitions: {petitions.slice(0, 2).map((p) => `${p.title} (${p.status})`).join(" · ")}</p>}
            {gender && <p>Women MCAs {gender.womenMcasCount} ({gender.womenMcasPercentage}%) · Female CECMs {gender.femaleCecmCount}</p>}
            {civic && <p>Participation: {civic.publicHearingsHeld} hearings · {civic.participationCompliance}</p>}
            {conflicts.length > 0 && <p className="rounded-lg border border-amber-300 bg-amber-50 p-2 dark:bg-amber-950/30">Border: {conflicts.map((c) => `${c.countiesInvolved.join(" ↔ ")} (${c.severity})`).join("; ")}</p>}
            {!dpi && !rev && petitions.length === 0 && !gender && !civic && conflicts.length === 0 && <DataGap />}
            <SourceLinks sources={meta.sources} />
          </div>
        )}

        {tab === "procurement" && (
          <div className="text-sm">
            {fin?.pendingBills != null ? (<>
              <Row k="Pending bills (CoB)" v={formatKshs(fin.pendingBills)} />
              <p className="mt-2">Arrears ageing + supplier schedules come from CoB pending-bill annexes; award-level tenders from PPRA.</p>
            </>) : <DataGap note="No CoB pending-bill schedule bundled for this county — shown as N/A." />}
            <DataGap note="Award-level tender data (PPRA) is not bundled — this panel stays empty rather than fabricating tenders." />
            <SourceLinks sources={meta.sources} />
          </div>
        )}

        {tab === "environment" && (
          <div className="text-sm">
            {climate ? (<>
              <Row k="NEMA compliance" v={climate.nemaComplianceStatus ?? "N/A"} />
              {climate.waterResourceStatus && <Row k="Water" v={climate.waterResourceStatus} />}
              {climate.deforestationRate && <p className="mt-1 text-muted-foreground">{climate.deforestationRate}</p>}
              {climate.disasterEventsLast5Yrs && <p className="mt-1">Disasters: {climate.disasterEventsLast5Yrs}</p>}
              {climate.disasterResponseBudget && <Row k="Disaster budget" v={climate.disasterResponseBudget} />}
            </>) : <DataGap note="No NEMA/KFS/NDMA extract bundled for this county — shown as N/A." />}
            <SourceLinks sources={meta.sources} />
          </div>
        )}

        {tab === "elections" && (
          <div className="text-sm">
            {succession && <Row k="Governors 2013-2022" v={`${succession.term1} / ${succession.term2}`} />}
            <Row k="Governor (IEBC 2022)" v={`${g.fullName} — ${g.party}`} />
            {g.votes != null && <Row k="Governor votes" v={g.votes.toLocaleString()} />}
            {sen && <Row k="Senator" v={`${sen.fullName} (${sen.party})`} />}
            {wr && <Row k="Woman Rep" v={`${wr.fullName} (${wr.party})`} />}
            <Row k="Constituency MPs" v={mps.length > 0 ? mps.map((m) => `${m.jurisdiction} (${m.party})`).slice(0, 6).join(" · ") + (mps.length > 6 ? ` +${mps.length - 6}` : "") : "N/A — see parliament.go.ke"} />
            <Row k="Population base (2019)" v={demo ? formatPopulation(demo.population) : "N/A"} />
            <SourceLinks sources={meta.sources} />
          </div>
        )}
      </div>

      <details className="mt-4 rounded-xl bg-muted/50 p-3 text-xs text-muted-foreground">
        <summary className="cursor-pointer font-semibold">Pipeline: ingestion → backend → frontend → database</summary>
        <div className="mt-2 space-y-1">
          {PIPELINE_STAGES.map((p) => (
            <p key={p.id}><span className="font-mono">{p.folder}</span> — {p.title}: {p.detail}</p>
          ))}
          <p><span className="font-mono">backend/</span> API routes mirror these domains. <span className="font-mono">frontend/</span> is this dashboard. <span className="font-mono">database/schema.sql</span> tables per domain — see Stats → Data infrastructure.</p>
        </div>
      </details>
    </Card>
  );
}
