import { useState } from "react";
import { LogIn, LogOut, User as UserIcon, X } from "lucide-react";
import { useAuth } from "../lib/auth";

export function AuthButton() {
  const { configured, user, initializing, signInWithGoogle, signOut, error } = useAuth();
  const [showHelp, setShowHelp] = useState(false);
  const [menu, setMenu] = useState(false);

  if (initializing) return <div className="h-8 w-8 animate-pulse rounded-full bg-muted" />;

  if (user) {
    const label = user.displayName || user.email || "Signed in";
    const initial = (user.displayName || user.email || "?").trim().charAt(0).toUpperCase();
    return (
      <div className="relative">
        <button
          onClick={() => setMenu((m) => !m)}
          className="flex items-center gap-2 rounded-full border border-border bg-card py-1 pl-1 pr-2.5 text-xs shadow-sm"
          title={user.email ?? label}
        >
          {user.photoURL ? (
            <img src={user.photoURL} alt="" className="h-6 w-6 rounded-full object-cover" />
          ) : (
            <span className="flex h-6 w-6 items-center justify-center rounded-full bg-ke-green text-[11px] font-bold text-white">{initial}</span>
          )}
          <span className="hidden max-w-[110px] truncate font-medium sm:block">{label.split(" ")[0]}</span>
        </button>
        {menu && (
          <>
            <div className="fixed inset-0 z-40" onClick={() => setMenu(false)} />
            <div className="absolute right-0 z-50 mt-2 w-64 rounded-2xl border border-border bg-card p-4 shadow-xl">
              <p className="truncate text-sm font-medium">{user.displayName ?? "Google user"}</p>
              <p className="truncate text-xs text-muted-foreground">{user.email}</p>
              <button onClick={() => { setMenu(false); signOut(); }} className="mt-3 flex w-full items-center justify-center gap-1 rounded-xl border border-border py-2 text-sm">
                <LogOut className="h-4 w-4" /> Sign out
              </button>
            </div>
          </>
        )}
      </div>
    );
  }

  return (
    <>
      <button
        onClick={() => (configured ? signInWithGoogle() : setShowHelp(true))}
        className="flex items-center gap-1.5 rounded-full bg-ke-black px-3 py-1.5 text-xs font-medium text-white dark:bg-primary dark:text-primary-foreground"
      >
        {configured ? <UserIcon className="h-3.5 w-3.5" /> : <LogIn className="h-3.5 w-3.5" />}
        <span className="hidden sm:inline">{configured ? "Sign in" : "Sign in"}</span>
      </button>
      {error && error !== "not-configured" && <span className="hidden text-[10px] text-rose-600 xl:block">{error}</span>}
      {showHelp && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center bg-black/50 p-4" onClick={() => setShowHelp(false)}>
          <div className="w-full max-w-md rounded-2xl border border-border bg-card p-5 shadow-2xl" onClick={(e) => e.stopPropagation()}>
            <div className="mb-2 flex items-center justify-between">
              <h3 className="font-display text-xl">Enable Google sign-in</h3>
              <button onClick={() => setShowHelp(false)}><X className="h-5 w-5" /></button>
            </div>
            <ol className="list-decimal space-y-2 pl-5 text-sm text-muted-foreground">
              <li>Create a project at <span className="font-mono">console.firebase.google.com</span></li>
              <li>Build → Authentication → Sign-in method → enable <strong>Google</strong></li>
              <li>Project settings → add a Web app → copy the config values</li>
              <li>Set <span className="font-mono">VITE_FIREBASE_API_KEY</span>, <span className="font-mono">VITE_FIREBASE_AUTH_DOMAIN</span>, <span className="font-mono">VITE_FIREBASE_PROJECT_ID</span>, <span className="font-mono">VITE_FIREBASE_APP_ID</span> and rebuild</li>
            </ol>
            <p className="mt-3 text-xs text-muted-foreground">Full steps live in Admin → Backend tab. Until then the dashboard works fully signed-out.</p>
          </div>
        </div>
      )}
    </>
  );
}
