import type { ReactNode } from "react";
import { cn } from "../utils/cn";
import { initials } from "../lib/format";
import type { AuditOpinion, Coalition } from "../lib/types";
import { auditBg, coalitionColor } from "../lib/format";

export function Avatar({ name, size = "md", className }: { name: string; size?: "sm" | "md" | "lg" | "xl"; className?: string }) {
  const dim = { sm: "h-8 w-8 text-[10px]", md: "h-11 w-11 text-xs", lg: "h-16 w-16 text-base", xl: "h-24 w-24 text-2xl" }[size];
  return (
    <div className={cn("flex shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-ke-green to-ke-black font-semibold text-white shadow-inner", dim, className)}>
      {initials(name)}
    </div>
  );
}

export function Badge({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <span className={cn("inline-flex items-center rounded-full border px-2 py-0.5 text-[11px] font-medium tracking-wide", className)}>
      {children}
    </span>
  );
}

export function AuditBadge({ opinion }: { opinion: AuditOpinion | string }) {
  return <Badge className={auditBg(opinion)}>{opinion}</Badge>;
}

export function CoalitionBadge({ coalition }: { coalition: Coalition | string }) {
  return <Badge className={coalitionColor(coalition)}>{coalition}</Badge>;
}

export function Card({ children, className, onClick }: { children: ReactNode; className?: string; onClick?: () => void }) {
  return (
    <div onClick={onClick} className={cn("rounded-2xl border border-border bg-card text-card-foreground shadow-sm", onClick && "cursor-pointer transition hover:-translate-y-0.5 hover:shadow-md", className)}>
      {children}
    </div>
  );
}

export function StatCard({ label, value, hint, icon, tone = "default" }: { label: string; value: string; hint?: string; icon?: ReactNode; tone?: "default" | "green" | "red" | "gold" }) {
  const tones = {
    default: "from-card to-card",
    green: "from-emerald-50 to-card dark:from-emerald-950/40",
    red: "from-rose-50 to-card dark:from-rose-950/40",
    gold: "from-amber-50 to-card dark:from-amber-950/40",
  };
  return (
    <Card className={cn("overflow-hidden bg-gradient-to-br p-4", tones[tone])}>
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">{label}</p>
          <p className="mt-1 font-display text-2xl font-semibold tracking-tight">{value}</p>
          {hint && <p className="mt-1 text-xs text-muted-foreground">{hint}</p>}
        </div>
        {icon && <div className="text-ke-green/80 dark:text-primary">{icon}</div>}
      </div>
    </Card>
  );
}

export function ScoreRing({ score, size = 72, label }: { score: number | null | undefined; size?: number; label?: string }) {
  const v = score ?? 0;
  const r = 28;
  const c = 2 * Math.PI * r;
  const offset = c - (Math.min(100, Math.max(0, v)) / 100) * c;
  const color = v >= 80 ? "#006b3f" : v >= 60 ? "#c5a572" : v > 0 ? "#bb0000" : "#9ca3af";
  return (
    <div className="flex flex-col items-center">
      <svg width={size} height={size} viewBox="0 0 72 72">
        <circle cx="36" cy="36" r={r} fill="none" stroke="currentColor" strokeWidth="6" className="text-muted" />
        <circle cx="36" cy="36" r={r} fill="none" stroke={color} strokeWidth="6" strokeDasharray={c} strokeDashoffset={score == null ? c : offset} strokeLinecap="round" transform="rotate(-90 36 36)" />
        <text x="36" y="40" textAnchor="middle" className="fill-foreground" fontSize="14" fontWeight="700">{score == null ? "—" : Math.round(score)}</text>
      </svg>
      {label && <p className="mt-1 text-[10px] uppercase tracking-wider text-muted-foreground">{label}</p>}
    </div>
  );
}

export function PersonRow({ person, onClick, extra }: { person: any; onClick?: () => void; extra?: ReactNode }) {
  const name = person.fullName ?? person.name ?? "Unknown";
  const title = person.officialTitle ?? person.title ?? "";
  return (
    <button type="button" onClick={onClick} className="flex w-full items-center gap-3 rounded-xl px-2 py-2 text-left transition hover:bg-muted/70">
      <Avatar name={name} />
      <div className="min-w-0 flex-1">
        <p className="truncate font-medium">{name}</p>
        <p className="truncate text-xs text-muted-foreground">{title}</p>
      </div>
      {extra}
    </button>
  );
}

export function Empty({ title, body }: { title: string; body?: string }) {
  return (
    <div className="rounded-2xl border border-dashed border-border p-8 text-center">
      <p className="font-display text-lg">{title}</p>
      {body && <p className="mt-1 text-sm text-muted-foreground">{body}</p>}
    </div>
  );
}

export function SectionTitle({ kicker, title, action }: { kicker?: string; title: string; action?: ReactNode }) {
  return (
    <div className="mb-4 flex items-end justify-between gap-3">
      <div>
        {kicker && <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-ke-red">{kicker}</p>}
        <h2 className="font-display text-2xl font-semibold tracking-tight">{title}</h2>
      </div>
      {action}
    </div>
  );
}

export function DataGap({ note }: { note?: string }) {
  return (
    <p className="text-xs italic text-muted-foreground">
      {note ?? "Data not publicly available in the latest OAG / CoB / TI-Kenya reports. Marked N/A rather than estimated."}
    </p>
  );
}
