import { useEffect, useMemo, useState, type ReactNode } from "react";
import {
  BarChart3, Bot, Building2, Gavel, Home, Landmark, Menu, Moon, Scale,
  Search, ShieldAlert, Sun, Users, X, GitCompare, MessageSquare, Activity,
  FileWarning, Briefcase, Wallet, Siren, ScrollText, Vote, Newspaper,
  Video, FileText, Gem, Ghost, HeartHandshake, Plane, Network, TrendingDown,
  FileCheck, Coins, Bell, Trophy, Gauge, UsersRound, HelpCircle, GraduationCap,
  HeartPulse, ClipboardList, Sprout, Hourglass, Archive,
} from "lucide-react";
import { useLanguage } from "../lib/i18n";
import { useRouter } from "../lib/router";
import { useTheme } from "../lib/theme";
import { realSearch, allCounties } from "../lib/real-store";
import { AuthButton } from "./AuthButton";
import { cn } from "../utils/cn";
import type { PageId } from "../lib/types";

type NavItem = { id: string; labelKey: string; fallback: string; page: PageId; params?: Record<string,string>; icon: any; section: string };

const NAV: NavItem[] = [
  { id: "home", labelKey: "item.home", fallback: "Home", page: "home", icon: Home, section: "Dashboard" },
  { id: "finance", labelKey: "nav.finance_audit", fallback: "Finance & Audit", page: "finance", icon: BarChart3, section: "Dashboard" },
  { id: "reports", labelKey: "FY Reports", fallback: "FY Reports Archive", page: "reports", icon: Archive, section: "Dashboard" },
  { id: "reps", labelKey: "nav.representatives", fallback: "Representatives", page: "reps", icon: Users, section: "Dashboard" },
  { id: "senate", labelKey: "reps.senators", fallback: "Senate — How to get info", page: "senate", icon: Landmark, section: "Dashboard" },
  { id: "compare", labelKey: "nav.compare", fallback: "Compare", page: "compare", icon: GitCompare, section: "Dashboard" },
  { id: "stats", labelKey: "nav.stats", fallback: "Platform Stats", page: "stats", icon: Activity, section: "Dashboard" },
  { id: "search", labelKey: "nav.search", fallback: "Search", page: "search", icon: Search, section: "Dashboard" },
  { id: "history", labelKey: "Devolution history", fallback: "Devolution history (2013→)", page: "history", icon: Hourglass, section: "Constitution & Law" },
  { id: "constitution", labelKey: "item.constitution", fallback: "Constitution", page: "oversight", params: { section: "constitution" }, icon: Scale, section: "Constitution & Law" },
  { id: "court", labelKey: "item.court_cases", fallback: "Court Cases Tracker", page: "oversight", params: { section: "court" }, icon: Gavel, section: "Constitution & Law" },
  { id: "petitions", labelKey: "item.resolutions", fallback: "Petitions & Resolutions", page: "oversight", params: { section: "petitions" }, icon: ScrollText, section: "Constitution & Law" },
  { id: "pending", labelKey: "item.pending_bills", fallback: "Pending Bills Heatmap", page: "oversight", params: { section: "pending-bills" }, icon: Wallet, section: "Accountability" },
  { id: "projects", labelKey: "item.projects", fallback: "Project Tracker (CIDP)", page: "oversight", params: { section: "projects" }, icon: Briefcase, section: "Accountability" },
  { id: "variance", labelKey: "item.variance", fallback: "Budget Variance", page: "oversight", params: { section: "variance" }, icon: FileCheck, section: "Accountability" },
  { id: "debt", labelKey: "item.debt", fallback: "Debt & Borrowing", page: "oversight", params: { section: "debt" }, icon: Coins, section: "Accountability" },
  { id: "contracts", labelKey: "item.contracts", fallback: "Contract Performance", page: "oversight", params: { section: "contracts" }, icon: FileText, section: "Accountability" },
  { id: "wealth", labelKey: "item.wealth", fallback: "Wealth Declarations", page: "oversight", params: { section: "wealth" }, icon: Gem, section: "Dishonesty Tracking" },
  { id: "redflags", labelKey: "item.red_flags", fallback: "AI Red Flag Scanner", page: "oversight", params: { section: "red-flags" }, icon: Siren, section: "Dishonesty Tracking" },
  { id: "tenders", labelKey: "item.tenders", fallback: "Tender Anomaly Detector", page: "oversight", params: { section: "tenders" }, icon: FileWarning, section: "Dishonesty Tracking" },
  { id: "payroll", labelKey: "item.payroll_assets", fallback: "Ghost Workers & Assets", page: "oversight", params: { section: "payroll" }, icon: Ghost, section: "Dishonesty Tracking" },
  { id: "travel", labelKey: "item.travel", fallback: "Travel & Per-Diem Audit", page: "oversight", params: { section: "travel" }, icon: Plane, section: "Dishonesty Tracking" },
  { id: "ownership", labelKey: "item.ownership", fallback: "Beneficial Ownership", page: "oversight", params: { section: "ownership" }, icon: Network, section: "Dishonesty Tracking" },
  { id: "revenue", labelKey: "item.revenue", fallback: "Revenue Leakage", page: "oversight", params: { section: "revenue" }, icon: TrendingDown, section: "Dishonesty Tracking" },
  { id: "peer", labelKey: "item.peer_ranking", fallback: "Peer Ranking", page: "oversight", params: { section: "peer" }, icon: Trophy, section: "Performance & Ranking" },
  { id: "dpi", labelKey: "item.performance_index", fallback: "Devolution Performance Index", page: "oversight", params: { section: "dpi" }, icon: Gauge, section: "Performance & Ranking" },
  { id: "service", labelKey: "item.service_delivery", fallback: "Service Delivery", page: "oversight", params: { section: "service" }, icon: HeartPulse, section: "Performance & Ranking" },
  { id: "gender", labelKey: "Gender & Inclusion", fallback: "Gender & Inclusion", page: "oversight", params: { section: "gender" }, icon: UsersRound, section: "Performance & Ranking" },
  { id: "climate", labelKey: "Climate & Environment", fallback: "Climate & Environment", page: "oversight", params: { section: "climate" }, icon: Sprout, section: "Performance & Ranking" },
  { id: "participation", labelKey: "item.participation", fallback: "Public Participation", page: "oversight", params: { section: "participation" }, icon: Vote, section: "Citizen Engagement" },
  { id: "budgetqa", labelKey: "item.budget_qa", fallback: "AI Budget Q&A", page: "ai", icon: HelpCircle, section: "Citizen Tools" },
  { id: "bursary", labelKey: "item.bursary", fallback: "Bursary Tracker", page: "oversight", params: { section: "bursary" }, icon: GraduationCap, section: "Citizen Engagement" },
  { id: "alerts", labelKey: "item.alerts", fallback: "Expenditure Alerts", page: "oversight", params: { section: "alerts" }, icon: Bell, section: "Citizen Tools" },
  { id: "sentiment", labelKey: "item.sentiment", fallback: "Sentiment Monitor", page: "oversight", params: { section: "sentiment" }, icon: HeartHandshake, section: "Citizen Tools" },
  { id: "feedback", labelKey: "item.feedback", fallback: "Feedback", page: "feedback", icon: MessageSquare, section: "Citizen Tools" },
  { id: "whistle", labelKey: "item.whistleblower", fallback: "Whistleblower", page: "whistleblower", icon: ShieldAlert, section: "Citizen Tools" },
  { id: "hotline", labelKey: "item.hotline", fallback: "Hotline Reports", page: "oversight", params: { section: "hotline" }, icon: Newspaper, section: "Citizen Tools" },
  { id: "ai", labelKey: "nav.ai", fallback: "AI Assistant", page: "ai", icon: Bot, section: "Citizen Tools" },
  { id: "admin", labelKey: "action.admin", fallback: "Admin", page: "admin", icon: Landmark, section: "Citizen Tools" },
  { id: "borders", labelKey: "Border Conflicts", fallback: "Border Conflicts", page: "oversight", params: { section: "borders" }, icon: ClipboardList, section: "Constitution & Law" },
  { id: "civic", labelKey: "Civic Education", fallback: "Civic Education", page: "oversight", params: { section: "civic" }, icon: Video, section: "Citizen Engagement" },
];

function FlagMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 48 32" className={className} aria-hidden>
      <rect width="48" height="32" fill="#17120b" />
      <rect y="10.5" width="48" height="11" fill="#bb0000" />
      <rect y="21.5" width="48" height="10.5" fill="#006b3f" />
      <rect y="9.5" width="48" height="2" fill="#fff" />
      <rect y="20.5" width="48" height="2" fill="#fff" />
      <circle cx="16" cy="16" r="6.2" fill="#fff" />
      <circle cx="16" cy="16" r="4.6" fill="#c5a572" />
    </svg>
  );
}

export function Layout({ children }: { children: ReactNode }) {
  const { t, language, setLanguage } = useLanguage();
  const { theme, toggle } = useTheme();
  const { route, navigate } = useRouter();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [cmdOpen, setCmdOpen] = useState(false);
  const [q, setQ] = useState("");

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") { e.preventDefault(); setCmdOpen(true); }
      if (e.key === "Escape") setCmdOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  useEffect(() => { setSidebarOpen(false); }, [route.page, route.params.section, route.params.code, route.params.id, route.params.name]);

  const isActive = (item: NavItem) => {
    if (item.page === "oversight") return route.page === "oversight" && route.params.section === item.params?.section;
    if (item.page === "home") return route.page === "home";
    return route.page === item.page || (item.page === "finance" && route.page === "finance-county") || (item.page === "reps" && route.page === "rep");
  };

  const sections = useMemo(() => {
    const map = new Map<string, NavItem[]>();
    for (const n of NAV) {
      const arr = map.get(n.section) ?? [];
      arr.push(n);
      map.set(n.section, arr);
    }
    return [...map.entries()];
  }, []);

  const results = q.trim().length > 1 ? realSearch(q) : null;
  const counties = useMemo(() => allCounties(), []);

  const labelFor = (item: NavItem) => {
    const v = t(item.labelKey);
    if (v === item.labelKey) return item.fallback;
    return v;
  };

  return (
    <div className="min-h-dvh bg-background text-foreground">
      <div className="flag-stripe h-1.5 w-full" />
      <header className="sticky top-0 z-40 border-b border-border/80 bg-background/85 backdrop-blur-md">
        <div className="mx-auto flex max-w-[1600px] items-center gap-3 px-3 py-2.5 lg:px-5">
          <button className="rounded-lg p-2 lg:hidden" onClick={() => setSidebarOpen(true)} aria-label="Open menu"><Menu className="h-5 w-5" /></button>
          <button onClick={() => navigate("home")} className="flex items-center gap-2.5">
            <img src="/images/emblem.svg" alt="" className="h-9 w-9 rounded-full object-cover ring-1 ring-ke-gold/50" />
            <div className="text-left">
              <p className="font-display text-base font-semibold leading-none">{t("app.title.short")}</p>
              <p className="mt-0.5 hidden text-[10px] uppercase tracking-[0.16em] text-muted-foreground sm:block">47 Counties · 2022–2027 · OAG · CoB · KNBS</p>
            </div>
          </button>
          <button onClick={() => setCmdOpen(true)} className="ml-auto hidden flex-1 items-center gap-2 rounded-full border border-border bg-card px-4 py-2 text-sm text-muted-foreground shadow-sm md:flex lg:max-w-md">
            <Search className="h-4 w-4" /><span className="flex-1 text-left">{t("action.search")} — counties, MPs, finance…</span>
            <kbd className="rounded border border-border bg-muted px-1.5 py-0.5 text-[10px]">⌘K</kbd>
          </button>
          <div className="ml-auto flex items-center gap-1.5 md:ml-0">
            <button onClick={() => setCmdOpen(true)} className="rounded-lg p-2 md:hidden" aria-label="Search"><Search className="h-5 w-5" /></button>
            <AuthButton />
            <div className="flex overflow-hidden rounded-full border border-border text-[11px] font-semibold">
              <button className={cn("px-2.5 py-1", language === "en" ? "bg-ke-black text-white dark:bg-primary dark:text-primary-foreground" : "")} onClick={() => setLanguage("en")}>EN</button>
              <button className={cn("px-2.5 py-1", language === "sw" ? "bg-ke-black text-white dark:bg-primary dark:text-primary-foreground" : "")} onClick={() => setLanguage("sw")}>SW</button>
            </div>
            <button onClick={toggle} className="rounded-lg p-2" aria-label="Toggle theme">{theme === "dark" ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}</button>
          </div>
        </div>
      </header>

      <div className="mx-auto flex max-w-[1600px]">
        <aside className={cn("fixed inset-y-0 left-0 z-50 w-72 overflow-y-auto border-r border-border bg-card px-3 py-4 transition lg:static lg:z-0 lg:block lg:h-[calc(100dvh-3.4rem)] lg:sticky lg:top-[3.4rem]", sidebarOpen ? "block" : "hidden lg:block")}>
          <div className="mb-3 flex items-center justify-between lg:hidden"><span className="font-display text-lg">Menu</span><button onClick={() => setSidebarOpen(false)}><X className="h-5 w-5" /></button></div>
          <div className="mb-4 rounded-xl bg-gradient-to-br from-ke-black via-ke-red to-ke-green p-[1px]">
            <div className="rounded-[11px] bg-card p-3">
              <p className="text-[10px] uppercase tracking-[0.16em] text-muted-foreground">{t("app.badge")}</p>
              <p className="mt-1 text-xs leading-relaxed">OAG · CoB · CoG · KNBS · Parliament · IEBC · EACC · TI-Kenya</p>
            </div>
          </div>
          {sections.map(([section, items]) => (
            <div key={section} className="mb-4">
              <p className="mb-1 px-2 text-[10px] font-semibold uppercase tracking-[0.18em] text-muted-foreground">{section}</p>
              <div className="space-y-0.5">
                {items.map((item) => {
                  const Icon = item.icon;
                  const active = isActive(item);
                  return (
                    <button key={item.id} onClick={() => navigate(item.page, item.params)} className={cn("flex w-full items-center gap-2.5 rounded-xl px-2.5 py-2 text-sm transition", active ? "bg-ke-green text-white dark:bg-primary dark:text-primary-foreground" : "hover:bg-muted")}>
                      <Icon className="h-4 w-4 shrink-0" /><span className="truncate">{labelFor(item)}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </aside>
        {sidebarOpen && <div className="fixed inset-0 z-40 bg-black/40 lg:hidden" onClick={() => setSidebarOpen(false)} />}
        <main className="has-bottom-nav min-w-0 flex-1 px-3 py-5 lg:px-6 lg:py-6">{children}</main>
      </div>

      <footer className="hidden border-t border-border bg-card/60 px-6 py-6 lg:block">
        <div className="mx-auto flex max-w-[1600px] flex-wrap items-center justify-between gap-3 text-xs text-muted-foreground">
          <div className="flex items-center gap-2"><FlagMark className="h-4 w-6 rounded-sm" /><span>{t("footer.title")}</span></div>
          <span>{t("footer.nonPartisan")}</span><span>{t("footer.sources")}</span>
        </div>
      </footer>

      <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-border bg-card/95 backdrop-blur lg:hidden" style={{ paddingBottom: "env(safe-area-inset-bottom)" }}>
        <div className="grid grid-cols-5 text-[10px]">
          {[
            { page: "home" as PageId, icon: Home, label: t("bottomnav.home") },
            { page: "finance" as PageId, icon: BarChart3, label: t("nav.finance_audit") },
            { page: "ai" as PageId, icon: Bot, label: t("bottomnav.ai") },
            { page: "reps" as PageId, icon: Users, label: t("nav.representatives") },
            { page: "reports" as PageId, icon: Archive, label: "Reports" },
          ].map((item) => {
            const Icon = item.icon;
            const active = route.page === item.page;
            return (
              <button key={item.page} onClick={() => navigate(item.page)} className={cn("flex flex-col items-center gap-1 py-2", active ? "text-ke-green dark:text-primary" : "text-muted-foreground")}>
                <Icon className="h-5 w-5" /><span className="truncate px-1">{item.label}</span>
              </button>
            );
          })}
        </div>
      </nav>

      {cmdOpen && (
        <div className="fixed inset-0 z-[60] flex items-start justify-center bg-black/50 p-4 pt-[10vh]" onClick={() => setCmdOpen(false)}>
          <div className="w-full max-w-2xl overflow-hidden rounded-2xl border border-border bg-card shadow-2xl" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center gap-2 border-b border-border px-4">
              <Search className="h-4 w-4 text-muted-foreground" />
              <input autoFocus value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search counties, governors, MPs, senators, finance…" className="h-12 w-full bg-transparent text-sm outline-none" />
              <kbd className="text-[10px] text-muted-foreground">ESC</kbd>
            </div>
            <div className="max-h-[55vh] overflow-y-auto p-2">
              {q.trim().length <= 1 && (
                <div className="grid grid-cols-2 gap-1 p-1">
                  {NAV.slice(0, 10).map((n) => (
                    <button key={n.id} onClick={() => { navigate(n.page, n.params); setCmdOpen(false); setQ(""); }} className="rounded-lg px-3 py-2 text-left text-sm hover:bg-muted">{labelFor(n)}</button>
                  ))}
                </div>
              )}
              {results && (
                <>
                  {results.counties.slice(0, 5).map((c) => (
                    <button key={c.code} className="flex w-full items-center gap-3 rounded-lg px-3 py-2 text-left hover:bg-muted" onClick={() => { navigate("county", { code: String(c.code) }); setCmdOpen(false); setQ(""); }}>
                      <Building2 className="h-4 w-4 text-ke-green" /><span>{c.name} County <span className="text-xs text-muted-foreground">· {c.governor.fullName}</span></span>
                    </button>
                  ))}
                  {results.mps.slice(0, 5).map((p) => (
                    <button key={p.id} className="flex w-full items-center gap-3 rounded-lg px-3 py-2 text-left hover:bg-muted" onClick={() => { navigate("search", {}, { q: p.fullName }); setCmdOpen(false); }}>
                      <Users className="h-4 w-4 text-ke-gold" /><span>{p.fullName} <span className="text-xs text-muted-foreground">· {p.officialTitle} · {p.party}</span></span>
                    </button>
                  ))}
                  {results.reps.slice(0, 5).map((p) => (
                    <button key={p.id} className="flex w-full items-center gap-3 rounded-lg px-3 py-2 text-left hover:bg-muted" onClick={() => { navigate("rep", { id: p.id }); setCmdOpen(false); setQ(""); }}>
                      <Users className="h-4 w-4 text-ke-gold" /><span>{p.fullName} <span className="text-xs text-muted-foreground">· {p.officialTitle}</span></span>
                    </button>
                  ))}
                  {q.trim().length > 1 && results.counties.length === 0 && results.reps.length === 0 && results.mps.length === 0 && (
                    <p className="p-4 text-center text-sm text-muted-foreground">No matches. Try a county, governor, MP, or party.</p>
                  )}
                </>
              )}
            </div>
            <div className="flex justify-between border-t border-border px-4 py-2 text-[11px] text-muted-foreground">
              <span>{counties.length} counties · 331 MPs · 47 senators · 47 women reps indexed</span>
              <button className="underline" onClick={() => { navigate("search", {}, q ? { q } : {}); setCmdOpen(false); }}>Open full search</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
