import { useMemo } from "react";
import { allCounties, getCountyFinance } from "../lib/real-store";
import { useRouter } from "../lib/router";
import { useLanguage } from "../lib/i18n";

type Mode = "audit" | "absorption" | "coalition";

export function CountyMap({ mode, onMode }: { mode: Mode; onMode: (m: Mode) => void }) {
  const { navigate } = useRouter();
  const { countyName } = useLanguage();
  const counties = useMemo(() => allCounties(), []);

  function colorFor(_code: number, county: (typeof counties)[number]): string {
    if (mode === "coalition") {
      if (county.governor.coalition === "Kenya Kwanza") return "bg-yellow-400/90 dark:bg-yellow-500/80";
      if (county.governor.coalition === "Azimio") return "bg-sky-500/90 dark:bg-sky-500/80";
      return "bg-stone-400/90";
    }
    if (mode === "absorption") {
      const v = county.governor.budgetPerformance?.overallAbsorption.rate ?? getCountyFinance(county.name, "2023/24")?.overallAbsorption;
      if (v == null) return "bg-muted text-muted-foreground";
      if (v >= 90) return "bg-emerald-600 text-white";
      if (v >= 80) return "bg-emerald-500/80 text-white";
      if (v >= 70) return "bg-amber-400 text-black";
      return "bg-rose-600 text-white";
    }
    const a = county.governor.auditOpinion?.fy2023_24.type ?? getCountyFinance(county.name, "2023/24")?.auditOpinion;
    if (a === "Unmodified") return "bg-emerald-600 text-white";
    if (a === "Qualified") return "bg-amber-400 text-black";
    if (a === "Adverse") return "bg-rose-600 text-white";
    if (a === "Disclaimer") return "bg-purple-600 text-white";
    return "bg-muted text-muted-foreground";
  }

  return (
    <div>
      <div className="mb-3 flex flex-wrap gap-2 text-xs">
        {(["audit", "absorption", "coalition"] as Mode[]).map((m) => (
          <button key={m} onClick={() => onMode(m)} className={`rounded-full px-3 py-1 ${mode === m ? "bg-ke-black text-white dark:bg-primary dark:text-primary-foreground" : "border border-border"}`}>
            {m === "audit" ? "Audit opinion" : m === "absorption" ? "Absorption FY23/24" : "Coalition"}
          </button>
        ))}
      </div>
      <div className="grid grid-cols-4 gap-1.5 sm:grid-cols-6 lg:grid-cols-8">
        {counties.map((c) => (
          <button key={c.code} onClick={() => navigate("county", { code: String(c.code) })} title={`${c.name} — ${c.governor.fullName}`}
            className={`flex min-h-[56px] flex-col items-center justify-center rounded-lg border border-black/10 p-1 text-center transition hover:scale-[1.03] hover:shadow ${colorFor(c.code, c)}`}>
            <span className="text-[9px] font-bold opacity-80">{String(c.code).padStart(2, "0")}</span>
            <span className="line-clamp-2 text-[10px] font-semibold leading-tight">{countyName(c.name)}</span>
            <span className="text-[9px] opacity-80">
              {mode === "absorption"
                ? `${c.governor.budgetPerformance?.overallAbsorption.rate ?? getCountyFinance(c.name, "2023/24")?.overallAbsorption ?? "N/A"}${c.governor.budgetPerformance?.overallAbsorption.rate != null ? "%" : ""}`
                : mode === "audit"
                  ? (c.governor.auditOpinion?.fy2023_24.type.slice(0, 4) ?? getCountyFinance(c.name, "2023/24")?.auditOpinion.slice(0, 4) ?? "N/A")
                  : c.governor.party}
            </span>
          </button>
        ))}
      </div>
      <div className="mt-2 flex flex-wrap gap-3 text-[11px] text-muted-foreground">
        {mode === "audit" ? (<>
          <span><i className="mr-1 inline-block h-2 w-2 rounded-full bg-emerald-600" /> Unmodified (clean)</span>
          <span><i className="mr-1 inline-block h-2 w-2 rounded-full bg-amber-400" /> Qualified</span>
          <span><i className="mr-1 inline-block h-2 w-2 rounded-full bg-rose-600" /> Adverse</span>
          <span><i className="mr-1 inline-block h-2 w-2 rounded-full bg-purple-600" /> Disclaimer</span>
        </>) : mode === "absorption" ? (<>
          <span><i className="mr-1 inline-block h-2 w-2 rounded-full bg-emerald-600" /> ≥90%</span>
          <span><i className="mr-1 inline-block h-2 w-2 rounded-full bg-emerald-500" /> 80–90%</span>
          <span><i className="mr-1 inline-block h-2 w-2 rounded-full bg-amber-400" /> 70–80%</span>
          <span><i className="mr-1 inline-block h-2 w-2 rounded-full bg-rose-600" /> &lt;70%</span>
        </>) : (<>
          <span><i className="mr-1 inline-block h-2 w-2 rounded-full bg-yellow-400" /> Kenya Kwanza</span>
          <span><i className="mr-1 inline-block h-2 w-2 rounded-full bg-sky-500" /> Azimio</span>
          <span><i className="mr-1 inline-block h-2 w-2 rounded-full bg-stone-400" /> Independent/Other</span>
        </>)}
      </div>
    </div>
  );
}
