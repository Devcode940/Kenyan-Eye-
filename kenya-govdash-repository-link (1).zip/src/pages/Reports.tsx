import { useEffect, useMemo, useState } from "react";
import { Archive, Download, ExternalLink, Globe, Search } from "lucide-react";
import { ALL_COUNTY_FINANCE, NATIONAL_FINANCE, getAvailableFiscalYears, formatKshs, countySites } from "../lib/real-store";
import { listReports, listSites, type BackendReport, type BackendSite } from "../lib/api";
import { useRouter } from "../lib/router";
import { AuditBadge, Card, DataGap, SectionTitle } from "../components/ui";
import { cn } from "../utils/cn";

const ARCHIVES = [
  { name: "CoB consolidated county reports (2013→)", url: "https://cob.go.ke/reports/consolidated-county-budget-implementation-review-reports", note: "Annual + quarterly BIRRs, every FY since devolution began" },
  { name: "OAG county audit reports archive", url: "https://oagkenya.go.ke/", note: "County executive + assembly audits, every FY" },
  { name: "National Treasury — budget documents", url: "https://www.treasury.go.ke/", note: "Budget statements, CARA/CARA bills, Division of Revenue" },
];

export function ReportsPage() {
  const { navigate, route } = useRouter();
  const initialCounty = (route.query.county as string) || "All";
  const [fy, setFy] = useState<string>("All");
  const [county, setCounty] = useState<string>(initialCounty);
  const [q, setQ] = useState("");
  const [webReports, setWebReports] = useState<BackendReport[]>([]);
  const [webVia, setWebVia] = useState<"backend" | "local">("local");
  const [sites, setSites] = useState<BackendSite[]>([]);
  const [sitesVia, setSitesVia] = useState<"backend" | "local">("local");

  const fys = useMemo(() => getAvailableFiscalYears(), []);
  const staticSites = useMemo(() => countySites(), []);

  useEffect(() => {
    listReports().then((r) => { setWebReports(r.reports); setWebVia(r.via); });
    listSites().then((r) => { setSites(r.sites); setSitesVia(r.via); });
  }, []);

  useEffect(() => { setCounty((route.query.county as string) || "All"); }, [route.query.county]);

  const siteStatus = useMemo(() => {
    const m = new Map<number, BackendSite>();
    sites.forEach((s) => m.set(s.code, s));
    return m;
  }, [sites]);

  const rows = useMemo(() => {
    return ALL_COUNTY_FINANCE.filter((r) => {
      if (fy !== "All" && r.fiscalYear !== fy) return false;
      if (county !== "All" && r.countyName !== county) return false;
      if (q && !`${r.countyName} ${r.auditOpinion} ${r.source}`.toLowerCase().includes(q.toLowerCase())) return false;
      return true;
    }).sort((a, b) => a.fiscalYear.localeCompare(b.fiscalYear) || a.countyName.localeCompare(b.countyName));
  }, [fy, county, q]);

  const countyNames = useMemo(() => [...new Set(ALL_COUNTY_FINANCE.map((r) => r.countyName))].sort(), []);

  const webFiltered = useMemo(() => {
    return webReports.filter((r) => {
      if (fy !== "All" && r.fy && r.fy !== fy) return false;
      if (county !== "All" && r.county && r.county !== county) return false;
      if (q && !`${r.title} ${r.county ?? ""}`.toLowerCase().includes(q.toLowerCase())) return false;
      return true;
    }).slice(0, 60);
  }, [webReports, fy, county, q]);

  function exportCsv() {
    const header = "county,fy,approvedBudget,equitableShare,osr,absorption,devAbsorption,audit,compliance,pendingBills,source\n";
    const body = rows.map((r) => `${r.countyName},${r.fiscalYear},${r.approvedBudget},${r.equitableShare},${r.ownSourceRevenue ?? ""},${r.overallAbsorption ?? ""},${r.developmentAbsorption ?? ""},${r.auditOpinion},${r.complianceScore ?? ""},${r.pendingBills ?? ""},"${r.source}"`).join("\n");
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([header + body], { type: "text/csv" }));
    a.download = `kenya-govdash-reports-${fy === "All" ? "all-FY" : fy.replace("/", "-")}.csv`;
    a.click();
  }

  return (
    <div className="space-y-8">
      <div>
        <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-ke-red">CoB · OAG · County websites — every fiscal year</p>
        <h1 className="font-display text-3xl sm:text-4xl">FY Reports Archive</h1>
        <p className="mt-1 max-w-3xl text-sm text-muted-foreground">
          Explore every bundled report ({ALL_COUNTY_FINANCE.length} county snapshots across {fys.join(", ")}, plus {NATIONAL_FINANCE.length} national FYs),
          live county-website report links ({webVia === "backend" ? `${webReports.length} fed by the scraper` : "run the backend + scraper to feed live links"}),
          and the official archives back to FY 2013/14.
        </p>
      </div>

      {/* FILTERS */}
      <div className="flex flex-wrap items-center gap-2">
        <div className="flex flex-wrap gap-1.5">
          {["All", ...fys].map((f) => (
            <button key={f} onClick={() => setFy(f)} className={cn("rounded-full px-3 py-1.5 text-xs font-medium", fy === f ? "bg-ke-black text-white dark:bg-primary dark:text-primary-foreground" : "border border-border")}>
              {f === "All" ? "All FYs" : `FY ${f}`}
            </button>
          ))}
        </div>
        <select value={county} onChange={(e) => setCounty(e.target.value)} className="h-9 rounded-full border border-border bg-card px-3 text-sm">
          <option value="All">All counties</option>
          {countyNames.map((c) => <option key={c}>{c}</option>)}
        </select>
        <div className="relative min-w-[180px] flex-1">
          <Search className="pointer-events-none absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search reports…" className="h-9 w-full rounded-full border border-border bg-card pl-9 pr-3 text-sm outline-none" />
        </div>
        <button onClick={exportCsv} className="inline-flex h-9 items-center gap-1 rounded-full border border-border px-3 text-xs"><Download className="h-3.5 w-3.5" /> CSV ({rows.length})</button>
      </div>

      {/* NATIONAL FYs */}
      <Card className="p-5">
        <SectionTitle kicker="National Treasury · OAG" title="National FY reports" />
        <div className="grid gap-2 sm:grid-cols-3">
          {NATIONAL_FINANCE.map((n) => (
            <div key={n.fiscalYear} className="rounded-xl border border-border p-3 text-sm">
              <p className="font-semibold">FY {n.fiscalYear}</p>
              <p>Budget {formatKshs(n.approvedBudget)} · absorption {n.overallAbsorption}%</p>
              <p className="text-xs text-muted-foreground">Debt {formatKshs(n.totalDebt)} · pending {formatKshs(n.pendingBills)} · audit {n.auditOpinion}</p>
            </div>
          ))}
        </div>
      </Card>

      {/* COUNTY SNAPSHOTS */}
      <section>
        <SectionTitle kicker="Bundled CoB extracts" title={`County FY snapshots (${rows.length})`} />
        <div className="space-y-2">
          {rows.map((r) => (
            <button key={`${r.countyName}-${r.fiscalYear}`} onClick={() => navigate("finance-county", { name: r.countyName })} className="flex w-full flex-wrap items-center gap-2 rounded-xl border border-border bg-card p-3 text-left text-sm hover:shadow">
              <span className="rounded-full bg-muted px-2 py-0.5 text-[11px] font-semibold">FY {r.fiscalYear}</span>
              <span className="font-medium">{r.countyName}</span>
              <AuditBadge opinion={r.auditOpinion} />
              <span className="text-muted-foreground">Abs {r.overallAbsorption ?? "N/A"}% · Dev {r.developmentAbsorption ?? "N/A"}% · {formatKshs(r.approvedBudget)}</span>
              <span className="ml-auto hidden text-[11px] text-muted-foreground lg:block">{r.source}</span>
            </button>
          ))}
          {rows.length === 0 && <DataGap note="No bundled snapshots match this filter — try another FY or county." />}
        </div>
      </section>

      {/* LIVE COUNTY-WEBSITE REPORTS */}
      <Card className="p-5">
        <SectionTitle kicker={webVia === "backend" ? "Fed by server/scrape.mjs" : "Needs backend + scraper"} title={`County website reports ${webVia === "backend" ? `(${webReports.length})` : ""}`} />
        {webVia !== "backend" ? (
          <DataGap note="Live county-website report links appear here once the backend runs and node server/scrape.mjs has fed the counties (stores titles + URLs in SQLite). Meanwhile use the official archives below." />
        ) : webFiltered.length === 0 ? (
          <p className="text-sm text-muted-foreground">No scraped reports match — run node server/scrape.mjs to feed the counties.</p>
        ) : (
          <div className="max-h-[380px] space-y-1 overflow-y-auto">
            {webFiltered.map((r) => (
              <a key={r.id} href={r.url} target="_blank" rel="noreferrer" className="flex items-center justify-between gap-2 rounded-lg px-2 py-1.5 text-sm hover:bg-muted">
                <span className="truncate">{r.title} <span className="text-muted-foreground">· {r.county ?? ""} {r.fy ? `· FY ${r.fy}` : ""}</span></span>
                <ExternalLink className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
              </a>
            ))}
          </div>
        )}
      </Card>

      {/* COUNTY WEBSITES DIRECTORY */}
      <Card className="p-5">
        <SectionTitle kicker="data/county-sites.json" title={`47 official county websites ${sitesVia === "backend" ? "· live-checked" : ""}`} />
        <div className="grid gap-1.5 sm:grid-cols-2 lg:grid-cols-3">
          {staticSites.map((s) => {
            const live = siteStatus.get(s.code);
            const ok = live ? live.http_status !== null && live.http_status < 400 : null;
            return (
              <a key={s.code} href={s.url} target="_blank" rel="noreferrer" className="flex items-center justify-between gap-2 rounded-xl border border-border px-3 py-2 text-sm hover:bg-muted">
                <span><strong>{s.county}</strong> <span className="text-[11px] text-muted-foreground">{s.url.replace("https://", "")}</span></span>
                <span className={cn("flex items-center gap-1 text-[10px]",
                  ok === true ? "text-emerald-600" : ok === false ? "text-rose-600" : "text-muted-foreground")}>
                  <Globe className="h-3 w-3" />
                  {ok === true ? `live (${live!.http_status})` : ok === false ? `check (${live!.http_status ?? "?"})` : sitesVia === "backend" ? "unchecked" : "open"}
                </span>
              </a>
            );
          })}
        </div>
        <p className="mt-2 text-[11px] text-muted-foreground">
          {sitesVia === "backend"
            ? "Statuses live-checked by the scraper (title + report links stored in SQLite)."
            : "Statuses need the backend: run node server/scrape.mjs to live-check all 47 sites and feed their FY reports into the archive above."}
        </p>
      </Card>

      {/* OLDER FYs */}
      <Card className="p-5">
        <SectionTitle kicker="FY 2013/14 → 2020/21" title="Previous FYs — official archives" />
        <div className="flex items-center gap-2 text-sm">
          <Archive className="h-4 w-4 text-ke-green" />
          <p className="text-muted-foreground">Bundled extracts start FY 2021/22. Everything older lives in the official archives — same sources, same validation when ingested.</p>
        </div>
        <div className="mt-3 space-y-2">
          {ARCHIVES.map((a) => (
            <a key={a.name} href={a.url} target="_blank" rel="noreferrer" className="flex items-center justify-between gap-2 rounded-xl border border-border p-3 text-sm hover:bg-muted">
              <span><strong>{a.name}</strong><span className="block text-xs text-muted-foreground">{a.note}</span></span>
              <ExternalLink className="h-4 w-4 shrink-0 text-muted-foreground" />
            </a>
          ))}
        </div>
      </Card>
    </div>
  );
}
