import { useMemo, useState } from "react";
import { Search, ExternalLink, Landmark, Vote, Scale, ArrowRight } from "lucide-react";
import { DEVOLUTION_TERMS, DEVOLUTION_MILESTONES, GOVERNOR_SUCCESSION, HISTORY_SOURCES } from "../real/devolution-history";
import { useRouter } from "../lib/router";
import { Card, SectionTitle, StatCard } from "../components/ui";

export function HistoryPage() {
  const { navigate } = useRouter();
  const [q, setQ] = useState("");
  const [term, setTerm] = useState<"2013-2017" | "2017-2022" | "2022-2027">("2022-2027");

  const filtered = useMemo(() => {
    const s = q.trim().toLowerCase();
    if (!s) return GOVERNOR_SUCCESSION;
    return GOVERNOR_SUCCESSION.filter((g) => `${g.countyName} ${g.term1} ${g.term2} ${g.term3}`.toLowerCase().includes(s));
  }, [q]);

  const comebacks = GOVERNOR_SUCCESSION.filter((g) => g.term1 === g.term3 && g.term1 !== g.term2).length;
  const twoTermers = GOVERNOR_SUCCESSION.filter((g) => g.term1 === g.term2).length;

  return (
    <div className="space-y-8">
      <div>
        <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-ke-red">Constitution 2010 · First elections 4 March 2013</p>
        <h1 className="font-display text-3xl sm:text-4xl">Devolution history — since 2013</h1>
        <p className="mt-1 max-w-3xl text-sm text-muted-foreground">
          Every county, all three terms. Past-term parties are deliberately omitted (defections make them unreliable);
          names per IEBC 2013 / 2017 / 2022 results. Finance series currently cover FY 2021/22 → 2023/24 — earlier
          reports live in the FY Reports Archive and the official archives linked below.
        </p>
      </div>

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Devolution age" value="13 yrs" hint="4 Mar 2013 → today" icon={<Landmark className="h-5 w-5" />} tone="green" />
        <StatCard label="Terms completed" value="2 + current" hint="2013–17 · 2017–22 · 2022–27" icon={<Vote className="h-5 w-5" />} />
        <StatCard label="Two-term governors 13–22" value={String(twoTermers)} hint="Served full first decade" icon={<Scale className="h-5 w-5" />} tone="gold" />
        <StatCard label="Comebacks (lost → won)" value={String(comebacks)} hint="Lamu, Garissa, Wajir, Kitui + 5 more" icon={<ArrowRight className="h-5 w-5" />} />
      </div>

      <Card className="p-5">
        <SectionTitle kicker="2010 → today" title="Devolution milestones" />
        <div className="relative space-y-0 border-l-2 border-ke-green/30 pl-0">
          {DEVOLUTION_MILESTONES.map((m) => (
            <div key={m.date + m.title} className="relative pb-5 pl-6 last:pb-0">
              <span className="absolute -left-[7px] top-1 h-3 w-3 rounded-full bg-ke-green ring-4 ring-ke-green/15" />
              <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-ke-green">{m.date}</p>
              <p className="font-medium">{m.title}</p>
              <p className="text-sm text-muted-foreground">{m.detail}</p>
            </div>
          ))}
        </div>
      </Card>

      <div className="grid gap-3 lg:grid-cols-3">
        {DEVOLUTION_TERMS.map((t) => (
          <Card key={t.id} className="p-4 text-sm">
            <p className="text-[11px] uppercase tracking-[0.16em] text-muted-foreground">{t.id}</p>
            <p className="font-display text-lg">{t.label}</p>
            <p className="mt-1">Elected {t.electionDate} · sworn {t.swornIn}</p>
            <p className="text-muted-foreground">President: {t.president}</p>
          </Card>
        ))}
      </div>

      <section>
        <SectionTitle kicker="IEBC 2013 · 2017 · 2022" title="All 47 successions" action={<span className="text-xs text-muted-foreground">{filtered.length} shown</span>} />
        <div className="mb-3 flex flex-wrap gap-2">
          <div className="relative min-w-[200px] flex-1">
            <Search className="pointer-events-none absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search county or governor…" className="h-10 w-full rounded-full border border-border bg-card pl-9 pr-3 text-sm outline-none" />
          </div>
          {(["2013-2017", "2017-2022", "2022-2027"] as const).map((t) => (
            <button key={t} onClick={() => setTerm(t)} className={`h-10 rounded-full px-4 text-sm ${term === t ? "bg-ke-black text-white dark:bg-primary dark:text-primary-foreground" : "border border-border"}`}>{t}</button>
          ))}
        </div>
        <Card className="overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full min-w-[720px] text-left text-sm">
              <thead className="bg-muted/60 text-[11px] uppercase tracking-wider text-muted-foreground">
                <tr><th className="px-4 py-2">#</th><th className="px-4 py-2">County</th><th className="px-4 py-2">2013–2017</th><th className="px-4 py-2">2017–2022</th><th className="px-4 py-2">2022–2027</th></tr>
              </thead>
              <tbody>
                {filtered.map((g) => (
                  <tr key={g.code} className="cursor-pointer border-t border-border hover:bg-muted/40" onClick={() => navigate("county", { code: String(g.code) })}>
                    <td className="px-4 py-2 text-muted-foreground">{String(g.code).padStart(2, "0")}</td>
                    <td className="px-4 py-2 font-medium">{g.countyName}{g.note ? " *" : ""}</td>
                    <td className={`px-4 py-2 ${term === "2013-2017" ? "bg-ke-green/10 font-medium" : ""}`}>{g.term1}</td>
                    <td className={`px-4 py-2 ${term === "2017-2022" ? "bg-ke-green/10 font-medium" : ""}`}>{g.term2}</td>
                    <td className={`px-4 py-2 ${term === "2022-2027" ? "bg-ke-green/10 font-medium" : ""}`}>{g.term3}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <p className="p-3 text-[11px] text-muted-foreground">* = note on the county page (impeachment, death in office, or comeback). Click any row for the county profile.</p>
        </Card>
      </section>

      <Card className="p-5">
        <SectionTitle kicker="Money since 2013" title="Finance across the devolution era" />
        <div className="grid gap-3 text-sm sm:grid-cols-3">
          <div className="rounded-xl border border-border p-3"><p className="font-semibold">In this dashboard</p><p className="mt-1 text-muted-foreground">County finance FY 2021/22 → 2023/24 (CoB extracts) with time-series, radar and linear forecast on the Finance page.</p><button onClick={() => navigate("finance")} className="mt-2 text-ke-green underline">Open finance →</button></div>
          <div className="rounded-xl border border-border p-3"><p className="font-semibold">Every FY report</p><p className="mt-1 text-muted-foreground">Browse all bundled FY snapshots plus live county-website report links in the FY Reports Archive.</p><button onClick={() => navigate("reports")} className="mt-2 text-ke-green underline">Open archive →</button></div>
          <div className="rounded-xl border border-border p-3"><p className="font-semibold">Full 2013→ archive</p><p className="mt-1 text-muted-foreground">CoB has published county implementation reports every year since FY 2013/14; OAG audits likewise — linked in the archive.</p></div>
        </div>
      </Card>

      <Card className="p-5">
        <SectionTitle kicker="Cite" title="History sources" />
        {HISTORY_SOURCES.map((s) => (
          <a key={s.abbr} href={s.url} target="_blank" rel="noreferrer" className="flex items-center justify-between rounded-lg px-2 py-2 text-sm hover:bg-muted">
            <span><strong>{s.abbr}</strong> — {s.name}</span><ExternalLink className="h-3.5 w-3.5 text-muted-foreground" />
          </a>
        ))}
      </Card>
    </div>
  );
}
