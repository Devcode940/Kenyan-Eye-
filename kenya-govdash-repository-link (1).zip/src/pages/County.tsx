import { ArrowLeft, MapPin, ExternalLink, Users } from "lucide-react";
import { useMemo } from "react";
import {
  getCountyByCode, getRepresentativeById, getCountyDemographics, getDataQualityScore,
  getCountyFinance, getCountyTimeSeries, mpsForCounty, senatorForCounty, womanRepForCounty,
  getDpiForCounty, getRevenueForCounty, getServiceDeliveryForCounty, getCidpForCounty,
  getPetitionsForCounty, getClimateForCounty, getCivicParticipationForCounty,
  getConflictsForCounty, getGenderInclusionForCounty, getBudgetQuarterlyForCounty,
  formatKshs, siteForCounty,
} from "../lib/real-store";
import { formatKesMillions, formatPopulation } from "../real/kenya-data";
import { useLanguage } from "../lib/i18n";
import { useRouter } from "../lib/router";
import { useAuth } from "../lib/auth";
import { AuditBadge, Avatar, Card, DataGap, PersonRow, ScoreRing, SectionTitle, StatCard } from "../components/ui";
import { CountyDomains } from "../components/CountyDomains";
import { CountyHistory } from "../components/CountyHistory";
import { Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis, CartesianGrid, Bar, BarChart } from "recharts";

export function CountyPage({ code }: { code: string }) {
  const { countyName } = useLanguage();
  const { navigate } = useRouter();
  const { user } = useAuth();
  const county = getCountyByCode(Number(code));
  const demo = county ? getCountyDemographics(county.name) : null;

  const fin = county ? getCountyFinance(county.name, "2023/24") : null;
  const series = county ? getCountyTimeSeries(county.name) : [];
  const mps = useMemo(() => mpsForCounty(Number(code)), [code]);
  const sen = useMemo(() => senatorForCounty(Number(code)), [code]);
  const wr = useMemo(() => womanRepForCounty(Number(code)), [code]);

  if (!county) {
    return <div className="p-8 text-center"><p className="font-display text-2xl">County not found</p><button className="mt-3 underline" onClick={() => navigate("home")}>Back home</button></div>;
  }

  const qual = getDataQualityScore(county);
  const dpi = getDpiForCounty(county.code);
  const rev = getRevenueForCounty(county.code);
  const svc = getServiceDeliveryForCounty(county.code);
  const cidp = getCidpForCounty(county.code);
  const petitions = getPetitionsForCounty(county.code);
  const climate = getClimateForCounty(county.code);
  const civic = getCivicParticipationForCounty(county.code);
  const conflicts = getConflictsForCounty(county.code);
  const gender = getGenderInclusionForCounty(county.code);
  const quarterly = getBudgetQuarterlyForCounty(county.code);
  const site = siteForCounty(county.code);
  const g = county.governor;
  void user;

  const leaders = [county.governor, county.deputyGovernor, county.senator, county.womanRep].filter(Boolean);

  return (
    <div className="space-y-6">
      <button onClick={() => navigate("home")} className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground"><ArrowLeft className="h-4 w-4" /> All 47 counties</button>

      <div className="relative overflow-hidden rounded-3xl border border-border">
        <img src="/images/county-assembly.jpg" alt="" className="h-52 w-full object-cover sm:h-64" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/40 to-black/10" />
        <div className="absolute bottom-0 w-full p-6 text-white">
          <p className="text-[11px] uppercase tracking-[0.2em] text-ke-gold">County {String(county.code).padStart(3,"0")} · {county.region} · KNBS 2019</p>
          <h1 className="font-display text-4xl sm:text-5xl">{countyName(county.name)} County</h1>
          <p className="mt-1 text-sm text-white/80">Governor {g.fullName} ({g.party}) · {demo ? `${formatPopulation(demo.population)} people · ${Math.round(demo.landAreaSqKm).toLocaleString()} km²` : ""}</p>
          {site && <a href={site.url} target="_blank" rel="noreferrer" className="mt-2 inline-flex items-center gap-1 rounded-full bg-white/15 px-3 py-1 text-xs text-white ring-1 ring-white/40">Official site: {site.url.replace("https://", "")} <ExternalLink className="h-3 w-3" /></a>}
        </div>
      </div>

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Population (KNBS 2019)" value={demo ? formatPopulation(demo.population) : "N/A"} hint={demo ? `Density ${demo.densityPerSqKm}/km²` : undefined} />
        <StatCard label="Equitable share FY24/25" value={county.budgetAllocation?.equitableShare != null ? formatKesMillions(county.budgetAllocation.equitableShare) : "N/A"} hint="CARA 2024" />
        <StatCard label="Absorption FY23/24" value={g.budgetPerformance?.overallAbsorption.rate != null ? `${g.budgetPerformance.overallAbsorption.rate}%` : fin?.overallAbsorption != null ? `${fin.overallAbsorption}%` : "N/A"} hint={g.budgetPerformance?.overallAbsorption.source ?? fin?.source ?? "N/A"} />
        <StatCard label="Data coverage" value={`${qual.coveragePercent}%`} hint={qual.quality} />
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="p-5 lg:col-span-2">
          <SectionTitle kicker="Executive & Parliament" title="Leadership — 2022–2027" action={dpi ? <span className="text-xs text-muted-foreground">DPI #{dpi.rank} · {dpi.overallDPI}/100</span> : undefined} />
          <div className="grid gap-2 sm:grid-cols-2">
            {leaders.map((p) => (
              <button key={p!.id} onClick={() => navigate("rep", { id: p!.id })} className="flex items-center gap-3 rounded-2xl border border-border p-3 text-left hover:bg-muted/60">
                <Avatar name={p!.fullName} size="lg" />
                <div className="min-w-0"><p className="truncate font-medium">{p!.fullName}</p><p className="truncate text-xs text-muted-foreground">{p!.officialTitle} · {p!.party}</p></div>
              </button>
            ))}
          </div>
          {(sen || wr) && (
            <div className="mt-4 rounded-xl bg-muted/50 p-3 text-xs leading-relaxed">
              <p className="font-semibold">Parliament verification (parliament.go.ke):</p>
              {sen && <p className="mt-1">Senate: {sen.fullName} ({sen.party}) — <a className="text-ke-green underline" href={sen.profileUrl} target="_blank" rel="noreferrer">profile <ExternalLink className="inline h-3 w-3" /></a></p>}
              {wr && <p className="mt-1">Women Rep: {wr.fullName} ({wr.party}) — <a className="text-ke-green underline" href={wr.profileUrl} target="_blank" rel="noreferrer">profile <ExternalLink className="inline h-3 w-3" /></a></p>}
            </div>
          )}
          <div className="mt-4">
            <p className="mb-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground">Governor scorecard (7 metrics)</p>
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
              <ScoreRing score={g.scorecard.overallAccountability.score} label="Overall" />
              <ScoreRing score={g.scorecard.transparencyBudget.score} label="Transparency" />
              <ScoreRing score={g.scorecard.projectDeliveryAbsorption.score} label="Delivery" />
              <ScoreRing score={g.scorecard.ethicsIntegrity.score} label="Ethics" />
            </div>
            <div className="mt-2 grid grid-cols-3 gap-2 text-[11px] text-muted-foreground">
              <span>Manifesto: {g.scorecard.manifestoFulfillment.score ?? "N/A"}</span>
              <span>Oversight: {g.scorecard.legislativeOversight.score ?? "N/A"}</span>
              <span>Sentiment: {g.scorecard.publicSentiment.score ?? "N/A"}</span>
            </div>
          </div>
        </Card>
        <div className="space-y-4">
          <Card className="flex flex-col items-center p-5">
            <ScoreRing score={g.scorecard.overallAccountability.score} size={110} label="Accountability" />
            <div className="mt-3">{g.auditOpinion ? <AuditBadge opinion={g.auditOpinion.fy2023_24.type} /> : <span className="text-xs">Audit N/A</span>}</div>
            <p className="mt-2 text-center text-[11px] text-muted-foreground">{g.auditOpinion?.fy2023_24.source}</p>
          </Card>
          {rev && (
            <Card className="p-4 text-sm">
              <p className="text-[11px] uppercase tracking-wider text-muted-foreground">Revenue autonomy {rev.fy}</p>
              <p className="mt-1">OSR {rev.ownSourceRevenue} ({rev.osrPercentage}%)</p>
              <p>Equitable {rev.equitableShare}</p>
              <p className="text-xs text-muted-foreground">Efficiency {rev.collectionEfficiency}% · Diversification {rev.revenueDiversificationIndex}/10</p>
            </Card>
          )}
          {dpi && (
            <Card className="p-4 text-sm">
              <p className="text-[11px] uppercase tracking-wider text-muted-foreground">DPI breakdown</p>
              {[["Financial", dpi.financialManagement],["Service", dpi.serviceDelivery],["Transparency", dpi.transparency],["Governance", dpi.governance]].map(([l, v]) => (
                <div key={l as string} className="mt-1.5"><div className="flex justify-between text-xs"><span>{l}</span><span>{v}</span></div><div className="h-1.5 rounded-full bg-muted"><div className="h-full rounded-full bg-ke-green" style={{ width: `${v}%` }} /></div></div>
              ))}
            </Card>
          )}
        </div>
      </div>

      {(fin || series.length > 0) && (
        <Card className="p-5">
          <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
            <SectionTitle kicker="CoB · OAG" title={fin ? `FY ${fin.fiscalYear} finance` : "Finance history"} />
            <div className="flex gap-3">
              <button onClick={() => navigate("reports", {}, { county: county.name })} className="text-sm text-muted-foreground underline">All FY reports</button>
              <button onClick={() => navigate("finance-county", { name: county.name })} className="text-sm text-ke-green underline">Full drill-down</button>
            </div>
          </div>
          {fin && (
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
              <StatCard label="Approved budget" value={formatKshs(fin.approvedBudget)} />
              <StatCard label="Actual spend" value={formatKshs(fin.actualExpenditure)} />
              <StatCard label="Pending bills" value={formatKshs(fin.pendingBills)} tone="red" />
              <StatCard label="Compliance" value={fin.complianceScore != null ? `${fin.complianceScore}/100` : "N/A"} />
            </div>
          )}
          {series.length > 1 && (
            <div className="mt-5 h-60">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={series}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                  <XAxis dataKey="fiscalYear" tick={{ fontSize: 12 }} />
                  <YAxis tick={{ fontSize: 12 }} domain={[0, 100]} />
                  <Tooltip />
                  <Line type="monotone" dataKey="overallAbsorption" name="Overall %" stroke="#006b3f" strokeWidth={2} />
                  <Line type="monotone" dataKey="developmentAbsorption" name="Dev %" stroke="#bb0000" strokeWidth={2} />
                  <Line type="monotone" dataKey="recurrentAbsorption" name="Rec %" stroke="#c5a572" strokeWidth={2} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          )}
          {fin?.notes && <p className="mt-3 text-sm text-muted-foreground">{fin.notes}</p>}
          {fin && <p className="mt-1 text-[11px] text-muted-foreground">Source: {fin.source}</p>}
        </Card>
      )}

      {quarterly.length > 0 && (
        <Card className="p-5">
          <SectionTitle kicker="CoB quarterly" title="Budget execution by quarter" />
          <div className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={quarterly}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="quarter" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} />
                <Tooltip />
                <Bar dataKey="absorptionRate" name="Absorption %" fill="#0f3d2e" radius={[6,6,0,0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
          <div className="mt-3 grid gap-2 sm:grid-cols-4 text-xs">
            {quarterly.map((q) => (
              <div key={q.quarter} className="rounded-lg border border-border p-2"><p className="font-semibold">{q.quarter}</p><p>Disbursed {q.totalDisbursed ?? "N/A"}</p><p>Dev {q.developmentSpent ?? "N/A"}</p><p>Pending {q.pendingBills ?? "N/A"}</p></div>
            ))}
          </div>
        </Card>
      )}

      <CountyDomains code={county.code} />

      <CountyHistory code={county.code} />

      <div className="grid gap-4 lg:grid-cols-2">
        <Card className="p-5">
          <SectionTitle kicker={`National Assembly · ${mps.length} elected`} title="Constituency MPs" />
          {mps.length === 0 ? <DataGap /> : (
            <div className="max-h-[380px] space-y-1 overflow-y-auto">
              {mps.map((m) => (
                <a key={m.id} href={m.profileUrl} target="_blank" rel="noreferrer" className="flex items-center justify-between rounded-lg px-2 py-1.5 text-sm hover:bg-muted">
                  <span><strong>{m.fullName}</strong> <span className="text-muted-foreground">· {m.jurisdiction}</span></span>
                  <span className="text-[11px] text-muted-foreground">{m.party}</span>
                </a>
              ))}
            </div>
          )}
          {county.constituencyMPs && county.constituencyMPs.length > 0 && (
            <div className="mt-3 border-t border-border pt-3">
              <p className="mb-1 text-[11px] uppercase tracking-wider text-muted-foreground">Detailed profiles in GovDash</p>
              {county.constituencyMPs.slice(0, 6).map((mp) => <PersonRow key={mp.id} person={mp as any} onClick={() => navigate("rep", { id: mp.id })} />)}
            </div>
          )}
        </Card>
        <Card className="p-5">
          <SectionTitle kicker={`County executive · ${(county.cecms ?? []).length} portfolios`} title="CECMs" />
          <div className="max-h-[380px] overflow-y-auto">
            {(county.cecms ?? []).map((c) => (
              <PersonRow key={c.id} person={c as any} onClick={() => navigate("rep", { id: c.id })} extra={c.contacts?.email || c.biography ? <span className="text-[10px] text-emerald-600">Verified</span> : <span className="text-[10px] text-muted-foreground"> gazette pending</span>} />
            ))}
          </div>
          {county.countySecretary && <div className="mt-2 border-t border-border pt-2"><PersonRow person={county.countySecretary as any} onClick={() => navigate("rep", { id: county.countySecretary!.id })} /></div>}
          {county.countyAttorney && <PersonRow person={county.countyAttorney as any} onClick={() => navigate("rep", { id: county.countyAttorney!.id })} />}
        </Card>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card className="p-5">
          <SectionTitle kicker="Oversight" title="Service, CIDP, petitions" />
          {svc && <p className="text-sm">Health & education index: facilities, doctor ratios, enrollment — {svc.countyName} ({svc.fy}). <span className="text-muted-foreground">{svc.source}</span></p>}
          {cidp.length > 0 ? cidp.slice(0, 3).map((p) => (
            <div key={p.id} className="mt-2 rounded-lg border border-border p-2 text-sm"><p className="font-medium">{p.projectName}</p><p className="text-xs text-muted-foreground">{p.sector} · {p.status} · {p.completionPercent ?? "N/A"}% · {p.budgetAllocated}</p></div>
          )) : <div className="mt-2"><DataGap note="CIDP project rows for this county are not in the bundled extract." /></div>}
          {petitions.length > 0 ? petitions.slice(0, 2).map((p) => (
            <div key={p.id} className="mt-2 rounded-lg border border-border p-2 text-sm"><p className="font-medium">{p.title}</p><p className="text-xs text-muted-foreground">{p.category} · {p.status}</p></div>
          )) : <p className="mt-2 text-xs text-muted-foreground">No petition rows bundled for this county.</p>}
        </Card>
        <Card className="p-5">
          <SectionTitle kicker="Accountability" title="Gender, climate, civic" />
          {gender && <p className="text-sm">Women MCAs {gender.womenMcasCount} ({gender.womenMcasPercentage}%) · Female CECMs {gender.femaleCecmCount} · Compliance {gender.genderBudgetCompliance ?? "N/A"}</p>}
          {climate && <p className="mt-2 text-sm">NEMA: {climate.nemaComplianceStatus} · {climate.waterResourceStatus} <span className="text-muted-foreground">· {climate.source}</span></p>}
          {civic && <p className="mt-2 text-sm">Participation: {civic.publicHearingsHeld} hearings · {civic.participationCompliance} · Art.196: {civic.article196ComplianceNote.slice(0, 140)}…</p>}
          {conflicts.length > 0 && conflicts.map((c) => (
            <div key={c.id} className="mt-2 rounded-lg border border-amber-300 bg-amber-50 p-2 text-sm dark:bg-amber-950/30"><p className="font-medium">{c.countiesInvolved.join(" ↔ ")} — {c.severity}</p><p className="text-xs">{c.disputeType} · {c.status}</p></div>
          ))}
          {!gender && !climate && !civic && conflicts.length === 0 && <div className="mt-2"><DataGap /></div>}
        </Card>
      </div>

      <Card className="p-5">
        <SectionTitle kicker="Directory" title="All attached officials" />
        <p className="mb-3 flex items-center gap-1 text-xs text-muted-foreground"><MapPin className="h-3 w-3" /> Term 2022–2027 · click for scorecard, contacts, audit & budget</p>
        <div className="grid gap-1 sm:grid-cols-2">
          {[county.governor, county.deputyGovernor, county.senator, county.womanRep, ...(county.constituencyMPs ?? []), ...(county.electedMCAs ?? []).slice(0, 10), ...(county.cecms ?? [])].filter(Boolean).map((p) => (
            <PersonRow key={(p as any).id} person={p as any} onClick={() => navigate("rep", { id: (p as any).id })} />
          ))}
        </div>
      </Card>
    </div>
  );
}

export function RepPage({ id }: { id: string }) {
  const { navigate } = useRouter();
  const person = getRepresentativeById(id);
  if (!person) {
    return <div className="p-8 text-center"><p className="font-display text-2xl">Official not found</p><p className="mt-1 text-sm text-muted-foreground">ID: {id}</p><button className="mt-3 underline" onClick={() => navigate("reps")}>Back to directory</button></div>;
  }
  const county = person.countyCode ? getCountyByCode(person.countyCode) : undefined;
  const fin = county ? getCountyFinance(county.name, "2023/24") : null;
  const sc = person.scorecard;
  const metrics = [
    { label: "Overall", v: sc.overallAccountability },
    { label: "Transparency", v: sc.transparencyBudget },
    { label: "Delivery", v: sc.projectDeliveryAbsorption },
    { label: "Manifesto", v: sc.manifestoFulfillment },
    { label: "Oversight", v: sc.legislativeOversight },
    { label: "Ethics", v: sc.ethicsIntegrity },
    { label: "Sentiment", v: sc.publicSentiment },
  ];
  return (
    <div className="space-y-6">
      <button onClick={() => navigate("reps")} className="inline-flex items-center gap-1 text-sm text-muted-foreground"><ArrowLeft className="h-4 w-4" /> Directory</button>
      <Card className="p-6">
        <div className="flex flex-col gap-5 sm:flex-row">
          <Avatar name={person.fullName} size="xl" />
          <div className="flex-1">
            <p className="text-[11px] uppercase tracking-[0.18em] text-muted-foreground">{person.level} · {person.jurisdiction}</p>
            <h1 className="font-display text-3xl">{person.fullName}</h1>
            <p className="text-muted-foreground">{person.officialTitle} · {person.party} · {person.coalition}</p>
            <div className="mt-2 flex flex-wrap gap-2 text-[11px]">
              <span className="rounded-full border border-border px-2 py-0.5">{person.termStart.slice(0,4)}–{person.termEnd.slice(0,4)}</span>
              {person.votes != null && <span className="rounded-full border border-border px-2 py-0.5">{person.votes.toLocaleString()} votes</span>}
              {person.auditOpinion && <AuditBadge opinion={person.auditOpinion.fy2023_24.type} />}
            </div>
            {person.biography ? <p className="mt-4 max-w-3xl text-sm leading-relaxed">{person.biography}</p> : <div className="mt-4"><DataGap note="No citable biography attached." /></div>}
            {person.biographySource && <p className="mt-1 text-[11px] text-muted-foreground">Source: {person.biographySource}</p>}
            {person.votesSource && <p className="text-[11px] text-muted-foreground">Votes: {person.votesSource}</p>}
          </div>
        </div>
        <div className="mt-5 grid gap-2 text-sm sm:grid-cols-2 lg:grid-cols-4">
          {[["Email", person.contacts.email],["Phone", person.contacts.phone],["Twitter / X", person.contacts.twitter],["Website", person.contacts.website]].map(([l, v]) => (
            <div key={l} className="rounded-xl border border-border px-3 py-2"><p className="text-[10px] uppercase tracking-wider text-muted-foreground">{l}</p><p className="truncate">{(v as string) ?? "N/A"}</p></div>
          ))}
        </div>
      </Card>
      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="p-5 lg:col-span-2">
          <SectionTitle kicker="Scorecard" title="7 accountability metrics" />
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
            {metrics.map((m) => (
              <div key={m.label} className="flex flex-col items-center"><ScoreRing score={m.v.score} label={m.label} /><p className="mt-1 max-w-[140px] text-center text-[10px] text-muted-foreground">{m.v.score == null ? (m.v.note ?? "N/A") : `${m.v.source}${m.v.fy ? ` · ${m.v.fy}` : ""}`}</p></div>
            ))}
          </div>
        </Card>
        <Card className="p-5">
          <SectionTitle kicker="Context" title="Budget & audit" />
          {person.budgetPerformance ? (
            <div className="space-y-1 text-sm">
              <p>Overall {person.budgetPerformance.overallAbsorption.rate ?? "N/A"}% <span className="text-xs text-muted-foreground">· {person.budgetPerformance.overallAbsorption.fy}</span></p>
              <p>Recurrent {person.budgetPerformance.recurrentAbsorption.rate ?? "N/A"}%</p>
              <p>Development {person.budgetPerformance.developmentAbsorption.rate ?? "N/A"}%</p>
            </div>
          ) : <DataGap />}
          {fin && <div className="mt-3 border-t border-border pt-3 text-sm"><p>County finance: {formatKshs(fin.approvedBudget)} budget · {formatKshs(fin.pendingBills)} pending</p><button onClick={() => navigate("finance-county", { name: county!.name })} className="mt-2 w-full rounded-xl bg-ke-green py-2 text-white">County finance</button></div>}
          {county && <button onClick={() => navigate("county", { code: String(county.code) })} className="mt-2 flex w-full items-center justify-center gap-1 rounded-xl border border-border py-2 text-sm"><Users className="h-4 w-4" /> {county.name} profile</button>}
        </Card>
      </div>
    </div>
  );
}
