import { useEffect, useMemo, useState, type FormEvent } from "react";
import { Bot, Lock, Send, ShieldCheck, ExternalLink } from "lucide-react";
import {
  allCounties, allMPs, allSenators, allWomenReps, realSearch,
  NATIONAL_SUMMARY, getAggregateStats, ALL_COUNTY_FINANCE, getCountyFinance,
  dpiData, revenueAutonomyData, serviceDeliveryData, petitionData, cidpProjectData,
  borderConflictData, climateEnvironmentData, civicParticipationData, genderInclusionData,
  budgetQuarterlyData, KENYA_OVERSIGHT_FEATURES, flattenAllCountiesRepresentatives,
  getCountiesWithFinanceData,
} from "../lib/real-store";
import { useRouter } from "../lib/router";
import { useAuth } from "../lib/auth";
import { submitFeedback, listFeedback, submitEnvelope, trackTicket, backendHealth } from "../lib/api";
import { Card, DataGap, PersonRow, SectionTitle, StatCard } from "../components/ui";
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";

// ---------- SEARCH ----------
export function SearchPage() {
  const { navigate, route } = useRouter();
  const [q, setQ] = useState((route.query.q as string) || "");
  const res = useMemo(() => realSearch(q), [q]);
  const finHits = useMemo(() => {
    if (q.trim().length < 2) return [];
    const s = q.toLowerCase();
    return ALL_COUNTY_FINANCE.filter((r) => r.countyName.toLowerCase().includes(s)).slice(0, 10);
  }, [q]);

  return (
    <div className="space-y-6">
      <h1 className="font-display text-3xl">Site-wide search</h1>
      <p className="text-sm text-muted-foreground">Counties · governors · {allMPs().length} MPs · senators · women reps · finance · oversight</p>
      <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Try Nairobi, Sakaja, ODM, pending bills…" className="h-12 w-full rounded-2xl border border-border bg-card px-4" />
      {q.trim().length < 2 ? (
        <div className="grid gap-2 sm:grid-cols-2">
          {["Nairobi", "Sakaja", "Kisumu", "ODM", "UDA", "Nyeri", "Mombasa", "pending"].map((s) => (
            <button key={s} onClick={() => setQ(s)} className="rounded-xl border border-border p-3 text-left text-sm hover:bg-muted">Try “{s}”</button>
          ))}
        </div>
      ) : (
        <div className="grid gap-4 lg:grid-cols-2">
          <Card className="p-5">
            <SectionTitle title={`Counties (${res.counties.length})`} />
            {res.counties.map((c) => (
              <button key={c.code} onClick={() => navigate("county", { code: String(c.code) })} className="block w-full rounded-lg px-2 py-2 text-left text-sm hover:bg-muted">{c.name} · {c.governor.fullName} ({c.governor.party})</button>
            ))}
            {res.counties.length === 0 && <p className="text-sm text-muted-foreground">No county match.</p>}
            <div className="mt-4 border-t border-border pt-3">
              <p className="mb-1 text-xs uppercase tracking-wider text-muted-foreground">Finance rows ({finHits.length})</p>
              {finHits.map((r) => (
                <button key={`${r.countyName}-${r.fiscalYear}`} onClick={() => navigate("finance-county", { name: r.countyName })} className="block w-full rounded-lg px-2 py-1.5 text-left text-sm hover:bg-muted">{r.countyName} {r.fiscalYear} · {r.overallAbsorption}% · {r.auditOpinion}</button>
              ))}
            </div>
          </Card>
          <Card className="p-5">
            <SectionTitle title={`Officials (${res.reps.length + res.mps.length})`} />
            <div className="max-h-[220px] overflow-y-auto">
              {res.reps.slice(0, 15).map((p) => <PersonRow key={p.id} person={p as any} onClick={() => navigate("rep", { id: p.id })} />)}
            </div>
            <p className="mb-1 mt-3 text-xs uppercase tracking-wider text-muted-foreground">Parliament MPs ({res.mps.length})</p>
            <div className="max-h-[220px] overflow-y-auto">
              {res.mps.slice(0, 15).map((m) => (
                <a key={m.id} href={m.profileUrl} target="_blank" rel="noreferrer" className="block rounded-lg px-2 py-1.5 text-sm hover:bg-muted">{m.fullName} · {m.officialTitle} · {m.party}</a>
              ))}
            </div>
          </Card>
        </div>
      )}
    </div>
  );
}

// ---------- STATS ----------
export function StatsPage() {
  const counties = useMemo(() => allCounties(), []);
  const agg = useMemo(() => getAggregateStats("2023/24"), []);
  const reps = useMemo(() => flattenAllCountiesRepresentatives(counties), [counties]);
  const cecms = reps.filter((r) => r.officialTitle.startsWith("CECM"));
  const verified = cecms.filter((c) => c.contacts.email || c.biography);

  return (
    <div className="space-y-6">
      <h1 className="font-display text-3xl">Platform statistics — transparency dashboard</h1>
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Counties" value="47" hint="KNBS 2019 · IEBC 2022" />
        <StatCard label="Parliament MPs" value={String(allMPs().length)} hint="parliament.go.ke scrape" />
        <StatCard label="County officials" value={String(reps.length)} hint={`${cecms.length} CECMs`} />
        <StatCard label="Finance rows" value={String(ALL_COUNTY_FINANCE.length)} hint="FY21/22 → FY23/24" />
      </div>
      <div className="grid gap-4 lg:grid-cols-2">
        <Card className="p-5">
          <SectionTitle title="Coverage honesty" />
          <ul className="space-y-2 text-sm">
            <li className="flex justify-between border-b border-border py-1"><span>Governors 2022–2027</span><strong>47 / 47</strong></li>
            <li className="flex justify-between border-b border-border py-1"><span>Senators (parliament.go.ke)</span><strong>{allSenators().length} / 47</strong></li>
            <li className="flex justify-between border-b border-border py-1"><span>Women reps</span><strong>{allWomenReps().length} / 47</strong></li>
            <li className="flex justify-between border-b border-border py-1"><span>MPs</span><strong>{allMPs().length} / 290 + nominated</strong></li>
            <li className="flex justify-between border-b border-border py-1"><span>Finance FY23/24 counties</span><strong>{getCountiesWithFinanceData().length} / 47</strong></li>
            <li className="flex justify-between py-1"><span>Verified CECMs</span><strong>{verified.length} / {cecms.length}</strong></li>
          </ul>
        </Card>
        <Card className="p-5">
          <SectionTitle title="Audit & absorption" />
          <div className="h-52">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={Object.entries(agg.auditOpinionCounts).map(([k, v]) => ({ name: k, count: v }))}>
                <CartesianGrid strokeDasharray="3 3" /><XAxis dataKey="name" tick={{ fontSize: 11 }} /><YAxis allowDecimals={false} /><Tooltip />
                <Bar dataKey="count" fill="#0f3d2e" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
          <p className="mt-2 text-xs text-muted-foreground">Avg absorption {agg.avgOverallAbsorption.toFixed(1)}% · dev {agg.avgDevelopmentAbsorption.toFixed(1)}% · pending sampled counties only.</p>
        </Card>
      </div>
      <Card className="p-5">
        <SectionTitle title="Oversight datasets bundled" />
        <div className="grid gap-2 text-sm sm:grid-cols-2 lg:grid-cols-3">
          <span>Petitions: {petitionData.length}</span><span>CIDP projects: {cidpProjectData.length}</span><span>Revenue rows: {revenueAutonomyData.length}</span>
          <span>Gender rows: {genderInclusionData.length}</span><span>Border conflicts: {borderConflictData.length}</span><span>Climate rows: {climateEnvironmentData.length}</span>
          <span>Service rows: {serviceDeliveryData.length}</span><span>DPI rows: {dpiData.length}</span><span>Budget quarterly: {budgetQuarterlyData.length}</span>
        </div>
        <div className="mt-3 flex flex-wrap gap-2">
          {KENYA_OVERSIGHT_FEATURES.map((f) => (
            <span key={f.id} className="rounded-full border border-border px-2 py-1 text-[11px]">{f.icon} {f.title}</span>
          ))}
        </div>
      </Card>
      <Card className="p-5">
        <SectionTitle kicker="kenya-county-data" title="Data infrastructure — 11 domains" />
        <p className="mb-3 text-sm text-muted-foreground">
          Every county page carries a “County data file” with tabs for all 11 folders below, each with its ingestion pipeline and sources.
          Master file: <a href="/data/counties/county_master.json" target="_blank" rel="noreferrer" className="text-ke-green underline">county_master.json (47 counties)</a> ·
          Boundaries: <span className="font-mono text-xs">county_boundaries.geojson</span> (properties only — fetch official geometries, never invented) ·
          Schema: <span className="font-mono text-xs">kenya-county-data/database/schema.sql</span>
        </p>
        <div className="flex flex-wrap gap-2 text-xs">
          {["counties","demographics","health","education","agriculture","finance","infrastructure","projects","governance","procurement","environment","elections"].map((d) => (
            <span key={d} className="rounded-full border border-border px-2.5 py-1 font-mono">data/{d}</span>
          ))}
        </div>
        <p className="mt-3 text-[11px] text-muted-foreground">ingestion/knbs · ingestion/treasury · ingestion/cog · ingestion/county_portals · ingestion/validation → backend/ → frontend/ → database/</p>
      </Card>
    </div>
  );
}

// ---------- FEEDBACK ----------
interface FeedbackItem { id: string; name: string; county: string; topic: string; message: string; status: string; at: number; created_at?: number; }
export function FeedbackPage() {
  const { user } = useAuth();
  const [items, setItems] = useState<FeedbackItem[]>([]);
  const [via, setVia] = useState<"backend" | "local">("local");
  const [form, setForm] = useState({ name: "", county: "Nairobi City", topic: "Service delivery", message: "" });
  useEffect(() => { listFeedback().then((r) => { setItems(r.items); setVia(r.via); }); }, []);
  useEffect(() => {
    if (user && !form.name) setForm((f) => ({ ...f, name: user.displayName || user.email || f.name }));
  }, [user]);
  async function submit(e: FormEvent) {
    e.preventDefault();
    await submitFeedback(form);
    const fresh = await listFeedback();
    setItems(fresh.items); setVia(fresh.via);
    setForm({ ...form, message: "" });
  }
  return (
    <div className="space-y-6">
      <h1 className="font-display text-3xl">Public feedback</h1>
      <p className="text-sm text-muted-foreground">
        {user ? <>Signed in as <strong>{user.displayName || user.email}</strong> — submissions carry your name. </> : <>Sign in with Google (top-right) to attach your name, or submit as guest. </>}
        Storage: {via === "backend" ? "backend SQLite database" : "this browser (set a Backend URL in Admin to use the database)"}.
      </p>
      <Card className="p-5">
        <form onSubmit={submit} className="grid gap-3">
          <input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Your name" className="h-10 rounded-xl border border-border bg-background px-3" />
          <div className="grid gap-3 sm:grid-cols-2">
            <select value={form.county} onChange={(e) => setForm({ ...form, county: e.target.value })} className="h-10 rounded-xl border border-border bg-background px-3">{allCounties().map((c) => <option key={c.code}>{c.name}</option>)}</select>
            <select value={form.topic} onChange={(e) => setForm({ ...form, topic: e.target.value })} className="h-10 rounded-xl border border-border bg-background px-3">{["Service delivery","Roads","Health","Water","Corruption concern","Budget"].map((t) => <option key={t}>{t}</option>)}</select>
          </div>
          <textarea required value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} rows={4} placeholder="Your feedback" className="rounded-xl border border-border bg-background px-3 py-2" />
          <button className="inline-flex h-10 items-center justify-center gap-2 rounded-xl bg-ke-green text-white"><Send className="h-4 w-4" /> Submit</button>
        </form>
      </Card>
      <div className="space-y-3">
        {items.map((it) => (
          <Card key={it.id} className="p-4">
            <div className="flex justify-between gap-3"><div><p className="font-medium">{it.topic} · {it.county}</p><p className="text-sm text-muted-foreground">{it.message}</p><p className="mt-1 text-[11px] text-muted-foreground">{it.name} · {new Date(it.at ?? it.created_at ?? Date.now()).toLocaleString()}</p></div><span className="h-fit rounded-full bg-amber-100 px-2 py-0.5 text-[11px] text-amber-800">{it.status}</span></div>
          </Card>
        ))}
        {items.length === 0 && <p className="text-sm text-muted-foreground">No submissions yet.</p>}
      </div>
    </div>
  );
}

// ---------- WHISTLEBLOWER ----------
function b64(bytes: Uint8Array) { let s = ""; for (let i = 0; i < bytes.length; i++) s += String.fromCharCode(bytes[i]); return btoa(s); }
async function encryptPayload(text: string) {
  const key = await crypto.subtle.generateKey({ name: "AES-GCM", length: 256 }, true, ["encrypt"]);
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const cipher = await crypto.subtle.encrypt({ name: "AES-GCM", iv }, key, new TextEncoder().encode(text));
  const raw = await crypto.subtle.exportKey("raw", key);
  return { ciphertext: b64(new Uint8Array(cipher)), iv: b64(iv), wrappedKey: b64(new Uint8Array(raw)) };
}
export function WhistleblowerPage() {
  const [ticket, setTicket] = useState("");
  const [status, setStatus] = useState("");
  const [form, setForm] = useState({ category: "Procurement", county: "Nairobi City", evidence: "" });
  async function submit(e: FormEvent) {
    e.preventDefault();
    const env = await encryptPayload(JSON.stringify(form));
    const r = await submitEnvelope({ category: form.category, county: form.county, ...env });
    setTicket(`${r.ticket} (${r.via === "backend" ? "stored in backend DB" : "stored in this browser"})`);
    setForm({ ...form, evidence: "" });
  }
  async function track() {
    setTicket(await trackTicket(status));
  }
  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2"><Lock className="h-6 w-6 text-ke-green" /><h1 className="font-display text-3xl">Whistleblower portal</h1></div>
      <Card className="border-amber-300 bg-amber-50 p-4 text-sm text-amber-950 dark:border-amber-800 dark:bg-amber-950/40 dark:text-amber-100">
        AES-256-GCM envelope encrypted in your browser. With the backend running it is stored as ciphertext only in SQLite (ticket to track); otherwise it stays in this browser. The server never sees plaintext.
      </Card>
      <div className="grid gap-4 lg:grid-cols-2">
        <Card className="p-5">
          <SectionTitle title="Submit encrypted envelope" />
          <form onSubmit={submit} className="grid gap-3">
            <select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} className="h-10 rounded-xl border border-border bg-background px-3">{["Procurement","Ghost workers","Pending bills","Land","Police / extra-legal","Other"].map((c) => <option key={c}>{c}</option>)}</select>
            <select value={form.county} onChange={(e) => setForm({ ...form, county: e.target.value })} className="h-10 rounded-xl border border-border bg-background px-3">{allCounties().map((c) => <option key={c.code}>{c.name}</option>)}</select>
            <textarea required value={form.evidence} onChange={(e) => setForm({ ...form, evidence: e.target.value })} rows={6} placeholder="Describe the issue. Do not include your name." className="rounded-xl border border-border bg-background px-3 py-2" />
            <button className="h-10 rounded-xl bg-ke-black text-white dark:bg-primary dark:text-primary-foreground">Encrypt & submit</button>
          </form>
          {ticket.startsWith("WB-") && <p className="mt-3 rounded-xl bg-emerald-50 p-3 text-sm text-emerald-900">Ticket <strong>{ticket}</strong> — save this ID.</p>}
        </Card>
        <Card className="p-5">
          <SectionTitle title="Track a ticket" />
          <div className="flex gap-2"><input value={status} onChange={(e) => setStatus(e.target.value)} placeholder="WB-XXXXXX" className="h-10 flex-1 rounded-xl border border-border bg-background px-3" /><button onClick={track} className="h-10 rounded-xl border border-border px-4">Track</button></div>
          {ticket && <p className="mt-3 text-sm">{ticket}</p>}
          <div className="mt-6 flex items-start gap-2 text-sm text-muted-foreground"><ShieldCheck className="mt-0.5 h-4 w-4 text-ke-green" /> Private key never touches a server in the production design.</div>
        </Card>
      </div>
    </div>
  );
}

// ---------- AI ----------
function answerQuestion(q: string): string {
  const s = q.toLowerCase();
  const agg = getAggregateStats("2023/24");
  if (s.includes("best") || s.includes("unmodified") || s.includes("clean")) {
    const list = ALL_COUNTY_FINANCE.filter((c) => c.fiscalYear === "2023/24" && c.auditOpinion === "Unmodified").map((c) => c.countyName);
    return `Unmodified (clean) in FY23/24 CoB extract: ${list.join(", ") || "none"}. National OAG: 0/47 executives unmodified FY23/24, 1/47 FY24/25 (name in PDF).`;
  }
  if (s.includes("worst") || s.includes("bottom") || s.includes("adverse") || s.includes("disclaimer")) {
    return `Lowest CoG: ${agg.bottomPerformers.map((c) => `${c.countyName} (${c.complianceScore}, ${c.auditOpinion})`).join("; ")}. Published scores, not accusations.`;
  }
  if (s.includes("pending")) {
    return `Sampled pending bills total ${(agg.totalPendingBills/1000).toFixed(1)}B across CoB extract. National aggregate per NATIONAL_SUMMARY: ${NATIONAL_SUMMARY.cobBudgetFY2023_24.pendingBills} (CoB).`;
  }
  if (s.includes("nairobi")) {
    const n = getCountyFinance("Nairobi City", "2023/24");
    return n ? `Nairobi City FY23/24: budget ${n.approvedBudget}M, absorption ${n.overallAbsorption}%, dev ${n.developmentAbsorption}%, pending ${n.pendingBills}M, audit ${n.auditOpinion}, CoG ${n.complianceScore}. Governor Johnson Sakaja (UDA). Source: ${n.source}` : "Nairobi finance N/A.";
  }
  if (s.includes("debt")) return `Public debt FY23/24: Kshs 10.58T (National Treasury/OAG). CoB aggregate county absorption 79.5%, dev 37%.`;
  if (s.includes("governor") && s.includes("how many")) return `47 county governors, term 2022–2027, per IEBC 2022. Full succession since 2013 on the History page.`;
  if (s.includes("senator") && s.includes("how many")) return `47 elected senators + nominated, per parliament.go.ke (${allSenators().length} bundled). See the Senate page.`;
  if (s.includes("mp") || s.includes("parliament")) return `${allMPs().length} MPs bundled from parliament.go.ke (290 constituencies + nominated). Ask for a county, e.g. “MPs Kisumu”.`;
  const countyHit = allCounties().find((c) => s.includes(c.name.toLowerCase()));
  if (countyHit) {
    const f = getCountyFinance(countyHit.name, "2023/24");
    return `${countyHit.name} (code ${countyHit.code}, ${countyHit.region}) — Governor ${countyHit.governor.fullName} (${countyHit.governor.party}). ${f ? `FY23/24 absorption ${f.overallAbsorption}%, dev ${f.developmentAbsorption}%, audit ${f.auditOpinion}, CoG ${f.complianceScore}, pending ${f.pendingBills}M.` : "Finance N/A in extract."} Score overall ${countyHit.governor.scorecard.overallAccountability.score ?? "N/A"}.`;
  }
  if (s.includes("dpi") || s.includes("ranking") || s.includes("performance")) {
    const top = [...dpiData].sort((a,b) => b.overallDPI - a.overallDPI).slice(0,3).map((d) => `${d.countyName} ${d.overallDPI}`).join(", ");
    return `Top DPI in bundle: ${top}. DPI = financial + service + transparency + governance (OAG+CoB+TI+KNBS).`;
  }
  return `Rule-based assistant (no live LLM in this static build; original uses Mistral). I answer from bundled OAG/CoB/KNBS/parliament records — try “best audit”, “Nairobi”, “pending bills”, a county name, or “DPI”. I never invent figures.`;
}

export function AIPage() {
  const [q, setQ] = useState("");
  const [chat, setChat] = useState<{ role: "user" | "ai"; text: string }[]>([{ role: "ai", text: "Ask about county finance, audits, governors, MPs, DPI, pending bills. Answers cite bundled OAG/CoB/KNBS/parliament records." }]);
  function send(e: FormEvent) {
    e.preventDefault();
    if (!q.trim()) return;
    setChat((c) => [...c, { role: "user", text: q }, { role: "ai", text: answerQuestion(q) }]);
    setQ("");
  }
  return (
    <div className="mx-auto max-w-2xl space-y-4">
      <div className="flex items-center gap-2"><Bot className="h-6 w-6 text-ke-green" /><h1 className="font-display text-3xl">AI assistant</h1></div>
      <p className="text-sm text-muted-foreground">Rule-based fallback with real bundled data. Original GovDash adds Mistral AI when key configured.</p>
      <Card className="flex h-[520px] flex-col p-4">
        <div className="flex-1 space-y-3 overflow-y-auto pr-1">
          {chat.map((m, i) => <div key={i} className={`max-w-[92%] rounded-2xl px-3 py-2 text-sm ${m.role === "ai" ? "bg-muted" : "ml-auto bg-ke-green text-white"}`}>{m.text}</div>)}
        </div>
        <form onSubmit={send} className="mt-3 flex gap-2">
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Which counties have unmodified audits?" className="h-11 flex-1 rounded-full border border-border bg-background px-4 text-sm" />
          <button className="h-11 rounded-full bg-ke-green px-4 text-white">Send</button>
        </form>
      </Card>
      <div className="flex flex-wrap gap-2 text-xs">
        {["Best audit?", "Nairobi finance", "Pending bills?", "DPI ranking", "Governors how many?"].map((s) => (
          <button key={s} onClick={() => { setChat((c) => [...c, { role: "user", text: s }, { role: "ai", text: answerQuestion(s) }]); }} className="rounded-full border border-border px-3 py-1">{s}</button>
        ))}
      </div>
    </div>
  );
}

// ---------- ADMIN ----------
const ADMIN_PASSWORD = "fb0599a99117931085153a59";
export function AdminPage() {
  const [authed, setAuthed] = useState(() => sessionStorage.getItem("kgd-admin") === "1");
  const [pw, setPw] = useState("");
  const [err, setErr] = useState("");
  const [tab, setTab] = useState<"resources" | "finance" | "cecm" | "wb" | "backend">("resources");
  const [backend, setBackend] = useState<{ ok: boolean; counts?: Record<string, number>; url: string }>({ ok: false, url: "" });
  const [apiUrl, setApiUrl] = useState(() => { try { return localStorage.getItem("kgd-api-url") || ""; } catch { return ""; } });
  useEffect(() => { backendHealth().then(setBackend); }, [tab]);
  const counties = useMemo(() => allCounties(), []);
  const reps = useMemo(() => flattenAllCountiesRepresentatives(counties), [counties]);
  const cecms = reps.filter((r) => r.officialTitle.startsWith("CECM"));
  const verified = cecms.filter((c) => c.contacts.email || c.biography).length;

  if (!authed) {
    return (
      <div className="mx-auto max-w-sm space-y-4 pt-10">
        <h1 className="font-display text-3xl">Admin console</h1>
        <p className="text-sm text-muted-foreground">Demo password from README: <code>fb0599a99117931085153a59</code>. Production fails closed without ADMIN_PASSWORD_HASH + JWT_SECRET.</p>
        <form onSubmit={(e) => { e.preventDefault(); if (pw === ADMIN_PASSWORD) { sessionStorage.setItem("kgd-admin", "1"); setAuthed(true); } else setErr("Invalid password"); }} className="grid gap-3">
          <input type="password" value={pw} onChange={(e) => setPw(e.target.value)} placeholder="Password" className="h-11 rounded-xl border border-border bg-background px-3" />
          <button className="h-11 rounded-xl bg-ke-black text-white dark:bg-primary dark:text-primary-foreground">Sign in</button>
          {err && <p className="text-sm text-rose-600">{err}</p>}
        </form>
      </div>
    );
  }
  const wb = JSON.parse(localStorage.getItem("kgd-wb") || "[]") as { id: string; status: string; category: string; county: string }[];
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between"><h1 className="font-display text-3xl">Admin console</h1><button className="text-sm underline" onClick={() => { sessionStorage.removeItem("kgd-admin"); setAuthed(false); }}>Sign out</button></div>
      <div className="flex flex-wrap gap-2">
        {(["resources","finance","cecm","wb","backend"] as const).map((t) => <button key={t} onClick={() => setTab(t)} className={`rounded-full px-3 py-1 text-sm ${tab === t ? "bg-ke-green text-white" : "border border-border"}`}>{t === "resources" ? "Oversight resources" : t === "finance" ? `Finance snapshots (${ALL_COUNTY_FINANCE.length})` : t === "cecm" ? `CECM verification (${verified}/${cecms.length})` : t === "backend" ? `Backend ${backend.ok ? "● live" : "○ static"}` : `Whistleblower (${wb.length})`}</button>)}
      </div>
      {tab === "resources" && (
        <Card className="p-5 text-sm">
          {[
            ["OAG","oagkenya.go.ke","Audit opinions, pending bills"],
            ["CoB","cob.go.ke","Budget execution, absorption"],
            ["CoG","cog.go.ke","Compliance scores"],
            ["KNBS","knbs.or.ke","2019 Census"],
            ["Parliament","parliament.go.ke","MPs, senators, women reps"],
            ["IEBC","iebc.or.ke","2022 results"],
            ["EACC","eacc.go.ke","Ethics"],
            ["TI-Kenya","tikenya.org","Governance"],
          ].map(([n, u, d]) => <div key={n} className="flex justify-between border-b border-border py-2"><span><strong>{n}</strong> — {d}</span><a href={`https://${u}`} target="_blank" rel="noreferrer" className="text-ke-green">link <ExternalLink className="inline h-3 w-3" /></a></div>)}
        </Card>
      )}
      {tab === "finance" && (
        <Card className="overflow-x-auto p-5">
          <table className="w-full text-sm"><thead><tr className="text-left text-xs uppercase text-muted-foreground"><th>County</th><th>FY</th><th>Absorption</th><th>Audit</th></tr></thead>
          <tbody>{ALL_COUNTY_FINANCE.slice(0, 60).map((r) => <tr key={`${r.countyName}-${r.fiscalYear}`} className="border-t border-border"><td className="py-1">{r.countyName}</td><td>{r.fiscalYear}</td><td>{r.overallAbsorption}%</td><td>{r.auditOpinion}</td></tr>)}</tbody></table>
          <p className="mt-2 text-xs text-muted-foreground">Showing 60 of {ALL_COUNTY_FINANCE.length}. Full CSV export on Finance page.</p>
        </Card>
      )}
      {tab === "cecm" && (
        <Card className="p-5">
          <p className="mb-3 text-sm">Verified (email or bio present): {verified} / {cecms.length} ({Math.round((verified / Math.max(1, cecms.length)) * 100)}%)</p>
          <div className="h-3 overflow-hidden rounded-full bg-muted"><div className="h-full bg-ke-green" style={{ width: `${(verified / Math.max(1, cecms.length)) * 100}%` }} /></div>
          <DataGap note="Unverified rows stay listed so gaps remain visible — matches original CECM verification panel." />
        </Card>
      )}
      {tab === "wb" && (
        <Card className="p-5">
          {wb.length === 0 && <p className="text-sm text-muted-foreground">No local envelopes in this browser.</p>}
          {wb.map((w) => <div key={w.id} className="flex justify-between border-b border-border py-2 text-sm"><span>{w.id} · {w.category} · {w.county}</span><span>{w.status}</span></div>)}
        </Card>
      )}
      {tab === "backend" && (
        <div className="space-y-4">
          <Card className="p-5">
            <SectionTitle kicker="SQLite + REST" title={`Backend ${backend.ok ? "connected" : "not connected"}`} />
            <p className="mb-3 text-sm text-muted-foreground">
              {backend.ok
                ? `Live at ${backend.url} — feedback, whistleblower envelopes and alerts are being written to the SQLite database.`
                : "Static mode — writes stay in this browser. Start the backend and set its URL below to persist to SQLite."}
            </p>
            {backend.counts && (
              <div className="mb-3 grid grid-cols-2 gap-2 text-sm sm:grid-cols-4">
                {Object.entries(backend.counts).map(([k, v]) => (
                  <div key={k} className="rounded-xl border border-border p-2 text-center"><p className="text-[10px] uppercase tracking-wider text-muted-foreground">{k}</p><p className="font-display text-xl">{v}</p></div>
                ))}
              </div>
            )}
            <form
              className="flex gap-2"
              onSubmit={(e) => {
                e.preventDefault();
                try { localStorage.setItem("kgd-api-url", apiUrl.trim()); } catch { /* ignore */ }
                backendHealth().then(setBackend);
              }}
            >
              <input value={apiUrl} onChange={(e) => setApiUrl(e.target.value)} placeholder="http://localhost:3001" className="h-10 flex-1 rounded-xl border border-border bg-background px-3 text-sm" />
              <button className="h-10 rounded-xl bg-ke-green px-4 text-sm text-white">Connect</button>
              {apiUrl && (
                <button type="button" className="h-10 rounded-xl border border-border px-4 text-sm"
                  onClick={() => { try { localStorage.removeItem("kgd-api-url"); } catch { /* ignore */ } setApiUrl(""); backendHealth().then(setBackend); }}>
                  Disconnect
                </button>
              )}
            </form>
            <div className="mt-4 rounded-xl bg-muted/50 p-3 font-mono text-[11px] leading-relaxed">
              <p># run the backend (zero extra services — Node 20 + sql.js):</p>
              <p>node server/seed.mjs # first run</p>
              <p>PORT=3001 node server/index.mjs</p>
              <p># endpoints: /api/health /api/counties /api/finance /api/parliament</p>
              <p># /api/history /api/search /api/stats /api/feedback /api/whistleblower /api/alerts</p>
              <p># county sites + FY reports: /api/sites /api/reports (fed by node server/scrape.mjs)</p>
            </div>
          </Card>
          <Card className="p-5">
            <SectionTitle kicker="Firebase" title="Google sign-in setup (5 min)" />
            <ol className="list-decimal space-y-2 pl-5 text-sm text-muted-foreground">
              <li>Open <a className="text-ke-green underline" href="https://console.firebase.google.com/" target="_blank" rel="noreferrer">console.firebase.google.com</a> → Add project (any name, Analytics optional).</li>
              <li>Build → Authentication → Get started → Sign-in method → enable <strong>Google</strong> → Save.</li>
              <li>Project Overview → Add app → Web → copy the <span className="font-mono">firebaseConfig</span> values.</li>
              <li>Set env and rebuild: <span className="font-mono">VITE_FIREBASE_API_KEY</span>, <span className="font-mono">VITE_FIREBASE_AUTH_DOMAIN</span>, <span className="font-mono">VITE_FIREBASE_PROJECT_ID</span>, <span className="font-mono">VITE_FIREBASE_APP_ID</span>.</li>
              <li>Back in Authentication → Settings → Authorized domains → add your deployed domain.</li>
            </ol>
            <p className="mt-3 text-xs text-muted-foreground">Once configured, the header shows Sign in with Google; signed-in names attach to feedback submissions. Nothing else changes — data still comes from SQLite/bundled sources.</p>
          </Card>
        </div>
      )}
    </div>
  );
}

// ---------- OVERSIGHT ----------
export function OversightPage({ section }: { section: string }) {
  const { navigate } = useRouter();
  if (section === "constitution") {
    return (
      <div className="space-y-6">
        <h1 className="font-display text-3xl">Constitution of Kenya 2010 — devolution</h1>
        <p className="max-w-3xl text-sm text-muted-foreground">Chapter 11 creates 47 counties; Chapter 6 sets leadership & integrity; Art. 201 public finance principles; Art. 229 Auditor-General audits national & county governments.</p>
        <div className="grid gap-3 sm:grid-cols-2">
          {[["Chapter 6","Leadership & Integrity","State officers obligations"],["Chapter 11","Devolved Government","47 counties, Fourth Schedule functions"],["Article 201","Public finance","Openness, accountability, prudence"],["Article 229","Auditor-General","Annual audits, OAG reports"],["Article 196","Public participation","County assemblies must facilitate"],["CARA 2024","Revenue sharing","Equitable share per county"]].map(([a,b,c]) => (
            <Card key={a} className="p-4"><p className="text-xs uppercase tracking-wider text-ke-green">{a}</p><p className="font-medium">{b}</p><p className="text-xs text-muted-foreground">{c}</p></Card>
          ))}
        </div>
        <Card className="p-5 text-sm"><p>President: {NATIONAL_SUMMARY.president.fullName} ({NATIONAL_SUMMARY.president.party}) — {NATIONAL_SUMMARY.president.biography}</p><p className="mt-2">Deputy: {NATIONAL_SUMMARY.deputyPresident.fullName} — {NATIONAL_SUMMARY.deputyPresident.biography}</p></Card>
      </div>
    );
  }
  if (section === "dpi" || section === "peer") {
    const sorted = [...dpiData].sort((a,b) => b.overallDPI - a.overallDPI);
    return (
      <div className="space-y-6">
        <h1 className="font-display text-3xl">Devolution Performance Index (DPI)</h1>
        <p className="text-sm text-muted-foreground">Composite: financial + service + transparency + governance. OAG + CoB + TI-Kenya + KNBS. Only bundled counties shown — not a full 47 ranking.</p>
        {sorted.map((d) => (
          <button key={d.countyCode} onClick={() => navigate("county", { code: String(d.countyCode) })} className="block w-full rounded-xl border border-border bg-card p-4 text-left hover:shadow">
            <div className="flex justify-between"><span className="font-medium">#{d.rank} {d.countyName}</span><strong>{d.overallDPI}/100 ({d.trendVsPreviousYear ?? "—"})</strong></div>
            <div className="mt-2 grid grid-cols-4 gap-2 text-[11px]"><span>Fin {d.financialManagement}</span><span>Service {d.serviceDelivery}</span><span>Trans {d.transparency}</span><span>Gov {d.governance}</span></div>
          </button>
        ))}
      </div>
    );
  }
  if (section === "pending-bills") {
    const rows = [...ALL_COUNTY_FINANCE].filter((r) => r.fiscalYear === "2023/24").sort((a,b) => (b.pendingBills ?? 0) - (a.pendingBills ?? 0));
    const max = Math.max(...rows.map((r) => r.pendingBills ?? 0), 1);
    return (
      <div className="space-y-4">
        <h1 className="font-display text-3xl">Pending bills heatmap FY23/24</h1>
        <p className="text-sm text-muted-foreground">CoB-reported. National aggregate {NATIONAL_SUMMARY.cobBudgetFY2023_24.pendingBills}.</p>
        {rows.map((r) => (
          <button key={r.countyName} onClick={() => navigate("finance-county", { name: r.countyName })} className="block w-full rounded-xl border border-border bg-card p-3 text-left">
            <div className="flex justify-between text-sm"><span className="font-medium">{r.countyName}</span><span>{r.pendingBills != null ? `${r.pendingBills.toLocaleString()}M` : "N/A"}</span></div>
            <div className="mt-2 h-1.5 rounded-full bg-muted"><div className="h-full rounded-full bg-ke-red" style={{ width: `${((r.pendingBills ?? 0)/max)*100}%` }} /></div>
            <p className="mt-1 text-[11px] text-muted-foreground">{r.source}</p>
          </button>
        ))}
      </div>
    );
  }
  if (section === "revenue") {
    return (
      <div className="space-y-4">
        <h1 className="font-display text-3xl">County revenue autonomy</h1>
        {revenueAutonomyData.map((r) => (
          <Card key={r.countyCode} className="p-4 text-sm"><p className="font-medium">{r.countyName} ({r.fy})</p><p>OSR {r.ownSourceRevenue} ({r.osrPercentage}%) · Equitable {r.equitableShare}</p><p className="text-xs text-muted-foreground">Efficiency {r.collectionEfficiency}% · Diversification {r.revenueDiversificationIndex}/10 · {r.source}</p></Card>
        ))}
      </div>
    );
  }
  if (section === "service") {
    return (
      <div className="space-y-4">
        <h1 className="font-display text-3xl">Health & education service delivery</h1>
        {serviceDeliveryData.map((s: any, i: number) => (
          <Card key={i} className="p-4 text-sm"><p className="font-medium">{s.countyName} ({s.fy})</p><p className="text-muted-foreground">{JSON.stringify(s).slice(0, 400)}…</p><p className="text-xs text-muted-foreground">{s.source}</p></Card>
        ))}
        {serviceDeliveryData.length === 0 && <DataGap />}
      </div>
    );
  }
  if (section === "projects") {
    return (
      <div className="space-y-4">
        <h1 className="font-display text-3xl">CIDP project tracker</h1>
        {cidpProjectData.map((p) => (
          <Card key={p.id} className="p-4 text-sm"><p className="font-medium">{p.projectName}</p><p className="text-muted-foreground">{p.county} · {p.sector} · {p.status} · {p.completionPercent ?? "N/A"}% · {p.budgetAllocated} · {p.cidpPhase}</p></Card>
        ))}
      </div>
    );
  }
  if (section === "petitions" || section === "participation" || section === "civic") {
    const civic = section !== "petitions" ? civicParticipationData : [];
    return (
      <div className="space-y-4">
        <h1 className="font-display text-3xl">{section === "petitions" ? "Petitions & resolutions" : "Public participation & civic education"}</h1>
        {section === "petitions" && petitionData.map((p) => (
          <Card key={p.id} className="p-4 text-sm"><p className="font-medium">{p.title}</p><p className="text-muted-foreground">{p.category} · {p.status} · {p.county} · {p.assemblyLevel}</p><p className="text-xs">Petitioner: {p.petitioner} · {p.dateSubmitted} · outcome: {p.outcome ?? "pending"}</p></Card>
        ))}
        {section !== "petitions" && civic.map((c) => (
          <Card key={c.countyCode} className="p-4 text-sm"><p className="font-medium">{c.countyName}</p><p>Hearings {c.publicHearingsHeld} · attendance {c.averageAttendancePerHearing} · incorporation {c.feedbackIncorporationRate}% · {c.participationCompliance}</p><p className="text-xs text-muted-foreground">{c.article196ComplianceNote}</p></Card>
        ))}
      </div>
    );
  }
  if (section === "borders") {
    return (
      <div className="space-y-4">
        <h1 className="font-display text-3xl">Inter-county border conflicts</h1>
        {borderConflictData.map((b) => (
          <Card key={b.id} className="p-4 text-sm"><p className="font-medium">{b.countiesInvolved.join(" ↔ ")} — {b.severity} · {b.status}</p><p>{b.disputeType}</p><p className="text-muted-foreground">{b.description}</p><p className="text-xs">Mediation: {b.mediationBody} · {b.source}</p></Card>
        ))}
      </div>
    );
  }
  if (section === "climate") {
    return (
      <div className="space-y-4">
        <h1 className="font-display text-3xl">Climate & environment</h1>
        {climateEnvironmentData.map((c: any) => (
          <Card key={c.countyCode} className="p-4 text-sm"><p className="font-medium">{c.countyName} — NEMA {c.nemaComplianceStatus}</p><p>{c.waterResourceStatus}</p><p className="text-muted-foreground">{c.deforestationRate}</p></Card>
        ))}
      </div>
    );
  }
  if (section === "gender") {
    return (
      <div className="space-y-4">
        <h1 className="font-display text-3xl">Gender & inclusion (Art. 27 / 81b)</h1>
        {genderInclusionData.map((g) => (
          <Card key={g.countyCode} className="p-4 text-sm"><p className="font-medium">{g.countyName}</p><p>Women MCAs {g.womenMcasCount} ({g.womenMcasPercentage}%) · Female CECMs {g.femaleCecmCount} ({g.femaleCecmPercentage}%) · {g.genderBudgetCompliance ?? "compliance N/A"}</p></Card>
        ))}
      </div>
    );
  }
  if (section === "red-flags") {
    const flags = ALL_COUNTY_FINANCE.filter((r) => r.fiscalYear === "2023/24" && (r.auditOpinion === "Adverse" || r.auditOpinion === "Disclaimer" || (r.developmentAbsorption ?? 100) < 20 || (r.overallAbsorption ?? 100) < 60));
    return (
      <div className="space-y-4">
        <h1 className="font-display text-3xl">Red-flag scanner (heuristics, not findings)</h1>
        <p className="text-sm text-muted-foreground">Flags: adverse/disclaimer audit, dev absorption &lt;20%, overall &lt;60%.</p>
        {flags.map((r) => (
          <button key={r.countyName} onClick={() => navigate("finance-county", { name: r.countyName })} className="block w-full rounded-xl border border-rose-300 bg-rose-50 p-3 text-left text-sm dark:bg-rose-950/30"><strong>{r.countyName}</strong> — {r.auditOpinion} · overall {r.overallAbsorption}% · dev {r.developmentAbsorption}% · pending {r.pendingBills}M</button>
        ))}
        {flags.length === 0 && <DataGap />}
      </div>
    );
  }
  const titles: Record<string, string> = {
    wealth: "Wealth declarations", tenders: "Tender anomalies", payroll: "Ghost workers & assets",
    travel: "Travel & per-diem audit", ownership: "Beneficial ownership", contracts: "Contract performance",
    variance: "Budget variance", debt: "Debt & borrowing", alerts: "Expenditure alerts",
    sentiment: "Sentiment monitor", hotline: "Hotline reports", court: "Court cases tracker",
    bursary: "Bursary tracker", budgettracker: "Budget tracker",
  };
  return (
    <div className="space-y-6">
      <h1 className="font-display text-3xl">{titles[section] ?? section}</h1>
      {(section === "variance" || section === "debt" || section === "contracts" || section === "alerts") && (
        <Card className="p-5 text-sm">
          <p>Closest published proxies (CoB FY23/24): aggregate absorption 79.5%, dev 37%, {getCountiesWithFinanceData().length} counties with extracts. Award-level / loan-level registers are not bundled — see Finance page for county rows.</p>
          <button onClick={() => navigate("finance")} className="mt-3 rounded-full bg-ke-green px-4 py-2 text-white">Open finance</button>
        </Card>
      )}
      <DataGap note={`No complete public dataset for “${titles[section] ?? section}” is bundled in this static build. Original GovDash ingests PDFs / live feeds server-side. This panel stays empty rather than fabricating cases.`} />
      <Card className="p-5">
        <SectionTitle title="What is available instead" />
        <div className="flex flex-wrap gap-2 text-sm">
          <button onClick={() => navigate("finance")} className="rounded-full border border-border px-3 py-1">Finance & audit</button>
          <button onClick={() => navigate("oversight", { section: "dpi" })} className="rounded-full border border-border px-3 py-1">DPI</button>
          <button onClick={() => navigate("oversight", { section: "pending-bills" })} className="rounded-full border border-border px-3 py-1">Pending bills</button>
          <button onClick={() => navigate("whistleblower")} className="rounded-full border border-border px-3 py-1">Whistleblower</button>
        </div>
      </Card>
      <p className="text-[11px] text-muted-foreground">Feature registry: {KENYA_OVERSIGHT_FEATURES.find((f) => f.id === section)?.description ?? "See original repo KENYA_OVERSIGHT_FEATURES."}</p>
    </div>
  );
}
