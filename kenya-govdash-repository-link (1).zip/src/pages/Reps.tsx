import { useMemo, useState } from "react";
import { ExternalLink } from "lucide-react";
import { allCounties, allMPs, allSenators, allWomenReps, flattenAllCountiesRepresentatives } from "../lib/real-store";
import { useRouter } from "../lib/router";
import { Avatar, Card } from "../components/ui";

type Tab = "governors" | "senators" | "women" | "mps" | "cecms";

export function RepsPage() {
  const { navigate } = useRouter();
  const [tab, setTab] = useState<Tab>("governors");
  const [q, setQ] = useState("");
  const [county, setCounty] = useState("All");
  const [page, setPage] = useState(0);
  const pageSize = 24;

  const counties = useMemo(() => allCounties(), []);
  const mps = useMemo(() => allMPs(), []);
  const senators = useMemo(() => allSenators(), []);
  const women = useMemo(() => allWomenReps(), []);
  const allCountyReps = useMemo(() => flattenAllCountiesRepresentatives(counties), [counties]);
  const cecms = useMemo(() => allCountyReps.filter((r) => r.officialTitle.startsWith("CECM")), [allCountyReps]);

  const governors = useMemo(() => counties.map((c) => c.governor), [counties]);

  const filteredMPs = useMemo(() => mps.filter((m) => {
    if (county !== "All" && String(m.countyCode) !== county) return false;
    if (q) {
      const s = `${m.fullName} ${m.officialTitle} ${m.party} ${m.jurisdiction} ${m.countyName}`.toLowerCase();
      if (!s.includes(q.toLowerCase())) return false;
    }
    return true;
  }), [mps, q, county]);

  const filteredCecms = useMemo(() => cecms.filter((c) => {
    if (county !== "All" && String(c.countyCode) !== county) return false;
    if (q && !`${c.fullName} ${c.officialTitle} ${c.jurisdiction}`.toLowerCase().includes(q.toLowerCase())) return false;
    return true;
  }), [cecms, q, county]);

  const filteredGovs = useMemo(() => governors.filter((g) => {
    if (q && !`${g.fullName} ${g.party} ${g.jurisdiction}`.toLowerCase().includes(q.toLowerCase())) return false;
    if (county !== "All" && String(g.countyCode) !== county) return false;
    return true;
  }), [governors, q, county]);

  const list = tab === "mps" ? filteredMPs : tab === "cecms" ? filteredCecms : tab === "governors" ? filteredGovs : tab === "senators" ? senators.filter((s) => !q || `${s.fullName} ${s.party} ${s.countyName}`.toLowerCase().includes(q.toLowerCase())) : women.filter((s) => !q || `${s.fullName} ${s.party} ${s.countyName}`.toLowerCase().includes(q.toLowerCase()));

  const slice = list.slice(page * pageSize, (page + 1) * pageSize);
  const pages = Math.max(1, Math.ceil(list.length / pageSize));

  return (
    <div className="space-y-6">
      <div>
        <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-ke-red">Parliament of Kenya · IEBC 2022 · County gazettes</p>
        <h1 className="font-display text-3xl sm:text-4xl">Representatives directory</h1>
        <p className="mt-1 text-sm text-muted-foreground">{governors.length} governors · {senators.length} senators · {women.length} women reps · {mps.length} MPs · {cecms.length} CECMs</p>
      </div>

      <div className="flex flex-wrap gap-2">
        {([["governors", `Governors (${governors.length})`],["senators", `Senators (${senators.length})`],["women", `Women Reps (${women.length})`],["mps", `MPs (${mps.length})`],["cecms", `CECMs (${cecms.length})`]] as [Tab, string][]).map(([id, label]) => (
          <button key={id} onClick={() => { setTab(id); setPage(0); }} className={`rounded-full px-3 py-1.5 text-sm ${tab === id ? "bg-ke-green text-white" : "border border-border"}`}>{label}</button>
        ))}
      </div>

      <div className="flex flex-wrap gap-2">
        <input value={q} onChange={(e) => { setQ(e.target.value); setPage(0); }} placeholder={tab === "mps" ? "Search MP, constituency, party…" : "Search by name, county, party…"} className="h-10 min-w-[200px] flex-1 rounded-full border border-border bg-card px-4 text-sm" />
        <select value={county} onChange={(e) => { setCounty(e.target.value); setPage(0); }} className="h-10 rounded-full border border-border bg-card px-3 text-sm">
          <option value="All">All counties</option>
          {counties.map((c) => <option key={c.code} value={String(c.code)}>{c.name}</option>)}
        </select>
      </div>

      <p className="text-xs text-muted-foreground">{list.length} results · page {page + 1} / {pages} · sources: parliament.go.ke, IEBC, county assemblies</p>

      {tab === "mps" && (
        <div className="grid gap-2 sm:grid-cols-2 xl:grid-cols-3">
          {(slice as typeof mps).map((m) => (
            <a key={m.id} href={m.profileUrl} target="_blank" rel="noreferrer" className="flex items-center gap-3 rounded-2xl border border-border bg-card p-3 hover:shadow-md">
              <Avatar name={m.fullName} />
              <div className="min-w-0 flex-1">
                <p className="truncate font-medium">{m.fullName} <ExternalLink className="inline h-3 w-3 text-muted-foreground" /></p>
                <p className="truncate text-xs text-muted-foreground">{m.officialTitle} · {m.countyName}</p>
                <span className="mt-1 inline-block rounded-full border border-border px-2 py-0.5 text-[11px]">{m.party} · {m.coalition}</span>
              </div>
            </a>
          ))}
        </div>
      )}

      {tab === "senators" && (
        <div className="grid gap-2 sm:grid-cols-2 xl:grid-cols-3">
          {(slice as typeof senators).map((m) => (
            <a key={m.id} href={m.profileUrl} target="_blank" rel="noreferrer" className="flex items-center gap-3 rounded-2xl border border-border bg-card p-3 hover:shadow-md">
              <Avatar name={m.fullName} />
              <div className="min-w-0 flex-1">
                <p className="truncate font-medium">{m.fullName}</p>
                <p className="truncate text-xs text-muted-foreground">{m.officialTitle} · Elected</p>
                <span className="mt-1 inline-block rounded-full border border-border px-2 py-0.5 text-[11px]">{m.party} · {m.coalition}</span>
              </div>
            </a>
          ))}
        </div>
      )}

      {tab === "women" && (
        <div className="grid gap-2 sm:grid-cols-2 xl:grid-cols-3">
          {(slice as typeof women).map((m: any) => (
            <a key={m.id} href={m.profileUrl} target="_blank" rel="noreferrer" className="flex items-center gap-3 rounded-2xl border border-border bg-card p-3 hover:shadow-md">
              <Avatar name={m.fullName} />
              <div className="min-w-0 flex-1">
                <p className="truncate font-medium">{m.fullName}</p>
                <p className="truncate text-xs text-muted-foreground">{m.officialTitle}</p>
                <span className="mt-1 inline-block rounded-full border border-border px-2 py-0.5 text-[11px]">{m.party} · {m.coalition}</span>
              </div>
            </a>
          ))}
        </div>
      )}

      {(tab === "governors" || tab === "cecms") && (
        <div className="grid gap-2 sm:grid-cols-2 xl:grid-cols-3">
          {(slice as any[]).map((p) => (
            <button key={p.id} onClick={() => navigate("rep", { id: p.id })} className="flex items-center gap-3 rounded-2xl border border-border bg-card p-3 text-left hover:shadow-md">
              <Avatar name={p.fullName} />
              <div className="min-w-0 flex-1">
                <p className="truncate font-medium">{p.fullName}</p>
                <p className="truncate text-xs text-muted-foreground">{p.officialTitle}</p>
                <span className="mt-1 inline-block rounded-full border border-border px-2 py-0.5 text-[11px]">{p.party || p.coalition} · {p.coalition}</span>
              </div>
            </button>
          ))}
        </div>
      )}

      <div className="flex justify-center gap-2">
        <button disabled={page === 0} onClick={() => setPage((p) => p - 1)} className="rounded-full border border-border px-4 py-1.5 text-sm disabled:opacity-40">Prev</button>
        <span className="px-2 py-1.5 text-sm text-muted-foreground">{page + 1} / {pages}</span>
        <button disabled={page + 1 >= pages} onClick={() => setPage((p) => p + 1)} className="rounded-full border border-border px-4 py-1.5 text-sm disabled:opacity-40">Next</button>
      </div>

      <Card className="p-4 text-xs text-muted-foreground">
        Parliament profiles link to parliament.go.ke. Governor/CECM profiles open GovDash scorecards with OAG audit, CoB absorption, contacts and sources. Data gaps are shown as N/A.
      </Card>
    </div>
  );
}
