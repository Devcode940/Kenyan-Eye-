import { useMemo, useState } from "react";
import { MapPin, Users, Landmark, Scale, ArrowRight, Filter, ShieldCheck, TrendingUp, AlertTriangle, Search } from "lucide-react";
import { allCounties, NATIONAL_SUMMARY, getAggregateStats, dpiData, revenueAutonomyData, allMPs, allSenators, allWomenReps, filterCounties, getDataQualityScore, getAllCountyFinance } from "../lib/real-store";
import { DEFAULT_FILTERS, type FilterState } from "../real/kenya-data";
import { useLanguage } from "../lib/i18n";
import { useRouter } from "../lib/router";
import { AuditBadge, Badge, Card, ScoreRing, SectionTitle, StatCard } from "../components/ui";
import { CountyMap } from "../components/CountyMap";

function coalitionColor(c: string) {
  if (c === "Kenya Kwanza") return "bg-yellow-100 text-yellow-900 border-yellow-300 dark:bg-yellow-900/30 dark:text-yellow-200";
  if (c === "Azimio") return "bg-sky-100 text-sky-900 border-sky-300 dark:bg-sky-900/30 dark:text-sky-200";
  if (c === "Independent") return "bg-stone-100 text-stone-800 border-stone-300 dark:bg-stone-800 dark:text-stone-200";
  return "bg-zinc-100 text-zinc-700 border-zinc-300 dark:bg-zinc-800 dark:text-zinc-200";
}

function CountyMapWrapper() {
  const [mode, setMode] = useState<"audit" | "absorption" | "coalition">("audit");
  return <CountyMap mode={mode} onMode={setMode} />;
}

export function HomePage() {
  const { t, countyName } = useLanguage();
  const { navigate } = useRouter();
  const counties = useMemo(() => allCounties(), []);
  const [filters, setFilters] = useState<FilterState>(DEFAULT_FILTERS);
  const [q, setQ] = useState("");

  const filtered = useMemo(() => filterCounties(counties, { ...filters, searchQuery: q }), [counties, filters, q]);
  const agg = useMemo(() => getAggregateStats("2023/24"), []);
  const financeRows = useMemo(() => getAllCountyFinance("2023/24"), []);
  const mps = useMemo(() => allMPs(), []);

  const kk = counties.filter((c) => c.governor.coalition === "Kenya Kwanza").length;
  const az = counties.filter((c) => c.governor.coalition === "Azimio").length;
  const ind = counties.length - kk - az;

  const topDPI = useMemo(() => [...dpiData].sort((a, b) => b.overallDPI - a.overallDPI).slice(0, 5), []);
  const lowRevenue = useMemo(() => [...revenueAutonomyData].sort((a, b) => (a.osrPercentage ?? 999) - (b.osrPercentage ?? 999)).slice(0, 4), []);

  return (
    <div className="space-y-8">
      <section className="relative overflow-hidden rounded-3xl border border-border">
        <img src="/images/hero.jpg" alt="Nairobi, Kenya" className="h-[360px] w-full object-cover sm:h-[440px]" />
        <div className="absolute inset-0 bg-gradient-to-r from-black/85 via-black/55 to-black/15" />
        <div className="absolute inset-0 flex flex-col justify-end p-6 sm:p-10">
          <div className="flag-stripe mb-4 h-1 w-28 rounded-full" />
          <p className="text-[11px] font-semibold uppercase tracking-[0.22em] text-ke-gold">{t("app.badge")}</p>
          <h1 className="mt-2 max-w-4xl font-display text-3xl font-semibold leading-tight text-white sm:text-5xl">{t("app.title")}</h1>
          <p className="mt-3 max-w-2xl text-sm text-white/80 sm:text-base">{t("app.subtitle")} — {counties.length} counties · {mps.length} MPs · {allSenators().length} senators · {allWomenReps().length} women reps</p>
          <div className="mt-5 flex flex-wrap gap-2">
            <button onClick={() => navigate("finance")} className="rounded-full bg-ke-green px-4 py-2 text-sm font-medium text-white">Finance & Audit FY 2023/24</button>
            <button onClick={() => navigate("reports")} className="rounded-full bg-white/10 px-4 py-2 text-sm font-medium text-white ring-1 ring-white/30">FY Reports Archive</button>
            <button onClick={() => navigate("reps")} className="rounded-full bg-white/10 px-4 py-2 text-sm font-medium text-white ring-1 ring-white/30">All representatives</button>
            <button onClick={() => navigate("compare")} className="rounded-full bg-white/10 px-4 py-2 text-sm font-medium text-white ring-1 ring-white/30">Compare counties</button>
          </div>
          <p className="mt-3 text-[11px] text-white/60">OAG summary FY 2023/24 & 2024/25 · CoB Annual CBIRR FY 2023/24 · KNBS 2019 Census · parliament.go.ke · IEBC 2022</p>
        </div>
      </section>

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Counties (devolved)" value="47" hint={`${kk} KK · ${az} Azimio · ${ind} Ind/Other`} icon={<MapPin className="h-5 w-5" />} tone="green" />
        <StatCard label="National absorption" value={`${NATIONAL_SUMMARY.cobBudgetFY2023_24.aggregateAbsorption}%`} hint={`Pending bills ${NATIONAL_SUMMARY.cobBudgetFY2023_24.pendingBills}`} icon={<Landmark className="h-5 w-5" />} tone="gold" />
        <StatCard label="OAG executives FY23/24" value={`${NATIONAL_SUMMARY.oagSummaryFY2023_24.countyExecutives.qualified} Qualified`} hint="0 unmodified · full PDF cited" icon={<ShieldCheck className="h-5 w-5" />} />
        <StatCard label="CPI 2025 / CBTS avg" value={`${NATIONAL_SUMMARY.tiKenyaData.cpi2025.score} / ${NATIONAL_SUMMARY.tiKenyaData.cbts2025.nationalAverage}`} hint={`Rank ${NATIONAL_SUMMARY.tiKenyaData.cpi2025.rank} · TI-Kenya`} icon={<Scale className="h-5 w-5" />} tone="red" />
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="p-5">
          <SectionTitle kicker="OAG" title="Audit summary" />
          <div className="space-y-2 text-sm">
            <div className="flex justify-between border-b border-border py-1.5"><span>Executives FY23/24 qualified</span><strong>47 / 47</strong></div>
            <div className="flex justify-between border-b border-border py-1.5"><span>Assemblies unmodified FY23/24</span><strong>3</strong></div>
            <div className="flex justify-between border-b border-border py-1.5"><span>Assemblies adverse FY23/24</span><strong>7</strong></div>
            <div className="flex justify-between py-1.5"><span>Executives unmodified FY24/25</span><strong>1 (see PDF)</strong></div>
          </div>
          <a href="https://oagkenya.go.ke/" target="_blank" rel="noreferrer" className="mt-3 inline-flex items-center gap-1 text-xs text-ke-green">oagkenya.go.ke <ArrowRight className="h-3 w-3" /></a>
        </Card>
        <Card className="p-5">
          <SectionTitle kicker="Controller of Budget" title="Budget execution FY23/24" />
          <div className="space-y-2 text-sm">
            <div className="flex justify-between border-b border-border py-1.5"><span>Aggregate absorption</span><strong>79.5%</strong></div>
            <div className="flex justify-between border-b border-border py-1.5"><span>Development absorption</span><strong>37%</strong></div>
            <div className="flex justify-between border-b border-border py-1.5"><span>Counties &gt;70% dev budget</span><strong>12</strong></div>
            <div className="flex justify-between py-1.5"><span>Pending bills</span><strong>Kshs 176.80B</strong></div>
          </div>
          <a href="https://cob.go.ke/" target="_blank" rel="noreferrer" className="mt-3 inline-flex items-center gap-1 text-xs text-ke-green">cob.go.ke <ArrowRight className="h-3 w-3" /></a>
        </Card>
        <Card className="p-5">
          <SectionTitle kicker="Devolution Performance" title="Top DPI counties" />
          {topDPI.map((d, i) => (
            <button key={d.countyCode} onClick={() => navigate("county", { code: String(d.countyCode) })} className="flex w-full items-center gap-2 py-1.5 text-left text-sm hover:bg-muted/50">
              <span className="w-5 font-display">{i + 1}</span>
              <span className="flex-1">{d.countyName}</span>
              <span className="font-semibold">{d.overallDPI}</span>
              <span className="text-[11px] text-muted-foreground">rank #{d.rank}</span>
            </button>
          ))}
          <p className="mt-2 text-[11px] text-muted-foreground">Source: OAG + CoB + TI-Kenya + KNBS aggregated DPI</p>
        </Card>
      </div>

      <Card className="p-5">
        <SectionTitle kicker="Interactive" title="Kenya county map — click any county" />
        <CountyMapWrapper />
      </Card>

      <section>
        <SectionTitle kicker="Devolution" title="All 47 counties" action={<span className="text-xs text-muted-foreground">{filtered.length} shown</span>} />
        <div className="mb-4 grid gap-2 lg:grid-cols-[1fr_160px_160px_160px_120px]">
          <div className="relative">
            <Search className="pointer-events-none absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Filter by county, governor, party…" className="h-9 w-full rounded-full border border-border bg-card pl-9 pr-3 text-sm outline-none" />
          </div>
          <select value={filters.region} onChange={(e) => setFilters({ ...filters, region: e.target.value as any })} className="h-9 rounded-full border border-border bg-card px-3 text-sm">
            <option value="All">All regions</option>
            {["Coast","North Eastern","Eastern","Central","Rift Valley","Western","Nyanza","Nairobi"].map((r) => <option key={r} value={r}>{r}</option>)}
          </select>
          <select value={filters.coalition} onChange={(e) => setFilters({ ...filters, coalition: e.target.value as any })} className="h-9 rounded-full border border-border bg-card px-3 text-sm">
            <option value="All">All coalitions</option><option>Kenya Kwanza</option><option>Azimio</option><option>Independent</option><option>Other</option>
          </select>
          <select value={filters.auditOpinion} onChange={(e) => setFilters({ ...filters, auditOpinion: e.target.value as any })} className="h-9 rounded-full border border-border bg-card px-3 text-sm">
            <option value="All">All audits</option><option>Unmodified</option><option>Qualified</option><option>Adverse</option><option>Disclaimer</option>
          </select>
          <button onClick={() => { setFilters(DEFAULT_FILTERS); setQ(""); }} className="inline-flex h-9 items-center justify-center gap-1 rounded-full border border-border text-sm"><Filter className="h-3 w-3" /> Reset</button>
        </div>
        <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
          {filtered.map((c) => {
            const qual = getDataQualityScore(c);
            return (
              <Card key={c.code} className="p-4" onClick={() => navigate("county", { code: String(c.code) })}>
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <p className="text-[10px] font-semibold uppercase tracking-[0.16em] text-muted-foreground">County {String(c.code).padStart(3,"0")} · {c.region}</p>
                    <h3 className="truncate font-display text-xl">{countyName(c.name)}</h3>
                    <p className="mt-0.5 truncate text-sm text-muted-foreground">{c.governor.fullName}</p>
                    <div className="mt-2 flex flex-wrap gap-1">
                      <Badge className={coalitionColor(c.governor.coalition)}>{c.governor.party || c.governor.coalition}</Badge>
                      {c.governor.auditOpinion && <AuditBadge opinion={c.governor.auditOpinion.fy2023_24.type} />}
                    </div>
                  </div>
                  <ScoreRing score={c.governor.scorecard.overallAccountability.score} size={62} label="Score" />
                </div>
                <div className="mt-3 grid grid-cols-3 gap-2 border-t border-border pt-3 text-xs">
                  <div><p className="text-muted-foreground">Absorption</p><p className="font-medium">{c.governor.budgetPerformance?.overallAbsorption.rate != null ? `${c.governor.budgetPerformance.overallAbsorption.rate}%` : "N/A"}</p></div>
                  <div><p className="text-muted-foreground">Dev</p><p className="font-medium">{c.governor.budgetPerformance?.developmentAbsorption.rate != null ? `${c.governor.budgetPerformance.developmentAbsorption.rate}%` : "N/A"}</p></div>
                  <div><p className="text-muted-foreground">Coverage</p><p className="font-medium">{qual.coveragePercent}%</p></div>
                </div>
              </Card>
            );
          })}
        </div>
      </section>

      <section className="grid gap-4 lg:grid-cols-2">
        <Card className="overflow-hidden">
          <img src="https://images.pexels.com/photos/15496542/pexels-photo-15496542.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200" alt="Nairobi" className="h-44 w-full object-cover" />
          <div className="p-5">
            <SectionTitle kicker="Revenue autonomy" title="OSR share — sample" />
            {lowRevenue.map((r) => (
              <div key={r.countyCode} className="flex justify-between border-b border-border py-1.5 text-sm last:border-0">
                <span>{r.countyName}</span><span className="text-muted-foreground">{r.osrPercentage}% OSR · {r.fy}</span>
              </div>
            ))}
            <p className="mt-2 text-[11px] text-muted-foreground">CoB annual reports; county revenue statements. Full table in County pages.</p>
          </div>
        </Card>
        <Card className="p-5">
          <SectionTitle kicker="Methodology" title="How this dashboard treats data" />
          <ul className="space-y-2 text-sm text-muted-foreground">
            <li className="flex gap-2"><TrendingUp className="mt-0.5 h-4 w-4 shrink-0 text-ke-green" /> 47 governors (IEBC 2022); {mps.length} MPs, 47 senators, 47 women reps from parliament.go.ke.</li>
            <li className="flex gap-2"><AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-amber-600" /> Missing figures are N/A — never estimated. Every number carries source + URL.</li>
            <li className="flex gap-2"><Users className="mt-0.5 h-4 w-4 shrink-0 text-ke-green" /> Finance: {financeRows.length} rows FY23/24 + historical FY21/22–22/23 for trends.</li>
            <li className="flex gap-2"><ArrowRight className="mt-0.5 h-4 w-4 shrink-0 text-ke-green" /> Avg absorption {agg.avgOverallAbsorption.toFixed(1)}% · pending Kshs {(agg.totalPendingBills/1000).toFixed(1)}B.</li>
          </ul>
          <div className="mt-4 flex flex-wrap gap-2">
            <button onClick={() => navigate("finance")} className="rounded-full bg-ke-green px-4 py-2 text-sm text-white">Open finance</button>
            <button onClick={() => navigate("reports")} className="rounded-full border border-border px-4 py-2 text-sm">FY reports</button>
            <button onClick={() => navigate("history")} className="rounded-full border border-border px-4 py-2 text-sm">Since 2013</button>
          </div>
        </Card>
      </section>
    </div>
  );
}
