import { useMemo, useState } from "react";
import { ExternalLink, Search, Landmark, FileText, Users, ArrowRight, Phone, Mail, BookOpen } from "lucide-react";
import { allSenators, allCounties } from "../lib/real-store";
import { getNominatedSenators } from "../real/kenya-parliament-senators";
import { useRouter } from "../lib/router";
import { Avatar, Card, SectionTitle, StatCard } from "../components/ui";

export function SenatePage() {
  const { navigate } = useRouter();
  const [q, setQ] = useState("");
  const [party, setParty] = useState("All");
  const senators = useMemo(() => allSenators(), []);
  const nominated = useMemo(() => getNominatedSenators(), []);
  const counties = useMemo(() => allCounties(), []);

  const parties = useMemo(() => {
    const s = new Set(senators.map((x) => x.party));
    return ["All", ...[...s].sort()];
  }, [senators]);

  const filtered = senators.filter((s) => {
    if (party !== "All" && s.party !== party) return false;
    if (q) {
      const t = `${s.fullName} ${s.party} ${s.countyName} ${s.coalition}`.toLowerCase();
      if (!t.includes(q.toLowerCase())) return false;
    }
    return true;
  });

  const kk = senators.filter((s) => s.coalition === "Kenya Kwanza").length;
  const az = senators.filter((s) => s.coalition === "Azimio").length;

  return (
    <div className="space-y-8">
      <div>
        <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-ke-red">Parliament of Kenya · The Senate · 2022–2027</p>
        <h1 className="font-display text-3xl sm:text-4xl">Senate — how to get info</h1>
        <p className="mt-1 max-w-3xl text-sm text-muted-foreground">
          The Senate represents counties, oversees county governments, debates revenue sharing (Division of Revenue Bill),
          vets county-related appointments and hears impeachment charges. Every senator below links to their official{" "}
          <span className="font-medium text-foreground">parliament.go.ke</span> profile — the primary source.
        </p>
      </div>

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Elected senators" value="47" hint="One per county" icon={<Users className="h-5 w-5" />} tone="green" />
        <StatCard label="In this dashboard" value={String(senators.length)} hint="parliament.go.ke scrape" icon={<Landmark className="h-5 w-5" />} />
        <StatCard label="Kenya Kwanza / Azimio" value={`${kk} / ${az}`} hint="By bundled party mapping" icon={<FileText className="h-5 w-5" />} tone="gold" />
        <StatCard label="Nominated" value={String(nominated.length + 20)} hint="20 gazetted + youth/PWD slots*" icon={<BookOpen className="h-5 w-5" />} />
      </div>

      <Card className="p-5">
        <SectionTitle kicker="In this dashboard" title="4 ways to get Senate info here" />
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4 text-sm">
          <button onClick={() => navigate("reps")} className="rounded-xl border border-border p-3 text-left hover:bg-muted/50">
            <p className="font-semibold">1. Representatives → Senators</p>
            <p className="mt-1 text-muted-foreground">Full directory tab with party + coalition filters. Click any name for the official profile link.</p>
          </button>
          <button onClick={() => navigate("search")} className="rounded-xl border border-border p-3 text-left hover:bg-muted/50">
            <p className="font-semibold">2. Search or ⌘K</p>
            <p className="mt-1 text-muted-foreground">Type a senator, county or party — e.g. “Sifuna”, “Nakuru”, “ODM”. Results link straight to parliament.go.ke.</p>
          </button>
          <button onClick={() => navigate("county", { code: "47" })} className="rounded-xl border border-border p-3 text-left hover:bg-muted/50">
            <p className="font-semibold">3. County pages</p>
            <p className="mt-1 text-muted-foreground">Open any of the 47 counties — the “Parliament verification” box shows that county’s senator + profile link.</p>
          </button>
          <button onClick={() => navigate("ai")} className="rounded-xl border border-border p-3 text-left hover:bg-muted/50">
            <p className="font-semibold">4. Ask the AI</p>
            <p className="mt-1 text-muted-foreground">Try “senators how many?”, “senator Kisumu”, “senator Nairobi”. Answers cite bundled records.</p>
          </button>
        </div>
      </Card>

      <section>
        <SectionTitle kicker="Directory" title={`All ${filtered.length} elected senators`} action={<span className="text-xs text-muted-foreground">Source: parliament.go.ke</span>} />
        <div className="mb-4 flex flex-wrap gap-2">
          <div className="relative min-w-[200px] flex-1">
            <Search className="pointer-events-none absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search senator, county, party…" className="h-10 w-full rounded-full border border-border bg-card pl-9 pr-3 text-sm outline-none" />
          </div>
          <select value={party} onChange={(e) => setParty(e.target.value)} className="h-10 rounded-full border border-border bg-card px-3 text-sm">
            {parties.map((p) => <option key={p}>{p}</option>)}
          </select>
        </div>
        <div className="grid gap-2 sm:grid-cols-2 xl:grid-cols-3">
          {filtered.map((s) => (
            <a key={s.id} href={s.profileUrl} target="_blank" rel="noreferrer" className="flex items-center gap-3 rounded-2xl border border-border bg-card p-3 hover:shadow-md">
              <Avatar name={s.fullName} />
              <div className="min-w-0 flex-1">
                <p className="truncate font-medium">{s.fullName} <ExternalLink className="inline h-3 w-3 text-muted-foreground" /></p>
                <p className="truncate text-xs text-muted-foreground">Senator, {s.countyName} · {s.status ?? "Elected"}</p>
                <div className="mt-1 flex flex-wrap gap-1">
                  <span className="rounded-full border border-border px-2 py-0.5 text-[11px]">{s.party}</span>
                  <span className="rounded-full border border-border px-2 py-0.5 text-[11px]">{s.coalition}</span>
                  <button onClick={(e) => { e.preventDefault(); const c = counties.find((x) => x.code === s.countyCode); if (c) navigate("county", { code: String(c.code) }); }}
                    className="rounded-full bg-muted px-2 py-0.5 text-[11px] hover:bg-ke-green hover:text-white">
                    County <ArrowRight className="inline h-3 w-3" />
                  </button>
                </div>
              </div>
            </a>
          ))}
        </div>
        {filtered.length === 0 && <p className="mt-4 text-center text-sm text-muted-foreground">No match. Try a county or party.</p>}
      </section>

      <Card className="p-5">
        <SectionTitle kicker="Special seats" title="Nominated senators" />
        <p className="mb-3 text-sm text-muted-foreground">Article 98: 16 women, 2 youth, 2 PWDs nominated by parties. Only a sample row is bundled — the full gazette list lives on parliament.go.ke.</p>
        {nominated.map((s) => (
          <a key={s.id} href={s.profileUrl} target="_blank" rel="noreferrer" className="flex items-center justify-between rounded-lg px-2 py-2 text-sm hover:bg-muted">
            <span><strong>{s.fullName}</strong> <span className="text-muted-foreground">· {s.party}</span></span>
            <span className="text-xs text-ke-green">profile <ExternalLink className="inline h-3 w-3" /></span>
          </a>
        ))}
        <a href="https://www.parliament.go.ke/the-senate/members" target="_blank" rel="noreferrer" className="mt-2 inline-block text-sm text-ke-green underline">Full nominated list on parliament.go.ke →</a>
      </Card>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card className="p-5">
          <SectionTitle kicker="Official sources" title="Get info from the Senate itself" />
          <ol className="space-y-3 text-sm">
            <li><strong>1. Member profiles:</strong> <a className="text-ke-green underline" href="https://www.parliament.go.ke/the-senate/members" target="_blank" rel="noreferrer">parliament.go.ke/the-senate/members <ExternalLink className="inline h-3 w-3" /></a> — every URL above follows <code>parliament.go.ke/the-senate/sen-…</code></li>
            <li><strong>2. Hansard (what they said):</strong> <a className="text-ke-green underline" href="https://www.parliament.go.ke/the-senate/house-business/hansard" target="_blank" rel="noreferrer">Senate Hansard <ExternalLink className="inline h-3 w-3" /></a> — verbatim debates, motions, questions to governors.</li>
            <li><strong>3. Committees (county oversight):</strong> County Public Accounts, County Public Investments & Special Funds, Delegated Legislation — reports tabled as PDFs on the Senate site.</li>
            <li><strong>4. Order Paper / Bills:</strong> Division of Revenue Bill, County Allocation of Revenue Bill — track county money from the Senate calendar.</li>
          </ol>
        </Card>
        <Card className="p-5">
          <SectionTitle kicker="Contact & visits" title="Reach or follow the Senate" />
          <ul className="space-y-2 text-sm text-muted-foreground">
            <li className="flex gap-2"><Phone className="mt-0.5 h-4 w-4 text-ke-green" /> Clerk of the Senate via parliament.go.ke “Contact Us” — +254 20 2848000, Senate Buildings, Parliament Rd, Nairobi.</li>
            <li className="flex gap-2"><Mail className="mt-0.5 h-4 w-4 text-ke-green" /> Write your county senator through their parliament.go.ke profile page (contact tab) or county office — county pages in GovDash show the link.</li>
            <li className="flex gap-2"><FileText className="mt-0.5 h-4 w-4 text-ke-green" /> Petitions to the Senate: Art. 119 + Senate Standing Orders — any citizen can petition on county matters.</li>
            <li className="flex gap-2"><Users className="mt-0.5 h-4 w-4 text-ke-green" /> Public galleries are open on sitting days (Tue–Thu). Committee sessions are listed on the order paper.</li>
          </ul>
          <div className="mt-4 flex flex-wrap gap-2">
            <a href="https://www.parliament.go.ke/the-senate" target="_blank" rel="noreferrer" className="rounded-full bg-ke-green px-4 py-2 text-sm text-white">Open the-senate <ExternalLink className="inline h-3 w-3" /></a>
            <button onClick={() => navigate("oversight", { section: "petitions" })} className="rounded-full border border-border px-4 py-2 text-sm">Petitions tracker</button>
          </div>
          <p className="mt-3 text-[11px]">* Nominated composition per Constitution Art. 98(1): 47 elected + 16 women + 2 youth + 2 PWD = 67 total.</p>
        </Card>
      </div>
    </div>
  );
}
