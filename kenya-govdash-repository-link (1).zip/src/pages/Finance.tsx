import { useMemo, useState } from "react";
import { Bar, BarChart, CartesianGrid, Legend, Line, LineChart, PolarAngleAxis, PolarGrid, PolarRadiusAxis, Radar, RadarChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Bell, Download, TrendingUp, GitCompare, Trophy } from "lucide-react";
import { ALL_COUNTY_FINANCE, NATIONAL_FINANCE, getAggregateStats, getAvailableFiscalYears, getCountiesWithFinanceData, getCountyFinance, getCountyTimeSeries, formatKshs, linearForecast } from "../lib/real-store";
import { allCounties } from "../lib/real-store";
import { useRouter } from "../lib/router";
import { createAlert } from "../lib/api";
import { AuditBadge, Card, DataGap, SectionTitle, StatCard } from "../components/ui";
import type { AuditOpinion } from "../lib/types";

const COLORS = ["#0ea5e9", "#10b981", "#f59e0b", "#ef4444", "#7c3aed"];

export function FinancePage() {
  const { navigate } = useRouter();
  const agg = useMemo(() => getAggregateStats("2023/24"), []);
  const fys = useMemo(() => getAvailableFiscalYears(), []);
  const countiesWithData = useMemo(() => getCountiesWithFinanceData(), []);
  const national = NATIONAL_FINANCE[0];

  const [tsCounties, setTsCounties] = useState<string[]>(["Nairobi City", "Kisumu", "Nyeri"]);
  const [tsMetric, setTsMetric] = useState<"overallAbsorption" | "developmentAbsorption" | "recurrentAbsorption" | "complianceScore" | "pendingBills" | "approvedBudget">("overallAbsorption");
  const [radarCounties, setRadarCounties] = useState<string[]>(["Nairobi City", "Kisumu", "Nyeri"]);
  const [email, setEmail] = useState("");
  const [alertCounty, setAlertCounty] = useState("Nairobi City");
  const [threshold, setThreshold] = useState("60");
  const [saved, setSaved] = useState("");

  const tsData = useMemo(() => fys.map((fy) => {
    const row: Record<string, any> = { fy };
    for (const c of tsCounties) {
      const rec = ALL_COUNTY_FINANCE.find((r) => r.countyName === c && r.fiscalYear === fy);
      row[c] = rec ? (rec as any)[tsMetric] ?? null : null;
    }
    return row;
  }), [fys, tsCounties, tsMetric]);

  const radarData = useMemo(() => {
    const metrics = [
      { key: "overallAbsorption", label: "Absorption" },
      { key: "developmentAbsorption", label: "Dev Absorp" },
      { key: "recurrentAbsorption", label: "Rec Absorp" },
      { key: "complianceScore", label: "Compliance" },
    ];
    return metrics.map((m) => {
      const row: Record<string, any> = { metric: m.label };
      for (const c of radarCounties) {
        const s = getCountyTimeSeries(c);
        const rec = s[s.length - 1];
        row[c] = rec ? (rec as any)[m.key] ?? 0 : 0;
      }
      return row;
    });
  }, [radarCounties]);

  const leaderboard = useMemo(() => {
    const recent = fys[fys.length - 1];
    return ALL_COUNTY_FINANCE.filter((r) => r.fiscalYear === recent && (r as any)[tsMetric] != null)
      .sort((a, b) => ((b as any)[tsMetric] ?? 0) - ((a as any)[tsMetric] ?? 0)).slice(0, 10);
  }, [fys, tsMetric]);

  const nationalTrend = useMemo(() => NATIONAL_FINANCE.slice().reverse().map((n) => ({ fy: n.fiscalYear, overall: n.overallAbsorption, dev: n.developmentAbsorption, rec: n.recurrentAbsorption })), []);
  const forecast = linearForecast(NATIONAL_FINANCE.slice().reverse().map((n) => n.overallAbsorption ?? 0));

  const auditData = (["Unmodified", "Qualified", "Adverse", "Disclaimer"] as AuditOpinion[]).map((k) => ({ name: k, count: (agg.auditOpinionCounts as any)[k] || 0 }));

  function exportCsv() {
    const header = "county,fy,approvedBudget,equitableShare,osr,absorption,devAbsorption,audit,compliance,pendingBills,source\n";
    const rows = ALL_COUNTY_FINANCE.map((r) => `${r.countyName},${r.fiscalYear},${r.approvedBudget},${r.equitableShare},${r.ownSourceRevenue ?? ""},${r.overallAbsorption ?? ""},${r.developmentAbsorption ?? ""},${r.auditOpinion},${r.complianceScore ?? ""},${r.pendingBills ?? ""},"${r.source}"`).join("\n");
    const blob = new Blob([header + rows], { type: "text/csv" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "kenya-govdash-finance-all-years.csv";
    a.click();
  }

  return (
    <div className="space-y-6">
      <div>
        <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-ke-red">Controller of Budget · OAG · CoG — FY {fys.join(" → ")}</p>
        <h1 className="font-display text-3xl sm:text-4xl">Finance & Audit Dashboard</h1>
        <p className="mt-1 text-sm text-muted-foreground">{countiesWithData.length} counties with published extracts · amounts Kshs millions · <button className="underline" onClick={() => navigate("reports")}>explore all FY reports →</button></p>
      </div>

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="National budget FY23/24" value={formatKshs(national.approvedBudget)} hint={`Spent ${formatKshs(national.actualExpenditure)}`} />
        <StatCard label="National absorption" value={`${national.overallAbsorption}%`} hint={`Linear forecast FY24/25: ${forecast ?? "N/A"}%`} tone="green" />
        <StatCard label="Sample pending bills" value={formatKshs(agg.totalPendingBills)} hint={`${getCountiesWithFinanceData().length} counties · CoB`} tone="red" />
        <StatCard label="Avg county absorption" value={`${agg.avgOverallAbsorption.toFixed(1)}%`} hint={`Dev avg ${agg.avgDevelopmentAbsorption.toFixed(1)}%`} tone="gold" />
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card className="p-5">
          <SectionTitle kicker="National" title="Budget trends — 3 years" />
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={nationalTrend}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                <XAxis dataKey="fy" /><YAxis domain={[70, 100]} /><Tooltip /><Legend />
                <Line dataKey="overall" name="Overall" stroke="#006b3f" strokeWidth={2} />
                <Line dataKey="rec" name="Recurrent" stroke="#c5a572" strokeWidth={2} />
                <Line dataKey="dev" name="Development" stroke="#bb0000" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </div>
          <p className="mt-2 text-[11px] text-muted-foreground">OAG + National Treasury. Debt FY23/24 {formatKshs(national.totalDebt)} · pending {formatKshs(national.pendingBills)}</p>
        </Card>
        <Card className="p-5">
          <SectionTitle kicker="OAG" title="County audit distribution FY23/24" />
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={auditData}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                <XAxis dataKey="name" tick={{ fontSize: 11 }} /><YAxis allowDecimals={false} /><Tooltip />
                <Bar dataKey="count" fill="#0f3d2e" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
          <p className="mt-2 text-[11px] text-muted-foreground">Among counties in CoB extract. National OAG summary: 47/47 executives Qualified FY23/24.</p>
        </Card>
      </div>

      <Card className="p-5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2"><TrendingUp className="h-5 w-5 text-emerald-600" /><h3 className="font-display text-xl">Finance trends over time</h3></div>
          <select value={tsMetric} onChange={(e) => setTsMetric(e.target.value as any)} className="h-8 rounded-lg border border-border bg-background px-2 text-sm">
            <option value="overallAbsorption">Overall Absorption</option>
            <option value="developmentAbsorption">Development Absorption</option>
            <option value="recurrentAbsorption">Recurrent Absorption</option>
            <option value="complianceScore">CoG Compliance</option>
            <option value="pendingBills">Pending Bills</option>
            <option value="approvedBudget">Approved Budget</option>
          </select>
        </div>
        <div className="mb-3 mt-3 flex flex-wrap gap-2">
          {tsCounties.map((c, i) => (
            <button key={c} onClick={() => setTsCounties(tsCounties.filter((x) => x !== c))} className="rounded-full border border-border px-2 py-1 text-xs" style={{ borderLeft: `4px solid ${COLORS[i % 5]}` }}>{c} ✕</button>
          ))}
          {tsCounties.length < 5 && (
            <select onChange={(e) => { if (e.target.value && !tsCounties.includes(e.target.value)) setTsCounties([...tsCounties, e.target.value]); }} className="h-7 rounded-lg border border-border text-xs" defaultValue="">
              <option value="">+ Add county</option>
              {countiesWithData.filter((c) => !tsCounties.includes(c)).map((c) => <option key={c} value={c}>{c}</option>)}
            </select>
          )}
        </div>
        <div className="h-[340px]">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={tsData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="fy" /><YAxis width={80} tick={{ fontSize: 11 }} tickFormatter={(v) => (tsMetric === "pendingBills" || tsMetric === "approvedBudget") ? formatKshs(v) : `${v}`} /><Tooltip formatter={(v: any) => (v == null ? "No data" : (tsMetric === "pendingBills" || tsMetric === "approvedBudget") ? formatKshs(Number(v)) : `${v}`)} /><Legend />
              {tsCounties.map((c, i) => <Line key={c} type="monotone" dataKey={c} stroke={COLORS[i % 5]} strokeWidth={2} dot={{ r: 4 }} connectNulls />)}
            </LineChart>
          </ResponsiveContainer>
        </div>
        <div className="mt-4">
          <p className="mb-2 flex items-center gap-1 text-xs font-semibold uppercase text-muted-foreground"><Trophy className="h-3 w-3" /> Top 10 by selected metric ({fys[fys.length - 1]})</p>
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-5">
            {leaderboard.map((r, i) => (
              <button key={r.countyName} onClick={() => navigate("finance-county", { name: r.countyName })} className="rounded-lg border border-border p-2 text-left text-sm hover:bg-muted">
                <span>{["🥇","🥈","🥉","4","5","6","7","8","9","10"][i]} {r.countyName}</span>
                <span className="block text-xs text-muted-foreground">{(tsMetric === "pendingBills" || tsMetric === "approvedBudget") ? formatKshs((r as any)[tsMetric]) : `${(r as any)[tsMetric]}`}</span>
              </button>
            ))}
          </div>
        </div>
      </Card>

      <Card className="p-5">
        <div className="flex items-center gap-2"><GitCompare className="h-5 w-5 text-purple-600" /><h3 className="font-display text-xl">3-county radar comparison</h3></div>
        <div className="mb-3 mt-3 grid gap-2 sm:grid-cols-3">
          {radarCounties.map((c, i) => (
            <select key={i} value={c} onChange={(e) => { const n = [...radarCounties]; n[i] = e.target.value; setRadarCounties(n); }} className="h-9 rounded-lg border border-border bg-background px-2 text-sm">
              {countiesWithData.map((x) => <option key={x} value={x}>{x}</option>)}
            </select>
          ))}
        </div>
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <RadarChart data={radarData}>
              <PolarGrid /><PolarAngleAxis dataKey="metric" /><PolarRadiusAxis domain={[0, 100]} />
              {radarCounties.map((c, i) => <Radar key={c} name={c} dataKey={c} stroke={COLORS[i]} fill={COLORS[i]} fillOpacity={0.2} />)}
              <Legend />
            </RadarChart>
          </ResponsiveContainer>
        </div>
      </Card>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card className="p-5">
          <SectionTitle kicker="CoG" title="Top 5 — compliance" />
          {agg.topPerformers.map((r, i) => (
            <button key={r.countyName} onClick={() => navigate("finance-county", { name: r.countyName })} className="flex w-full items-center gap-3 py-2 text-left hover:bg-muted/50">
              <span className="w-6 font-display text-lg">{i + 1}</span><span className="flex-1">{r.countyName}</span><AuditBadge opinion={r.auditOpinion} /><span className="w-10 text-right font-semibold">{r.complianceScore}</span>
            </button>
          ))}
        </Card>
        <Card className="p-5">
          <SectionTitle kicker="Intervention" title="Bottom 5" />
          {agg.bottomPerformers.map((r, i) => (
            <button key={r.countyName} onClick={() => navigate("finance-county", { name: r.countyName })} className="flex w-full items-center gap-3 py-2 text-left hover:bg-muted/50">
              <span className="w-6 font-display text-lg">{i + 1}</span><span className="flex-1">{r.countyName}</span><AuditBadge opinion={r.auditOpinion} /><span className="w-10 text-right font-semibold">{r.complianceScore}</span>
            </button>
          ))}
        </Card>
      </div>

      <Card className="overflow-hidden">
        <div className="flex items-center justify-between p-5">
          <SectionTitle kicker="Table" title={`County finance FY23/24 (${ALL_COUNTY_FINANCE.filter((r) => r.fiscalYear === "2023/24").length} rows)`} />
          <button onClick={exportCsv} className="inline-flex items-center gap-1 rounded-full border border-border px-3 py-1.5 text-xs"><Download className="h-3.5 w-3.5" /> CSV all years</button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[760px] text-left text-sm">
            <thead className="bg-muted/60 text-[11px] uppercase tracking-wider text-muted-foreground">
              <tr>{["County","Budget","OSR","Absorption","Dev %","Pending","Audit","CoG"].map((h) => <th key={h} className="px-4 py-2 font-medium">{h}</th>)}</tr>
            </thead>
            <tbody>
              {ALL_COUNTY_FINANCE.filter((r) => r.fiscalYear === "2023/24").sort((a,b) => a.countyName.localeCompare(b.countyName)).map((r) => (
                <tr key={r.countyName} className="cursor-pointer border-t border-border hover:bg-muted/40" onClick={() => navigate("finance-county", { name: r.countyName })}>
                  <td className="px-4 py-2 font-medium">{r.countyName}</td>
                  <td className="px-4 py-2">{formatKshs(r.approvedBudget)}</td>
                  <td className="px-4 py-2">{formatKshs(r.ownSourceRevenue)}</td>
                  <td className="px-4 py-2">{r.overallAbsorption ?? "—"}%</td>
                  <td className="px-4 py-2">{r.developmentAbsorption ?? "—"}%</td>
                  <td className="px-4 py-2">{formatKshs(r.pendingBills)}</td>
                  <td className="px-4 py-2"><AuditBadge opinion={r.auditOpinion} /></td>
                  <td className="px-4 py-2">{r.complianceScore ?? "—"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="p-4"><DataGap note="Only counties with a published CoB extract appear. Others are N/A, not zero." /></div>
      </Card>

      <Card className="p-5">
        <SectionTitle kicker="Alerts" title="Subscribe to finance alerts" />
        <form className="grid gap-3 sm:grid-cols-4" onSubmit={async (e) => { e.preventDefault(); const r = await createAlert({ email, county: alertCounty, threshold: Number(threshold) }); setSaved(`Alert saved for ${alertCounty} below ${threshold}% absorption (${r.via === "backend" ? "backend DB" : "this browser"}).`); }}>
          <input required type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email" className="h-10 rounded-xl border border-border bg-background px-3 text-sm" />
          <select value={alertCounty} onChange={(e) => setAlertCounty(e.target.value)} className="h-10 rounded-xl border border-border bg-background px-3 text-sm">{allCounties().map((c) => <option key={c.code} value={c.name}>{c.name}</option>)}</select>
          <input type="number" min={0} max={100} value={threshold} onChange={(e) => setThreshold(e.target.value)} className="h-10 rounded-xl border border-border bg-background px-3 text-sm" />
          <button className="inline-flex h-10 items-center justify-center gap-1 rounded-xl bg-ke-green text-sm text-white"><Bell className="h-4 w-4" /> Create alert</button>
        </form>
        {saved && <p className="mt-2 text-sm text-emerald-700">{saved}</p>}
      </Card>
    </div>
  );
}

export function FinanceCountyPage({ name }: { name: string }) {
  const { navigate } = useRouter();
  const rec = getCountyFinance(name, "2023/24") ?? getCountyTimeSeries(name).slice(-1)[0];
  const series = getCountyTimeSeries(name);
  const county = allCounties().find((c) => c.name.toLowerCase() === name.toLowerCase());
  const forecast = linearForecast(series.map((s) => s.overallAbsorption || 0));

  if (!rec) {
    return <div className="space-y-4"><h1 className="font-display text-3xl">{name}</h1><DataGap note="No CoB/OAG extract attached for this county." />{county && <button className="rounded-full bg-ke-green px-4 py-2 text-sm text-white" onClick={() => navigate("county", { code: String(county.code) })}>Open county profile</button>}</div>;
  }

  return (
    <div className="space-y-6">
      <button onClick={() => navigate("finance")} className="text-sm text-muted-foreground underline">← All finance</button>
      <h1 className="font-display text-3xl">{rec.countyName} — finance drill-down</h1>
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Approved budget" value={formatKshs(rec.approvedBudget)} />
        <StatCard label="Actual spend" value={formatKshs(rec.actualExpenditure)} />
        <StatCard label="Overall absorption" value={`${rec.overallAbsorption ?? "N/A"}%`} hint={forecast != null ? `Linear forecast ${forecast}%` : undefined} />
        <StatCard label="Pending bills" value={formatKshs(rec.pendingBills)} tone="red" />
      </div>
      <div className="grid gap-3 sm:grid-cols-3">
        <StatCard label="Equitable share" value={formatKshs(rec.equitableShare)} />
        <StatCard label="OSR collected" value={formatKshs(rec.ownSourceRevenue)} hint={`Target ${formatKshs(rec.osrTarget)}`} />
        <StatCard label="Compliance" value={rec.complianceScore != null ? `${rec.complianceScore}/100` : "N/A"} />
      </div>
      {series.length > 0 && (
        <Card className="p-5">
          <SectionTitle title={`Absorption time series (${series.map((s) => s.fiscalYear).join(", ")})`} />
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={series}>
                <CartesianGrid strokeDasharray="3 3" /><XAxis dataKey="fiscalYear" /><YAxis domain={[0, 100]} /><Tooltip /><Legend />
                <Line dataKey="overallAbsorption" name="Overall" stroke="#006b3f" strokeWidth={2} />
                <Line dataKey="developmentAbsorption" name="Development" stroke="#bb0000" strokeWidth={2} />
                <Line dataKey="recurrentAbsorption" name="Recurrent" stroke="#c5a572" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </Card>
      )}
      <Card className="p-5 text-sm leading-relaxed">
        <p>Audit opinion: <AuditBadge opinion={rec.auditOpinion} /></p>
        <p className="mt-2">Source: {rec.source}</p>
        {rec.notes && <p className="mt-2">{rec.notes}</p>}
        <div className="mt-2 grid gap-2 sm:grid-cols-2 text-xs text-muted-foreground">
          <span>Recurrent spend {formatKshs(rec.recurrentExpenditure)} ({rec.recurrentAbsorption}%)</span>
          <span>Development spend {formatKshs(rec.developmentExpenditure)} ({rec.developmentAbsorption}%)</span>
        </div>
        <div className="mt-4 flex flex-wrap gap-2">
          {county && <button className="rounded-full bg-ke-green px-4 py-2 text-white" onClick={() => navigate("county", { code: String(county.code) })}>County profile</button>}
          <button className="rounded-full border border-border px-4 py-2" onClick={() => navigate("reports", {}, { county: rec.countyName })}>All FY reports</button>
        </div>
      </Card>
    </div>
  );
}

export function ComparePage() {
  const { navigate } = useRouter();
  const countiesWithData = useMemo(() => getCountiesWithFinanceData(), []);
  const [selected, setSelected] = useState<string[]>(["Nyeri", "Kisumu", "Nairobi City"].filter((c) => countiesWithData.includes(c)));
  const colors = ["#006b3f", "#bb0000", "#c5a572", "#1d4ed8", "#7c3aed"];

  const radar = ["overallAbsorption", "developmentAbsorption", "complianceScore", "recurrentAbsorption"].map((key) => {
    const row: Record<string, any> = { metric: key.replace(/([A-Z])/g, " $1") };
    selected.forEach((c) => {
      const s = getCountyTimeSeries(c);
      const rec = s[s.length - 1];
      row[c] = rec ? (rec as any)[key] ?? 0 : 0;
    });
    return row;
  });

  function toggle(name: string) {
    setSelected((prev) => (prev.includes(name) ? prev.filter((p) => p !== name) : prev.length >= 5 ? prev : [...prev, name]));
  }

  function exportCsv() {
    const rows = selected.map((n) => {
      const r = getCountyFinance(n, "2023/24");
      return `${r?.countyName},${r?.approvedBudget},${r?.overallAbsorption},${r?.developmentAbsorption},${r?.complianceScore},${r?.auditOpinion},${r?.pendingBills}`;
    }).join("\n");
    const blob = new Blob([`county,budget,absorption,dev,compliance,audit,pending\n${rows}`], { type: "text/csv" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "county-compare.csv";
    a.click();
  }

  return (
    <div className="space-y-6">
      <h1 className="font-display text-3xl">County comparison — 2 to 5 counties</h1>
      <p className="text-sm text-muted-foreground">Only counties with CoB FY23/24 extracts are selectable. Radar uses latest FY per county.</p>
      <div className="flex flex-wrap gap-2">
        {countiesWithData.map((n) => (
          <button key={n} onClick={() => toggle(n)} className={`rounded-full border px-3 py-1 text-xs ${selected.includes(n) ? "border-ke-green bg-ke-green text-white" : "border-border"}`}>{n}</button>
        ))}
      </div>
      <Card className="p-5">
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <RadarChart data={radar}>
              <PolarGrid /><PolarAngleAxis dataKey="metric" tick={{ fontSize: 11 }} /><PolarRadiusAxis domain={[0, 100]} />
              {selected.map((c, i) => <Radar key={c} name={c} dataKey={c} stroke={colors[i]} fill={colors[i]} fillOpacity={0.15} />)}
              <Legend />
            </RadarChart>
          </ResponsiveContainer>
        </div>
      </Card>
      <div className="overflow-x-auto">
        <table className="w-full min-w-[640px] text-sm">
          <thead className="text-left text-[11px] uppercase tracking-wider text-muted-foreground"><tr>{["County","Budget","Absorption","Dev %","CoG","Audit","Pending"].map((h) => <th key={h} className="px-3 py-2">{h}</th>)}</tr></thead>
          <tbody>
            {selected.map((n) => {
              const r = getCountyFinance(n, "2023/24");
              if (!r) return null;
              return (
                <tr key={n} className="cursor-pointer border-t border-border hover:bg-muted/40" onClick={() => navigate("finance-county", { name: n })}>
                  <td className="px-3 py-2 font-medium">{r.countyName}</td>
                  <td className="px-3 py-2">{formatKshs(r.approvedBudget)}</td>
                  <td className="px-3 py-2">{r.overallAbsorption}%</td>
                  <td className="px-3 py-2">{r.developmentAbsorption}%</td>
                  <td className="px-3 py-2">{r.complianceScore}</td>
                  <td className="px-3 py-2"><AuditBadge opinion={r.auditOpinion} /></td>
                  <td className="px-3 py-2">{formatKshs(r.pendingBills)}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
      <button onClick={exportCsv} className="rounded-full border border-border px-4 py-2 text-sm">Export CSV</button>
    </div>
  );
}
