// GovDash backend — SQLite store (sql.js, file-persisted).
// Tables mirror kenya-county-data/database/schema.sql domains.
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import initSqlJs from "sql.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
export const DB_PATH = process.env.GOVDASH_DB || path.join(__dirname, "govdash.sqlite");
export const DATA_DIR = process.env.GOVDASH_DATA || path.join(__dirname, "..", "public", "data");
export const SITES_FILE = process.env.GOVDASH_SITES || path.join(__dirname, "..", "data", "county-sites.json");

const SCHEMA = `
CREATE TABLE IF NOT EXISTS counties (
  code INTEGER PRIMARY KEY, name TEXT UNIQUE NOT NULL, region TEXT NOT NULL,
  governor TEXT, party TEXT, coalition TEXT, term TEXT DEFAULT '2022-2027',
  population_2019 INTEGER, land_area_sqkm REAL, density_per_sqkm INTEGER);
CREATE TABLE IF NOT EXISTS finance_snapshots (
  county_name TEXT, fy TEXT, approved_budget_m REAL, equitable_share_m REAL,
  osr_m REAL, osr_target_m REAL, actual_m REAL, recurrent_m REAL, development_m REAL,
  absorption REAL, recurrent_absorption REAL, dev_absorption REAL,
  audit TEXT, pending_bills_m REAL, compliance INTEGER, notes TEXT, source TEXT,
  PRIMARY KEY (county_name, fy));
CREATE TABLE IF NOT EXISTS parliament (
  id TEXT PRIMARY KEY, full_name TEXT, title TEXT, party TEXT, coalition TEXT,
  jurisdiction TEXT, county_name TEXT, county_code INTEGER, status TEXT,
  profile_url TEXT, kind TEXT);
CREATE TABLE IF NOT EXISTS succession (
  code INTEGER PRIMARY KEY, county TEXT, t1 TEXT, t2 TEXT, t3 TEXT, note TEXT);
CREATE TABLE IF NOT EXISTS county_sites (
  code INTEGER PRIMARY KEY, county TEXT, url TEXT,
  http_status INTEGER, title TEXT, checked_at INTEGER);
CREATE TABLE IF NOT EXISTS fy_reports (
  id INTEGER PRIMARY KEY AUTOINCREMENT, county_code INTEGER, county TEXT,
  fy TEXT, title TEXT, url TEXT, kind TEXT, source_page TEXT, found_at INTEGER);
CREATE TABLE IF NOT EXISTS feedback (
  id TEXT PRIMARY KEY, name TEXT, county TEXT, topic TEXT, message TEXT,
  status TEXT DEFAULT 'Received', created_at INTEGER);
CREATE TABLE IF NOT EXISTS whistleblower_reports (
  ticket TEXT PRIMARY KEY, category TEXT, county TEXT,
  ciphertext TEXT, iv TEXT, wrapped_key TEXT,
  status TEXT DEFAULT 'Queued', created_at INTEGER);
CREATE TABLE IF NOT EXISTS finance_alerts (
  id TEXT PRIMARY KEY, email TEXT, county TEXT, threshold REAL, created_at INTEGER);
`;

let SQL = null;
let db = null;

export async function openDb() {
  if (db) return db;
  SQL = await initSqlJs();
  let bytes = null;
  try { bytes = fs.readFileSync(DB_PATH); } catch { /* first run */ }
  db = bytes ? new SQL.Database(bytes) : new SQL.Database();
  db.run("PRAGMA journal_mode=DELETE;");
  for (const stmt of SCHEMA.split(";")) {
    const s = stmt.trim();
    if (s) db.run(s);
  }
  return db;
}

export function saveDb() {
  if (!db) return;
  fs.writeFileSync(DB_PATH, Buffer.from(db.export()));
}

function esc(v) {
  if (v === null || v === undefined) return "NULL";
  if (typeof v === "number") return Number.isFinite(v) ? String(v) : "NULL";
  return "'" + String(v).replace(/'/g, "''") + "'";
}

export function insert(table, row) {
  const keys = Object.keys(row);
  db.run(`INSERT OR REPLACE INTO ${table} (${keys.join(",")}) VALUES (${keys.map((k) => esc(row[k])).join(",")})`);
}

export function all(sql) {
  const res = db.exec(sql);
  if (!res.length) return [];
  const { columns, values } = res[0];
  return values.map((r) => Object.fromEntries(r.map((v, i) => [columns[i], v])));
}

export function count(table) {
  return all(`SELECT COUNT(*) AS n FROM ${table}`)[0]?.n ?? 0;
}
