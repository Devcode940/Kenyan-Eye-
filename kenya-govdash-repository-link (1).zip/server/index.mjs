// GovDash API backend — zero-dependency Node HTTP + SQLite (sql.js).
// Run:  node server/seed.mjs        (first time — builds govdash.sqlite)
//       node server/scrape.mjs      (feed counties: live-check sites, harvest FY report links)
//       node server/index.mjs       (serves API on :3001, or $PORT)
import http from "node:http";
import crypto from "node:crypto";
import { openDb, saveDb, insert, all, count } from "./db.mjs";

const PORT = Number(process.env.PORT || 3001);
const ADMIN_TOKEN = process.env.ADMIN_TOKEN || "";

function escLike(s) { return String(s).replace(/'/g, "''").replace(/%/g, "").replace(/_/g, ""); }
function json(res, code, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(code, {
    "Content-Type": "application/json",
    "Content-Length": Buffer.byteLength(body),
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
  });
  res.end(body);
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    let s = "";
    req.on("data", (c) => { s += c; if (s.length > 200_000) req.destroy(); });
    req.on("end", () => { try { resolve(s ? JSON.parse(s) : {}); } catch { reject(new Error("bad-json")); } });
    req.on("error", reject);
  });
}
const str = (v, max) => (typeof v === "string" ? v.trim().slice(0, max) : "");
const num = (v) => (typeof v === "number" && Number.isFinite(v) ? v : null);

async function handler(req, res) {
  const url = new URL(req.url, "http://x");
  const p = url.pathname;
  const q = url.searchParams;
  if (req.method === "OPTIONS") return json(res, 204, {});

  try {
    if (p === "/api/health" && req.method === "GET") {
      return json(res, 200, {
        ok: true, backend: "govdash-sqlite", time: new Date().toISOString(),
        counts: {
          counties: count("counties"), finance: count("finance_snapshots"),
          parliament: count("parliament"), succession: count("succession"),
          sites: count("county_sites"), reports: count("fy_reports"),
          feedback: count("feedback"), whistleblower: count("whistleblower_reports"), alerts: count("finance_alerts"),
        },
      });
    }

    if (p === "/api/counties" && req.method === "GET") {
      const region = q.get("region");
      const rows = all(`SELECT * FROM counties ${region ? `WHERE region='${escLike(region)}'` : ""} ORDER BY code`);
      return json(res, 200, { counties: rows });
    }
    const mCounty = p.match(/^\/api\/counties\/(\d+)$/);
    if (mCounty && req.method === "GET") {
      const code = Number(mCounty[1]);
      const county = all(`SELECT * FROM counties WHERE code=${code}`)[0];
      if (!county) return json(res, 404, { error: "county-not-found" });
      return json(res, 200, {
        county,
        site: all(`SELECT * FROM county_sites WHERE code=${code}`)[0] || null,
        succession: all(`SELECT * FROM succession WHERE code=${code}`)[0] || null,
        finance: all(`SELECT * FROM finance_snapshots WHERE county_name='${escLike(county.name)}' ORDER BY fy`),
        parliament: all(`SELECT * FROM parliament WHERE county_code=${code} ORDER BY kind, full_name`),
        reports: all(`SELECT * FROM fy_reports WHERE county_code=${code} ORDER BY found_at DESC LIMIT 50`),
      });
    }

    if (p === "/api/finance" && req.method === "GET") {
      const fy = q.get("fy"), county = q.get("county");
      const where = [
        fy ? `fy='${escLike(fy)}'` : "",
        county ? `county_name LIKE '%${escLike(county)}%'` : "",
      ].filter(Boolean).join(" AND ");
      return json(res, 200, { snapshots: all(`SELECT * FROM finance_snapshots ${where ? "WHERE " + where : ""} ORDER BY fy, county_name`) });
    }

    if (p === "/api/parliament" && req.method === "GET") {
      const kind = q.get("type"), county = q.get("county"), s = q.get("q");
      const where = [
        kind && ["mp", "senator", "women"].includes(kind) ? `kind='${kind}'` : "",
        county ? `(county_name LIKE '%${escLike(county)}%' OR CAST(county_code AS TEXT)='${escLike(county)}')` : "",
        s ? `(full_name LIKE '%${escLike(s)}%' OR party LIKE '%${escLike(s)}%' OR jurisdiction LIKE '%${escLike(s)}%')` : "",
      ].filter(Boolean).join(" AND ");
      const rows = all(`SELECT * FROM parliament ${where ? "WHERE " + where : ""} ORDER BY county_code, kind LIMIT 500`);
      return json(res, 200, { results: rows, count: rows.length });
    }

    if (p === "/api/history" && req.method === "GET") {
      return json(res, 200, { succession: all("SELECT * FROM succession ORDER BY code") });
    }

    // ---------- county sites (fed by scrape.mjs) ----------
    if (p === "/api/sites" && req.method === "GET") {
      return json(res, 200, { sites: all("SELECT * FROM county_sites ORDER BY code") });
    }

    // ---------- FY reports archive (bundled snapshots + scraped links) ----------
    if (p === "/api/reports" && req.method === "GET") {
      const fy = q.get("fy"), county = q.get("county");
      const where = [
        fy ? `fy='${escLike(fy)}'` : "",
        county ? `(county LIKE '%${escLike(county)}%' OR CAST(county_code AS TEXT)='${escLike(county)}')` : "",
      ].filter(Boolean).join(" AND ");
      return json(res, 200, { reports: all(`SELECT * FROM fy_reports ${where ? "WHERE " + where : ""} ORDER BY found_at DESC LIMIT 500`) });
    }

    if (p === "/api/search" && req.method === "GET") {
      const s = escLike(q.get("q") || "").slice(0, 60);
      if (s.length < 2) return json(res, 200, { counties: [], parliament: [], finance: [] });
      return json(res, 200, {
        counties: all(`SELECT * FROM counties WHERE name LIKE '%${s}%' OR governor LIKE '%${s}%' OR party LIKE '%${s}%' LIMIT 10`),
        parliament: all(`SELECT * FROM parliament WHERE full_name LIKE '%${s}%' OR party LIKE '%${s}%' OR jurisdiction LIKE '%${s}%' LIMIT 20`),
        finance: all(`SELECT * FROM finance_snapshots WHERE county_name LIKE '%${s}%' ORDER BY fy DESC LIMIT 10`),
      });
    }

    if (p === "/api/stats" && req.method === "GET") {
      const audits = all("SELECT audit, COUNT(*) AS n FROM finance_snapshots WHERE fy='2023/24' GROUP BY audit");
      const avg = all("SELECT AVG(absorption) AS a, AVG(dev_absorption) AS d, SUM(pending_bills_m) AS p FROM finance_snapshots WHERE fy='2023/24'")[0];
      return json(res, 200, {
        counties: count("counties"), mps: all("SELECT COUNT(*) AS n FROM parliament WHERE kind='mp'")[0].n,
        senators: all("SELECT COUNT(*) AS n FROM parliament WHERE kind='senator'")[0].n,
        women: all("SELECT COUNT(*) AS n FROM parliament WHERE kind='women'")[0].n,
        financeRows: count("finance_snapshots"), reports: count("fy_reports"), sites: count("county_sites"),
        audits, avgAbsorption: avg?.a, avgDev: avg?.d, totalPending: avg?.p,
        feedback: count("feedback"), alerts: count("finance_alerts"),
      });
    }

    if (p === "/api/feedback" && req.method === "GET") {
      return json(res, 200, { feedback: all("SELECT id,name,county,topic,message,status,created_at FROM feedback ORDER BY created_at DESC LIMIT 200") });
    }
    if (p === "/api/feedback" && req.method === "POST") {
      const b = await readBody(req);
      const item = { name: str(b.name, 80), county: str(b.county, 40), topic: str(b.topic, 40), message: str(b.message, 2000) };
      if (!item.name || !item.message) return json(res, 400, { error: "name and message required" });
      const row = { id: crypto.randomUUID(), ...item, status: "Received", created_at: Date.now() };
      insert("feedback", row); saveDb();
      return json(res, 201, row);
    }

    if (p === "/api/whistleblower" && req.method === "POST") {
      const b = await readBody(req);
      const env = {
        category: str(b.category, 40) || "Other", county: str(b.county, 40) || "Unknown",
        ciphertext: str(b.ciphertext, 100_000), iv: str(b.iv, 64), wrapped_key: str(b.wrappedKey, 4096),
      };
      if (!env.ciphertext || !env.iv || !env.wrapped_key) return json(res, 400, { error: "envelope (ciphertext, iv, wrappedKey) required" });
      const ticket = "WB-" + crypto.randomBytes(3).toString("hex").toUpperCase();
      insert("whistleblower_reports", { ticket, ...env, status: "Queued", created_at: Date.now() }); saveDb();
      return json(res, 201, { ticket, status: "Queued" });
    }
    if (p === "/api/whistleblower/status" && req.method === "GET") {
      const t = str(q.get("ticket"), 12).toUpperCase();
      const row = all(`SELECT ticket,status,category,county,created_at FROM whistleblower_reports WHERE ticket='${escLike(t)}'`)[0];
      if (!row) return json(res, 404, { error: "ticket-not-found" });
      return json(res, 200, row);
    }

    if (p === "/api/alerts" && req.method === "POST") {
      const b = await readBody(req);
      const email = str(b.email, 120), countyA = str(b.county, 40);
      const threshold = num(b.threshold);
      if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return json(res, 400, { error: "valid email required" });
      if (threshold === null || threshold < 0 || threshold > 100) return json(res, 400, { error: "threshold 0-100 required" });
      const row = { id: crypto.randomUUID(), email, county: countyA, threshold, created_at: Date.now() };
      insert("finance_alerts", row); saveDb();
      return json(res, 201, row);
    }
    if (p === "/api/alerts" && req.method === "GET") {
      if (ADMIN_TOKEN && req.headers.authorization !== `Bearer ${ADMIN_TOKEN}`) return json(res, 401, { error: "unauthorized" });
      return json(res, 200, { alerts: all("SELECT * FROM finance_alerts ORDER BY created_at DESC LIMIT 500") });
    }

    return json(res, 404, { error: "not-found", hint: "GET /api/health" });
  } catch (e) {
    if (e && e.message === "bad-json") return json(res, 400, { error: "invalid JSON body" });
    console.error(e);
    return json(res, 500, { error: "server-error" });
  }
}

await openDb();
http.createServer(handler).listen(PORT, () => console.log(`GovDash API on http://localhost:${PORT} — try /api/health`));
