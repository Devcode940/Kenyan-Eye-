// Smoke test: boots the API on a throwaway port, exercises every endpoint, exits.
// Usage: timeout 90 node server/smoke.mjs
process.env.PORT = process.env.SMOKE_PORT || "3999";
const BASE = `http://localhost:${process.env.PORT}`;

let pass = 0, fail = 0;
function check(name, cond, extra = "") {
  if (cond) { pass++; console.log(`PASS ${name} ${extra}`); }
  else { fail++; console.log(`FAIL ${name} ${extra}`); }
}
async function get(p) {
  const r = await fetch(BASE + p, { signal: AbortSignal.timeout(10000) });
  return { status: r.status, body: await r.json() };
}
async function post(p, data) {
  const r = await fetch(BASE + p, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data), signal: AbortSignal.timeout(10000) });
  return { status: r.status, body: await r.json() };
}

await import("./index.mjs");
await new Promise((r) => setTimeout(r, 500));

const h = await get("/api/health");
check("health", h.status === 200 && h.body.ok, JSON.stringify(h.body.counts));
check("seeded counties", h.body.counts?.counties === 47);
check("seeded parliament", h.body.counts?.parliament === 425);
check("sites fed", h.body.counts?.sites === 47);
check("reports fed", (h.body.counts?.reports ?? 0) > 200, `(${h.body.counts?.reports})`);

const c47 = await get("/api/counties/47");
check("county bundle", c47.body.county?.name === "Nairobi City" && c47.body.succession?.t1 === "Evans Kidero" && (c47.body.reports?.length ?? 0) > 0);

const fin = await get("/api/finance?fy=2023/24");
check("finance FY23/24", fin.body.snapshots?.length === 20);

const parl = await get("/api/parliament?type=senator&q=Sifuna");
check("senator search", parl.body.count === 1);

const sites = await get("/api/sites");
check("sites endpoint", sites.body.sites?.length === 47 && sites.body.sites.every((s) => s.http_status === 200));

const reps = await get("/api/reports?county=Kisumu");
check("reports filter", reps.body.reports?.length > 0);

const fb = await post("/api/feedback", { name: "Smoke", county: "Kisumu", topic: "Water", message: "smoke ok" });
check("feedback post", fb.status === 201 && Boolean(fb.body.id));

const wb = await post("/api/whistleblower", { category: "Land", county: "Kisumu", ciphertext: "eA", iv: "eQ", wrappedKey: "eQ" });
check("wb envelope", wb.status === 201 && wb.body.ticket?.startsWith("WB-"));
const st = await get(`/api/whistleblower/status?ticket=${wb.body.ticket}`);
check("wb status", st.body.status === "Queued");

const bad = await post("/api/alerts", { email: "nope", county: "Kilifi", threshold: 60 });
check("alert validation", bad.status === 400);
const al = await post("/api/alerts", { email: "s@t.co", county: "Kilifi", threshold: 55 });
check("alert post", al.status === 201);

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
