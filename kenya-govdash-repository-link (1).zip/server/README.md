# GovDash backend — SQLite + REST API (zero dependencies)

A tiny Node backend that persists citizen writes (feedback, whistleblower
envelopes, finance alerts), serves the reference data from SQLite, and feeds
the 47 official county websites for FY report links.
Needs nothing beyond Node 20 + the repo's `sql.js` dependency.

## Quick start

```bash
node server/seed.mjs          # build server/govdash.sqlite from public/data (first run)
node server/seed.mjs --reset  # rebuild from scratch
node server/scrape.mjs        # feed counties: live-check 47 sites, harvest FY report links
PORT=3001 node server/index.mjs
curl localhost:3001/api/health
```

Env: `PORT` (default 3001), `GOVDASH_DB` (sqlite file path),
`GOVDASH_DATA` (public/data dir), `ADMIN_TOKEN` (Bearer token gating `GET /api/alerts`).

## Feeding the counties (`scrape.mjs`)

```bash
node server/scrape.mjs                    # all 47 sites
node server/scrape.mjs --limit 5          # trial run
node server/scrape.mjs --timeout 12000    # slower sites
```

- Source list: `data/county-sites.json` (47 official `<county>.go.ke` URLs).
- Polite: 6 concurrent requests, 8s timeout, homepage only, civic-bot User-Agent.
- Stores per site: HTTP status, page title, check time → `county_sites`.
- Harvests report links (budget / BIRR / audit / CIDP / assembly papers, FY-aware)
  → `fy_reports` + `public/data/counties/websites.json`.
- Re-run any time; per-county rows are replaced, never duplicated.
- Sites that fail keep their last good status and are badged “check” in the UI —
  never silently dropped.

## Endpoints

| Method | Path | Description |
|---|---|---|
| GET | /api/health | status + row counts |
| GET | /api/counties[?region=] | 47 counties + demographics |
| GET | /api/counties/:code | county + site + succession + finance + parliament + reports |
| GET | /api/finance[?fy=&county=] | CoB snapshots (all FYs) |
| GET | /api/parliament[?type=mp\|senator\|women&county=&q=] | parliament.go.ke scrape |
| GET | /api/history | governor succession 2013→2027 |
| GET | /api/sites | 47 county websites + live status |
| GET | /api/reports[?fy=&county=] | FY reports archive (scraped links) |
| GET | /api/search?q= | counties + parliament + finance |
| GET | /api/stats | platform aggregates |
| GET/POST | /api/feedback | citizen feedback |
| POST | /api/whistleblower | E2E envelope `{ciphertext, iv, wrappedKey}` → ticket |
| GET | /api/whistleblower/status?ticket=WB-… | ticket status (no plaintext ever stored) |
| POST | /api/alerts | finance alert subscription |
| GET | /api/alerts | list alerts (needs `Authorization: Bearer $ADMIN_TOKEN` if set) |

## Schema

`server/schema.sql` (mirrors `kenya-county-data/database/schema.sql`):
`counties`, `finance_snapshots`, `parliament`, `succession`,
`county_sites`, `fy_reports`, `feedback`, `whistleblower_reports`, `finance_alerts`.

## Frontend wiring

Set `VITE_API_URL=http://localhost:3001` (or Admin → Backend tab → Backend URL):
the FY Reports Archive shows scraped report links + live site statuses, and
feedback / whistleblower / alerts POST to the API — with automatic fallback to
bundled data when the backend is unreachable (static hosting).

Firebase Google auth is frontend-only: see Admin → Backend tab for the
5-minute console.firebase.google.com setup.
