// Feed the counties: live-check all 47 official county websites and harvest
// FY report links (budgets, BIRRs, audits, CIDPs, assembly papers).
// Usage: node server/scrape.mjs [--limit N] [--timeout MS]
// Writes into SQLite (county_sites, fy_reports) + public/data/counties/websites.json.
// Polite: 6 concurrent requests, 8s timeout, stock browser User-Agent, homepage only.
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { openDb, saveDb, insert, all, DATA_DIR } from "./db.mjs";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
function argVal(name, def) {
  const i = process.argv.findIndex((a) => a === `--${name}` || a.startsWith(`--${name}=`));
  if (i === -1) return def;
  const eq = process.argv[i].split("=");
  if (eq.length > 1 && eq[1]) return eq[1];
  return process.argv[i + 1] ?? def;
}
const TIMEOUT = Number(argVal("timeout", 12000));
const LIMIT = Number(argVal("limit", 47));
const ONLY = argVal("only", "").split(",").map((s) => Number(s.trim())).filter(Boolean);
const CONCURRENCY = 6;
const UA = "GovDash-CivicBot/1.0 (county oversight dashboard; contact via repo issues)";

const REPORT_HINT = /(budget|birr|annual|audit|financial|cidp|appropriation|implementation|review|treasury|accounts|expenditure|revenue|fiscal|plan|assembly|hansard|gazette)/i;
const FY_HINT = /(20\d\d[\/-]?\d{0,4}|fy\s?\d|quarter|[1234](st|nd|rd|th)\s?quarter)/i;

function fetchText(url, timeout, insecure = false) {
  return new Promise((resolve) => {
    const lib = url.startsWith("https") ? import("node:https") : import("node:http");
    const timer = setTimeout(() => resolve({ status: 0, finalUrl: url, html: "", error: "timeout" }), timeout);
    Promise.all([lib, insecure ? import("node:https").then(() => null).catch(() => null) : null]).then(([{ default: h }]) => {
      const opts = { headers: { "User-Agent": UA, Accept: "text/html" }, timeout };
      if (insecure && url.startsWith("https")) opts.rejectUnauthorized = false;
      const req = h.get(url, opts, (res) => {
        // follow one redirect manually
        if ([301, 302, 303, 307, 308].includes(res.statusCode) && res.headers.location) {
          clearTimeout(timer);
          const next = new URL(res.headers.location, url).toString();
          res.resume();
          fetchText(next, Math.max(2000, timeout - 2000)).then((r) => resolve({ ...r, redirected: true }));
          return;
        }
        let html = "";
        res.on("data", (c) => { if (html.length < 600_000) html += c; });
        res.on("end", () => { clearTimeout(timer); resolve({ status: res.statusCode || 0, finalUrl: url, html }); });
      });
      req.on("timeout", () => { req.destroy(); });
      req.on("error", (e) => {
        clearTimeout(timer);
        // retry once without cert verification for misconfigured .go.ke hosts
        if (!insecure && /certificate|self-signed|verify/i.test(e.message || "")) {
          fetchText(url, timeout, true).then((r) => resolve({ ...r, tlsBypass: true }));
        } else {
          resolve({ status: 0, finalUrl: url, html: "", error: e.message });
        }
      });
    });
  });
}

function absUrl(href, base) {
  try {
    const u = new URL(href, base);
    if (!["http:", "https:"].includes(u.protocol)) return null;
    u.hash = "";
    return u.toString();
  } catch { return null; }
}

function harvestReports(html, pageUrl, county) {
  const out = [];
  const seen = new Set();
  const re = /<a[^>]+href=["']([^"']+)["'][^>]*>([\s\S]{0,220}?)<\/a>/gi;
  let m;
  while ((m = re.exec(html)) && out.length < 400) {
    const url = absUrl(m[1], pageUrl);
    if (!url || seen.has(url)) continue;
    seen.add(url);
    const text = m[2].replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim().slice(0, 160);
    if (!text || !REPORT_HINT.test(text + " " + url)) continue;
    const fy = (text.match(/20\d\d\s?[\/-]\s?\d{2,4}/) || url.match(/20\d\d[\/-]?\d{2,4}/) || [])[0] || null;
    let kind = "report";
    if (/audit/i.test(text + url)) kind = "audit";
    else if (/budget|appropriation/i.test(text + url)) kind = "budget";
    else if (/birr|implementation|review|quarter/i.test(text + url)) kind = "implementation-review";
    else if (/cidp|plan/i.test(text + url)) kind = "cidp";
    else if (/hansard|assembly/i.test(text + url)) kind = "assembly";
    out.push({ county, fy, title: text || url, url, kind, source_page: pageUrl, fyHint: FY_HINT.test(text + " " + url) });
  }
  // prefer links that mention a FY/year
  out.sort((a, b) => Number(b.fyHint) - Number(a.fyHint));
  return out.slice(0, 12);
}

async function run() {
  const db = await openDb();
  const sitesFile = JSON.parse(fs.readFileSync(path.join(__dirname, "..", "data", "county-sites.json"), "utf8")).sites;
  const targets = (ONLY.length ? sitesFile.filter((s) => ONLY.includes(s.code)) : sitesFile).slice(0, LIMIT);
  console.log(`Feeding ${targets.length} county sites (concurrency ${CONCURRENCY}, timeout ${TIMEOUT}ms)…`);

  let ok = 0, fail = 0, reports = 0;
  const webFile = path.join(DATA_DIR, "counties", "websites.json");
  const statuses = [];

  for (let i = 0; i < targets.length; i += CONCURRENCY) {
    const batch = targets.slice(i, i + CONCURRENCY);
    const results = await Promise.all(batch.map(async (s) => {
      const r = await fetchText(s.url, TIMEOUT);
      const title = (r.html.match(/<title[^>]*>([\s\S]{0,200}?)<\/title>/i) || [])[1]?.replace(/\s+/g, " ").trim() || null;
      const found = r.html ? harvestReports(r.html, r.finalUrl, s.county) : [];
      return { site: s, ...r, title, found };
    }));
    for (const r of results) {
      const live = r.status >= 200 && r.status < 400;
      if (live) ok++; else fail++;
      insert("county_sites", {
        code: r.site.code, county: r.site.county, url: r.site.url,
        http_status: r.status || null, title: r.title, checked_at: Date.now(),
      });
      statuses.push({ code: r.site.code, county: r.site.county, url: r.site.url, finalUrl: r.finalUrl, http_status: r.status, title: r.title, checked_at: new Date().toISOString(), error: r.error || null });
      db.run(`DELETE FROM fy_reports WHERE county_code=${r.site.code} AND source_page='scrape:homepage'`);
      for (const f of r.found) {
        insert("fy_reports", {
          county_code: r.site.code, county: r.site.county, fy: f.fy, title: f.title,
          url: f.url, kind: f.kind, source_page: "scrape:homepage", found_at: Date.now(),
        });
        reports++;
      }
      console.log(`${live ? "OK " : "FAIL"} ${r.status || r.error} ${r.site.county} — ${r.found.length} report links`);
    }
    saveDb();
  }

  // merge with previous statuses so partial (--only/--limit) runs never clobber the file
  let merged = new Map();
  try {
    for (const s of JSON.parse(fs.readFileSync(webFile, "utf8")).sites) merged.set(s.code, s);
  } catch { /* first run */ }
  for (const s of statuses) merged.set(s.code, s);
  const all = [...merged.values()].sort((a, b) => a.code - b.code);
  fs.writeFileSync(webFile, JSON.stringify({ generatedAt: new Date().toISOString(), sites: all }, null, 2));
  console.log(`\nDone: ${ok} live, ${fail} failed this run, ${reports} report links → SQLite fy_reports + ${webFile} (${all.length} sites tracked)`);
}

run().catch((e) => { console.error(e); process.exit(1); });
