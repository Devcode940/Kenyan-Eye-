// Seed SQLite from the shipped public/data JSON snapshots.
// Usage: node server/seed.mjs [--reset]
import fs from "node:fs";
import path from "node:path";
import { openDb, saveDb, insert, DATA_DIR, SITES_FILE } from "./db.mjs";

const read = (p) => JSON.parse(fs.readFileSync(path.join(DATA_DIR, p), "utf8"));
const reset = process.argv.includes("--reset");

async function main() {
  const db = await openDb();
  if (reset) {
    for (const t of ["counties", "finance_snapshots", "parliament", "succession", "county_sites"]) db.run(`DELETE FROM ${t}`);
  }
  if ((await import("./db.mjs")).count("counties") > 0 && !reset) {
    console.log("DB already seeded. Use --reset to reseed.");
    return;
  }

  const master = read("counties/county_master.json");
  for (const c of master.counties) {
    insert("counties", {
      code: c.code, name: c.name, region: c.region, governor: c.governor,
      party: c.party, coalition: c.coalition, term: c.term,
      population_2019: c.population_2019, land_area_sqkm: c.land_area_sqkm,
      density_per_sqkm: c.density_per_sqkm,
    });
  }

  const finance = read("finance/snapshots.json");
  for (const r of finance) {
    insert("finance_snapshots", {
      county_name: r.countyName, fy: r.fiscalYear, approved_budget_m: r.approvedBudget,
      equitable_share_m: r.equitableShare, osr_m: r.ownSourceRevenue, osr_target_m: r.osrTarget,
      actual_m: r.actualExpenditure, recurrent_m: r.recurrentExpenditure, development_m: r.developmentExpenditure,
      absorption: r.overallAbsorption, recurrent_absorption: r.recurrentAbsorption, dev_absorption: r.developmentAbsorption,
      audit: r.auditOpinion, pending_bills_m: r.pendingBills, compliance: r.complianceScore,
      notes: r.notes, source: r.source,
    });
  }

  const parl = read("elections/parliament.json");
  const seen = new Set();
  const dedupe = (id) => {
    if (!seen.has(id)) { seen.add(id); return id; }
    let i = 2;
    while (seen.has(`${id}-${i}`)) i++;
    seen.add(`${id}-${i}`);
    return `${id}-${i}`;
  };
  for (const m of parl.mps) {
    insert("parliament", {
      id: dedupe(m.id), full_name: m.fullName, title: m.officialTitle, party: m.party, coalition: m.coalition,
      jurisdiction: m.jurisdiction, county_name: m.countyName, county_code: m.countyCode,
      status: m.status, profile_url: m.profileUrl, kind: "mp",
    });
  }
  for (const m of parl.senators) {
    insert("parliament", {
      id: dedupe(m.id), full_name: m.fullName, title: m.officialTitle, party: m.party, coalition: m.coalition,
      jurisdiction: m.jurisdiction, county_name: m.countyName, county_code: m.countyCode,
      status: m.status || "Elected", profile_url: m.profileUrl, kind: "senator",
    });
  }
  for (const m of parl.womenReps) {
    insert("parliament", {
      id: dedupe(m.id), full_name: m.fullName, title: m.officialTitle, party: m.party, coalition: m.coalition,
      jurisdiction: m.jurisdiction, county_name: m.countyName, county_code: m.countyCode,
      status: m.status || "Elected", profile_url: m.profileUrl, kind: "women",
    });
  }

  const hist = read("elections/history.json");
  for (const h of hist.counties) {
    insert("succession", { code: h.code, county: h.county, t1: h["2013_2017"], t2: h["2017_2022"], t3: h["2022_2027"], note: h.note });
  }

  try {
    const sites = JSON.parse(fs.readFileSync(SITES_FILE, "utf8")).sites;
    for (const s of sites) {
      insert("county_sites", { code: s.code, county: s.county, url: s.url, http_status: null, title: null, checked_at: null });
    }
  } catch (e) {
    console.log("county sites list not seeded:", e.message);
  }

  saveDb();
  const c = (await import("./db.mjs"));
  console.log(`Seeded: ${c.count("counties")} counties, ${c.count("finance_snapshots")} finance rows, ${c.count("parliament")} parliament rows, ${c.count("succession")} succession rows, ${c.count("county_sites")} sites.`);
}

main().catch((e) => { console.error(e); process.exit(1); });
